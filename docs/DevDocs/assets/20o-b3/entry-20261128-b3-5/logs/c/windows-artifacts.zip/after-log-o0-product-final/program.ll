; Xiao N0-B LLVM dynamic module
; target = x86_64-pc-windows-msvc
target triple = "x86_64-pc-windows-msvc"

%xiao.value = type { i32, i64 }
%xiao.bytes = type { ptr, i64 }

%xiao.table.field = type { %xiao.bytes, i32, i8 }
%xiao.table.descriptor = type { %xiao.bytes, i32, ptr, i64 }

%xiao.table.method = type { %xiao.bytes, i64, ptr, i64, i32, i8, ptr }
%xiao.table.descriptor.v2 = type { i32, i32, %xiao.table.descriptor, ptr, i64, ptr, ptr, ptr }

%xiao.error.location = type { i64, i64, i8, [7 x i8] }

; xiao.source-map statement 0..25
; xiao.source-map statement 26..85
@.xiao.bytes0 = private unnamed_addr constant [6 x i8] c"zh-CN\00"
@.xiao.str1 = private unnamed_addr constant [7 x i8] c"stdout\00"
@.xiao.str2 = private unnamed_addr constant [6 x i8] c"B3-5C\00"
@.xiao.str3 = private unnamed_addr constant [5 x i8] c"info\00"
@.xiao.bytes4 = private unnamed_addr constant [11 x i8] c"stdlib.log\00"
@.xiao.bytes5 = private unnamed_addr constant [6 x i8] c"write\00"

declare i32 @xiao_runtime_abi_is_compatible(i32, i32)
declare i32 @xiao_runtime_array_new(ptr, i64, ptr)
declare i32 @xiao_runtime_array_push(ptr, ptr)
declare i32 @xiao_runtime_concurrency_call(ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_concurrency_call_with_entry(ptr, ptr, ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_concurrency_cancellation_check(ptr)
declare i32 @xiao_runtime_concurrency_finish()
declare i32 @xiao_runtime_dict_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_dict_new(i32, ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_dynamic_check(ptr, ptr)
declare i32 @xiao_runtime_dynamic_member_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_env_run_native(ptr, i64, i32)
declare i32 @xiao_runtime_error_attach_span(i64, i64)
declare i32 @xiao_runtime_error_checkpoint_finish()
declare i32 @xiao_runtime_error_class()
declare i32 @xiao_runtime_error_code(ptr, ptr)
declare i32 @xiao_runtime_error_exit_code()
declare i32 @xiao_runtime_error_matches(ptr)
declare i32 @xiao_runtime_error_raise_value(ptr, ptr)
declare i32 @xiao_runtime_error_take(ptr)
declare i32 @xiao_runtime_language_context_set(ptr)
declare i32 @xiao_runtime_lfloat_divide(ptr, ptr, ptr, ptr, ptr)
declare i32 @xiao_runtime_log_write(ptr, ptr, ptr, i64)
declare i32 @xiao_runtime_print_values_with_capabilities(ptr, i64, i64)
declare i32 @xiao_runtime_process_close_with_capabilities(ptr, i64)
declare i32 @xiao_runtime_random_seed(ptr)
declare i32 @xiao_runtime_resource_close_with_capabilities(ptr, i64)
declare i32 @xiao_runtime_set_add(ptr, ptr)
declare i32 @xiao_runtime_set_new(ptr, i64, ptr)
declare i32 @xiao_runtime_set_remove(ptr, ptr, ptr)
declare i32 @xiao_runtime_string_new(ptr, ptr)
declare i32 @xiao_runtime_table_call(ptr, ptr, i64, ptr, i64, ptr)
declare i32 @xiao_runtime_table_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_get_value(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_new(ptr, ptr)
declare i32 @xiao_runtime_table_new_v2(ptr, ptr)
declare i32 @xiao_runtime_table_new_v2_with_args(ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_table_set(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_set_value(ptr, ptr, ptr)
declare i32 @xiao_runtime_tuple_new(ptr, i64, ptr)
declare i32 @xiao_runtime_value_binary(ptr, ptr, ptr, ptr)
declare i32 @xiao_runtime_value_cast(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_chr(ptr, ptr)
declare i32 @xiao_runtime_value_copy(ptr, ptr)
declare i32 @xiao_runtime_value_dict_keys(ptr, ptr)
declare i32 @xiao_runtime_value_dict_remove_dynamic(ptr, ptr)
declare i32 @xiao_runtime_value_dict_values(ptr, ptr)
declare i32 @xiao_runtime_value_index_get_dynamic(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_index_set_dynamic(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_iter_get(ptr, i64, ptr)
declare i32 @xiao_runtime_value_iter_len(ptr, ptr)
declare i32 @xiao_runtime_value_iter_snapshot(ptr, ptr)
declare i32 @xiao_runtime_value_release_weak(ptr)
declare i32 @xiao_runtime_value_select(ptr, i64, ptr, ptr)
declare i32 @xiao_runtime_value_unary(ptr, ptr, ptr)
declare ptr @llvm.stacksave()
declare void @llvm.stackrestore(ptr)
declare void @llvm.trap()
declare void @xiao_runtime_concurrency_entry_begin()
declare void @xiao_runtime_error_checkpoint_begin()
declare void @xiao_runtime_error_checkpoint_discard()
declare void @xiao_runtime_error_checkpoint_reset()
declare void @xiao_runtime_error_clear()
declare void @xiao_runtime_error_new(ptr sret(%xiao.value) align 8, ptr, ptr, ptr, ptr)
declare void @xiao_runtime_error_new_values(ptr sret(%xiao.value) align 8, ptr, ptr, ptr, ptr)
declare void @xiao_runtime_error_push_native_frame(ptr, ptr, i64, i64)
declare void @xiao_runtime_error_report()
declare void @xiao_runtime_fatal_abi()
declare void @xiao_runtime_input_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i8, i64)
declare void @xiao_runtime_process_spawn_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_process_wait_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_release(ptr)
declare void @xiao_runtime_release_trace_begin()
declare void @xiao_runtime_release_trace_flush()
declare void @xiao_runtime_resource_open_directory_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_resource_open_file_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_resource_read_text_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_value_array(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_array_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_bool(ptr sret(%xiao.value) align 8, i8)
declare void @xiao_runtime_value_dict(ptr sret(%xiao.value) align 8, ptr, i32)
declare void @xiao_runtime_value_dict_owned(ptr sret(%xiao.value) align 8, ptr, i32)
declare void @xiao_runtime_value_float(ptr sret(%xiao.value) align 8, double)
declare void @xiao_runtime_value_int(ptr sret(%xiao.value) align 8, i64)
declare void @xiao_runtime_value_lfloat(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lfloat_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lint(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lint_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_none(ptr sret(%xiao.value) align 8)
declare void @xiao_runtime_value_release_any(ptr)
declare void @xiao_runtime_value_release_strong(ptr)
declare void @xiao_runtime_value_set(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_set_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_sfloat(ptr sret(%xiao.value) align 8, float)
declare void @xiao_runtime_value_sint(ptr sret(%xiao.value) align 8, i32)
declare void @xiao_runtime_value_str(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_table(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_table_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_tuple(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_tuple_owned(ptr sret(%xiao.value) align 8, ptr)

define void @xiao_entry() {
entry:
  %xiao.statement.site0 = alloca %xiao.value
  %xiao.statement.site1 = alloca %xiao.value
  %xiao.statement.site2 = alloca %xiao.value
  %slot0 = alloca %xiao.value
  %t3 = alloca %xiao.bytes
  %t8 = alloca %xiao.value
  %t9 = alloca %xiao.value
  %t10 = alloca %xiao.value
  %t14 = alloca %xiao.bytes
  %t15 = alloca ptr
  %t20 = alloca %xiao.value
  %t26 = alloca %xiao.bytes
  %t27 = alloca ptr
  %t32 = alloca %xiao.value
  %t38 = alloca %xiao.bytes
  %t39 = alloca ptr
  %t44 = alloca %xiao.value
  %t47 = alloca %xiao.value
  %t51 = alloca %xiao.value
  store %xiao.value zeroinitializer, ptr %xiao.statement.site0
  store %xiao.value zeroinitializer, ptr %xiao.statement.site1
  store %xiao.value zeroinitializer, ptr %xiao.statement.site2
  call void @xiao_runtime_error_checkpoint_reset()
  call void @xiao_runtime_error_clear()
  call void @xiao_runtime_release_trace_begin()
  store %xiao.value zeroinitializer, ptr %slot0
  %t0 = getelementptr inbounds [6 x i8], ptr @.xiao.bytes0, i64 0, i64 0
  %t1 = insertvalue %xiao.bytes zeroinitializer, ptr %t0, 0
  %t2 = insertvalue %xiao.bytes %t1, i64 5, 1
  store %xiao.bytes %t2, ptr %t3
  %t4 = call i32 @xiao_runtime_language_context_set(ptr %t3)
  %t5 = icmp eq i32 %t4, 0
  br i1 %t5, label %abi.ok0, label %abi.status.fail1
abi.status.fail1:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 86)
  br label %xiao.error.terminal
abi.ok0:
  %t6 = call i32 @xiao_runtime_abi_is_compatible(i32 1, i32 20)
  %t7 = icmp eq i32 %t6, 1
  br i1 %t7, label %abi.entry.ok, label %abi.fail
abi.entry.ok:
  store %xiao.value zeroinitializer, ptr %t8
  store %xiao.value zeroinitializer, ptr %t9
  store %xiao.value zeroinitializer, ptr %t10
  %t11 = getelementptr inbounds [7 x i8], ptr @.xiao.str1, i64 0, i64 0
  %t12 = insertvalue %xiao.bytes zeroinitializer, ptr %t11, 0
  %t13 = insertvalue %xiao.bytes %t12, i64 6, 1
  store %xiao.bytes %t13, ptr %t14
  store ptr null, ptr %t15
  %t16 = call i32 @xiao_runtime_string_new(ptr %t14, ptr %t15)
  %t17 = icmp eq i32 %t16, 0
  br i1 %t17, label %abi.ok4, label %abi.status.fail5
abi.status.fail5:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 86)
  br label %dynamic.call.arguments.fail2
abi.ok4:
  %t18 = load ptr, ptr %t15
  store %xiao.value zeroinitializer, ptr %t20
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t20, ptr %t18)
  %t19 = load %xiao.value, ptr %t20
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  store %xiao.value %t19, ptr %xiao.statement.site0
  %t21 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site0, ptr %t8)
  %t22 = icmp eq i32 %t21, 0
  br i1 %t22, label %abi.ok6, label %abi.status.fail7
abi.status.fail7:
  call i32 @xiao_runtime_error_attach_span(i64 41, i64 49)
  br label %dynamic.call.arguments.fail2
abi.ok6:
  %t23 = getelementptr inbounds [6 x i8], ptr @.xiao.str2, i64 0, i64 0
  %t24 = insertvalue %xiao.bytes zeroinitializer, ptr %t23, 0
  %t25 = insertvalue %xiao.bytes %t24, i64 5, 1
  store %xiao.bytes %t25, ptr %t26
  store ptr null, ptr %t27
  %t28 = call i32 @xiao_runtime_string_new(ptr %t26, ptr %t27)
  %t29 = icmp eq i32 %t28, 0
  br i1 %t29, label %abi.ok8, label %abi.status.fail9
abi.status.fail9:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 86)
  br label %dynamic.call.arguments.fail2
abi.ok8:
  %t30 = load ptr, ptr %t27
  store %xiao.value zeroinitializer, ptr %t32
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t32, ptr %t30)
  %t31 = load %xiao.value, ptr %t32
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  store %xiao.value %t31, ptr %xiao.statement.site1
  %t33 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site1, ptr %t9)
  %t34 = icmp eq i32 %t33, 0
  br i1 %t34, label %abi.ok10, label %abi.status.fail11
abi.status.fail11:
  call i32 @xiao_runtime_error_attach_span(i64 61, i64 68)
  br label %dynamic.call.arguments.fail2
abi.ok10:
  %t35 = getelementptr inbounds [5 x i8], ptr @.xiao.str3, i64 0, i64 0
  %t36 = insertvalue %xiao.bytes zeroinitializer, ptr %t35, 0
  %t37 = insertvalue %xiao.bytes %t36, i64 4, 1
  store %xiao.bytes %t37, ptr %t38
  store ptr null, ptr %t39
  %t40 = call i32 @xiao_runtime_string_new(ptr %t38, ptr %t39)
  %t41 = icmp eq i32 %t40, 0
  br i1 %t41, label %abi.ok12, label %abi.status.fail13
abi.status.fail13:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 86)
  br label %dynamic.call.arguments.fail2
abi.ok12:
  %t42 = load ptr, ptr %t39
  store %xiao.value zeroinitializer, ptr %t44
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t44, ptr %t42)
  %t43 = load %xiao.value, ptr %t44
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  store %xiao.value %t43, ptr %xiao.statement.site2
  %t45 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site2, ptr %t10)
  %t46 = icmp eq i32 %t45, 0
  br i1 %t46, label %abi.ok14, label %abi.status.fail15
abi.status.fail15:
  call i32 @xiao_runtime_error_attach_span(i64 78, i64 84)
  br label %dynamic.call.arguments.fail2
abi.ok14:
  br label %dynamic.call.arguments.ready3
dynamic.call.arguments.fail2:
  call void @xiao_runtime_value_release_strong(ptr %t8)
  call void @xiao_runtime_value_release_strong(ptr %t9)
  call void @xiao_runtime_value_release_strong(ptr %t10)
  br label %xiao.error.terminal
dynamic.call.arguments.ready3:
  store %xiao.value zeroinitializer, ptr %t47
  call void @xiao.fn.56e1deb30070798e(ptr %t47, ptr %t10, ptr %t9, ptr %t8)
  call void @xiao_runtime_value_release_strong(ptr %t8)
  call void @xiao_runtime_value_release_strong(ptr %t9)
  call void @xiao_runtime_value_release_strong(ptr %t10)
  %t48 = call i32 @xiao_runtime_error_class()
  %t49 = icmp eq i32 %t48, 0
  br i1 %t49, label %dynamic.call.ok16, label %dynamic.call.fail17
dynamic.call.fail17:
  br label %xiao.error.terminal
dynamic.call.ok16:
  %t50 = load %xiao.value, ptr %t47
  store %xiao.value %t50, ptr %t51
  call void @xiao_runtime_value_release_strong(ptr %t51)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  %t52 = call i32 @xiao_runtime_error_class()
  %t53 = icmp eq i32 %t52, 0
  br i1 %t53, label %abi.error.ok18, label %abi.error.fail19
abi.error.fail19:
  call i32 @xiao_runtime_error_attach_span(i64 26, i64 85)
  br label %xiao.error.terminal
abi.error.ok18:
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  %t54 = call i32 @xiao_runtime_error_class()
  %t55 = icmp eq i32 %t54, 0
  br i1 %t55, label %abi.ok20, label %abi.status.fail21
abi.status.fail21:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 86)
  br label %xiao.error.terminal
abi.ok20:
  call void @xiao_runtime_release_trace_flush()
  ret void
xiao.error.terminal:
  %t56 = call i32 @xiao_runtime_error_class()
  %t57 = icmp eq i32 %t56, 2
  br i1 %t57, label %xiao.error.report22, label %xiao.error.unmatched23
xiao.error.unmatched23:
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  br label %xiao.error.report22
xiao.error.report22:
  call void @xiao_runtime_error_report()
  call void @xiao_runtime_release_trace_flush()
  %t58 = call i32 @xiao_runtime_error_exit_code()
  ret void
abi.fail:
  call void @xiao_runtime_fatal_abi()
  unreachable
}

define internal i32 @xiao_application_main() {
entry:
  call void @xiao_entry()
  %xiao_exit_code = call i32 @xiao_runtime_error_exit_code()
  ret i32 %xiao_exit_code
}

define i32 @main() {
entry:
  %status = call i32 @xiao_runtime_env_run_native(ptr @xiao_application_main, i64 34, i32 0)
  ret i32 %status
}

define void @xiao.fn.56e1deb30070798e(ptr %xiao.function.result, ptr %xiao.arg0, ptr %xiao.arg1, ptr %xiao.arg2) {
entry:
  %xiao.return.source = alloca ptr
  %xiao.return.temporary = alloca i1
  %slot0 = alloca %xiao.value
  %slot1 = alloca %xiao.value
  %slot2 = alloca %xiao.value
  %t9 = alloca %xiao.value
  %t10 = alloca %xiao.value
  %t11 = alloca %xiao.value
  %t12 = alloca %xiao.value
  %t16 = alloca %xiao.value
  %t20 = alloca %xiao.value
  %t25 = alloca %xiao.value
  %t27 = alloca %xiao.value
  %t37 = alloca %xiao.bytes
  %t41 = alloca %xiao.bytes
  store ptr null, ptr %xiao.return.source
  store i1 false, ptr %xiao.return.temporary
  store %xiao.value zeroinitializer, ptr %slot0
  store %xiao.value zeroinitializer, ptr %slot1
  store %xiao.value zeroinitializer, ptr %slot2
  %t0 = call i32 @xiao_runtime_value_copy(ptr %xiao.arg0, ptr %slot0)
  %t1 = icmp eq i32 %t0, 0
  br i1 %t1, label %abi.ok0, label %abi.status.fail1
abi.status.fail1:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 86)
  br label %xiao.fn.error
abi.ok0:
  %t2 = call i32 @xiao_runtime_value_copy(ptr %xiao.arg1, ptr %slot1)
  %t3 = icmp eq i32 %t2, 0
  br i1 %t3, label %abi.ok2, label %abi.status.fail3
abi.status.fail3:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 86)
  br label %xiao.fn.error
abi.ok2:
  %t4 = call i32 @xiao_runtime_value_copy(ptr %xiao.arg2, ptr %slot2)
  %t5 = icmp eq i32 %t4, 0
  br i1 %t5, label %abi.ok4, label %abi.status.fail5
abi.status.fail5:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 86)
  br label %xiao.fn.error
abi.ok4:
  %t6 = load %xiao.value, ptr %slot0
  %t7 = load %xiao.value, ptr %slot1
  %t8 = load %xiao.value, ptr %slot2
  store %xiao.value zeroinitializer, ptr %t9
  store %xiao.value zeroinitializer, ptr %t10
  store %xiao.value zeroinitializer, ptr %t11
  store %xiao.value zeroinitializer, ptr %t12
  %t13 = call i32 @xiao_runtime_value_copy(ptr %slot0, ptr %t12)
  %t14 = icmp eq i32 %t13, 0
  br i1 %t14, label %abi.ok8, label %abi.status.fail9
abi.status.fail9:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 86)
  br label %log.arguments.fail6
abi.ok8:
  %t15 = load %xiao.value, ptr %t12
  store %xiao.value %t15, ptr %t9
  store %xiao.value zeroinitializer, ptr %t16
  %t17 = call i32 @xiao_runtime_value_copy(ptr %slot1, ptr %t16)
  %t18 = icmp eq i32 %t17, 0
  br i1 %t18, label %abi.ok10, label %abi.status.fail11
abi.status.fail11:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 86)
  br label %log.arguments.fail6
abi.ok10:
  %t19 = load %xiao.value, ptr %t16
  store %xiao.value %t19, ptr %t10
  store %xiao.value zeroinitializer, ptr %t20
  %t21 = call i32 @xiao_runtime_value_copy(ptr %slot2, ptr %t20)
  %t22 = icmp eq i32 %t21, 0
  br i1 %t22, label %abi.ok12, label %abi.status.fail13
abi.status.fail13:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 86)
  br label %log.arguments.fail6
abi.ok12:
  %t23 = load %xiao.value, ptr %t20
  store %xiao.value %t23, ptr %t11
  br label %log.arguments.ready7
log.arguments.fail6:
  call void @xiao_runtime_value_release_strong(ptr %t11)
  call void @xiao_runtime_value_release_strong(ptr %t10)
  call void @xiao_runtime_value_release_strong(ptr %t9)
  br label %xiao.fn.error
log.arguments.ready7:
  %t24 = call i32 @xiao_runtime_log_write(ptr %t9, ptr %t10, ptr %t11, i64 34)
  call void @xiao_runtime_value_release_strong(ptr %t11)
  call void @xiao_runtime_value_release_strong(ptr %t10)
  call void @xiao_runtime_value_release_strong(ptr %t9)
  switch i32 %t24, label %log.abi.failure16 [ i32 0, label %log.ok14 i32 6, label %log.error15 i32 8, label %log.error15 ]
log.abi.failure16:
  call void @xiao_runtime_fatal_abi()
  unreachable
log.error15:
  call i32 @xiao_runtime_error_attach_span(i64 58, i64 94)
  br label %xiao.fn.error
log.ok14:
  store %xiao.value zeroinitializer, ptr %t25
  call void @xiao_runtime_value_release_strong(ptr %t25)
  store ptr null, ptr %xiao.return.source
  store %xiao.value zeroinitializer, ptr %t27
  call void @xiao_runtime_value_none(ptr sret(%xiao.value) %t27)
  %t26 = load %xiao.value, ptr %t27
  store %xiao.value %t26, ptr %xiao.function.result
  br label %xiao.fn.return
xiao.fn.return:
  call void @xiao_runtime_value_release_strong(ptr %slot2)
  call void @xiao_runtime_value_release_strong(ptr %slot1)
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  %t28 = call i32 @xiao_runtime_error_class()
  %t29 = icmp eq i32 %t28, 0
  br i1 %t29, label %abi.ok17, label %abi.status.fail18
abi.status.fail18:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 95)
  br label %xiao.fn.error
abi.ok17:
  br label %xiao.fn.return.cleanup
xiao.fn.return.cleanup:
  %t30 = call i32 @xiao_runtime_error_class()
  %t31 = icmp eq i32 %t30, 0
  br i1 %t31, label %abi.ok19, label %abi.status.fail20
abi.status.fail20:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 95)
  br label %xiao.fn.error
abi.ok19:
  ret void
xiao.fn.error:
  %t32 = call i32 @xiao_runtime_error_class()
  %t33 = icmp eq i32 %t32, 2
  br i1 %t33, label %xiao.fn.error.return, label %xiao.fn.error.cleanup
xiao.fn.error.cleanup:
  call void @xiao_runtime_value_release_strong(ptr %slot2)
  call void @xiao_runtime_value_release_strong(ptr %slot1)
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.function.result)
  br label %xiao.fn.error.return
xiao.fn.error.return:
  %t34 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes4, i64 0, i64 0
  %t35 = insertvalue %xiao.bytes zeroinitializer, ptr %t34, 0
  %t36 = insertvalue %xiao.bytes %t35, i64 10, 1
  store %xiao.bytes %t36, ptr %t37
  %t38 = getelementptr inbounds [6 x i8], ptr @.xiao.bytes5, i64 0, i64 0
  %t39 = insertvalue %xiao.bytes zeroinitializer, ptr %t38, 0
  %t40 = insertvalue %xiao.bytes %t39, i64 5, 1
  store %xiao.bytes %t40, ptr %t41
  call void @xiao_runtime_error_push_native_frame(ptr %t37, ptr %t41, i64 0, i64 95)
  store %xiao.value zeroinitializer, ptr %xiao.function.result
  ret void
}


@xiao_native_metadata = constant [107 x i8] c"\58\49\41\4F\4D\45\54\41\01\00\00\00\6B\00\00\00\14\00\01\00\00\00\00\00\14\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\1B\00\00\00\40\00\00\00\01\00\00\00\14\00\01\00\00\00\00\00\16\00\00\00\78\38\36\5F\36\34\2D\70\63\2D\77\69\6E\64\6F\77\73\2D\6D\73\76\63\05\00\00\00\30\2E\31\2E\30\08\00\00\00\70\6F\72\74\61\62\6C\65", section ".xiaomta", align 4
@llvm.used = appending global [1 x ptr] [ptr @xiao_native_metadata], section "llvm.metadata"
