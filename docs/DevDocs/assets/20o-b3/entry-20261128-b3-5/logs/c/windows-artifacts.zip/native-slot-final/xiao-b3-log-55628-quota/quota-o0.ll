; Xiao N0-B LLVM dynamic module
; target = x86_64-pc-windows-msvc
target triple = "x86_64-pc-windows-msvc"

%xiao.value = type { i32, i64 }
%xiao.bytes = type { ptr, i64 }

%xiao.table.field = type { %xiao.bytes, i32, i8 }
%xiao.table.descriptor = type { %xiao.bytes, i32, ptr, i64 }

%xiao.table.method = type { %xiao.bytes, i64, ptr, i64, i32, i8, ptr }
%xiao.table.descriptor.v2 = type { i32, i32, %xiao.table.descriptor, ptr, i64, ptr, ptr, ptr }

%xiao.error.location = type { i64, i64, i8, [7 x i8] }

; xiao.source-map statement 0..55
; xiao.source-map statement 56..144
; xiao.source-map statement 91..130
; xiao.source-map return 135..143
; xiao.source-map statement 144..157
; xiao.source-map while 158..242
; xiao.source-map statement 181..219
; xiao.source-map statement 224..241
; xiao.source-map statement 242..264
; xiao.source-map statement 265..299
; xiao.source-map statement 300..310
; xiao.source-map statement 311..350
@.xiao.bytes0 = private unnamed_addr constant [6 x i8] c"zh-CN\00"
@.xiao.bytes1 = private unnamed_addr constant [3 x i8] c"lt\00"
@.xiao.str2 = private unnamed_addr constant [5 x i8] c"info\00"
@.xiao.str3 = private unnamed_addr constant [5 x i8] c"root\00"
@.xiao.str4 = private unnamed_addr constant [7 x i8] c"stdout\00"
@.xiao.bytes5 = private unnamed_addr constant [4 x i8] c"add\00"
@.xiao.bytes6 = private unnamed_addr constant [16 x i8] c"current_runtime\00"
@.xiao.str7 = private unnamed_addr constant [7 x i8] c"worker\00"
@.xiao.bytes8 = private unnamed_addr constant [11 x i8] c"safe_point\00"
@.xiao.bytes9 = private unnamed_addr constant [6 x i8] c"spawn\00"
@.xiao.bytes10 = private unnamed_addr constant [5 x i8] c"wait\00"
@.xiao.bytes11 = private unnamed_addr constant [5 x i8] c"join\00"
@.xiao.str12 = private unnamed_addr constant [6 x i8] c"error\00"
@.xiao.str13 = private unnamed_addr constant [5 x i8] c"over\00"
@.xiao.str14 = private unnamed_addr constant [7 x i8] c"stdout\00"
@.xiao.bytes15 = private unnamed_addr constant [11 x i8] c"safe_point\00"
@.xiao.str16 = private unnamed_addr constant [5 x i8] c"warn\00"
@.xiao.str17 = private unnamed_addr constant [7 x i8] c"stdout\00"
@.xiao.bytes18 = private unnamed_addr constant [11 x i8] c"safe_point\00"
@.xiao.bytes19 = private unnamed_addr constant [6 x i8] c"entry\00"
@.xiao.bytes20 = private unnamed_addr constant [7 x i8] c"worker\00"

declare i32 @xiao_runtime_abi_is_compatible(i32, i32)
declare i32 @xiao_runtime_array_new(ptr, i64, ptr)
declare i32 @xiao_runtime_array_push(ptr, ptr)
declare i32 @xiao_runtime_concurrency_call(ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_concurrency_call_with_entry(ptr, ptr, ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_concurrency_cancellation_check(ptr)
declare i32 @xiao_runtime_concurrency_finish()
declare i32 @xiao_runtime_dict_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_dict_new(i32, ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_dynamic_check(ptr, ptr)
declare i32 @xiao_runtime_dynamic_member_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_env_run_native(ptr, i64, i32)
declare i32 @xiao_runtime_error_attach_span(i64, i64)
declare i32 @xiao_runtime_error_checkpoint_finish()
declare i32 @xiao_runtime_error_class()
declare i32 @xiao_runtime_error_code(ptr, ptr)
declare i32 @xiao_runtime_error_exit_code()
declare i32 @xiao_runtime_error_matches(ptr)
declare i32 @xiao_runtime_error_raise_value(ptr, ptr)
declare i32 @xiao_runtime_error_take(ptr)
declare i32 @xiao_runtime_language_context_set(ptr)
declare i32 @xiao_runtime_lfloat_divide(ptr, ptr, ptr, ptr, ptr)
declare i32 @xiao_runtime_log_write(ptr, ptr, ptr, i64)
declare i32 @xiao_runtime_print_values_with_capabilities(ptr, i64, i64)
declare i32 @xiao_runtime_process_close_with_capabilities(ptr, i64)
declare i32 @xiao_runtime_random_seed(ptr)
declare i32 @xiao_runtime_resource_close_with_capabilities(ptr, i64)
declare i32 @xiao_runtime_set_add(ptr, ptr)
declare i32 @xiao_runtime_set_new(ptr, i64, ptr)
declare i32 @xiao_runtime_set_remove(ptr, ptr, ptr)
declare i32 @xiao_runtime_string_new(ptr, ptr)
declare i32 @xiao_runtime_table_call(ptr, ptr, i64, ptr, i64, ptr)
declare i32 @xiao_runtime_table_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_get_value(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_new(ptr, ptr)
declare i32 @xiao_runtime_table_new_v2(ptr, ptr)
declare i32 @xiao_runtime_table_new_v2_with_args(ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_table_set(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_set_value(ptr, ptr, ptr)
declare i32 @xiao_runtime_tuple_new(ptr, i64, ptr)
declare i32 @xiao_runtime_value_binary(ptr, ptr, ptr, ptr)
declare i32 @xiao_runtime_value_cast(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_chr(ptr, ptr)
declare i32 @xiao_runtime_value_copy(ptr, ptr)
declare i32 @xiao_runtime_value_dict_keys(ptr, ptr)
declare i32 @xiao_runtime_value_dict_remove_dynamic(ptr, ptr)
declare i32 @xiao_runtime_value_dict_values(ptr, ptr)
declare i32 @xiao_runtime_value_index_get_dynamic(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_index_set_dynamic(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_iter_get(ptr, i64, ptr)
declare i32 @xiao_runtime_value_iter_len(ptr, ptr)
declare i32 @xiao_runtime_value_iter_snapshot(ptr, ptr)
declare i32 @xiao_runtime_value_release_weak(ptr)
declare i32 @xiao_runtime_value_select(ptr, i64, ptr, ptr)
declare i32 @xiao_runtime_value_unary(ptr, ptr, ptr)
declare ptr @llvm.stacksave()
declare void @llvm.stackrestore(ptr)
declare void @llvm.trap()
declare void @xiao_runtime_concurrency_entry_begin()
declare void @xiao_runtime_error_checkpoint_begin()
declare void @xiao_runtime_error_checkpoint_discard()
declare void @xiao_runtime_error_checkpoint_reset()
declare void @xiao_runtime_error_clear()
declare void @xiao_runtime_error_new(ptr sret(%xiao.value) align 8, ptr, ptr, ptr, ptr)
declare void @xiao_runtime_error_new_values(ptr sret(%xiao.value) align 8, ptr, ptr, ptr, ptr)
declare void @xiao_runtime_error_push_native_frame(ptr, ptr, i64, i64)
declare void @xiao_runtime_error_report()
declare void @xiao_runtime_fatal_abi()
declare void @xiao_runtime_input_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i8, i64)
declare void @xiao_runtime_process_spawn_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_process_wait_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_release(ptr)
declare void @xiao_runtime_release_trace_begin()
declare void @xiao_runtime_release_trace_flush()
declare void @xiao_runtime_resource_open_directory_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_resource_open_file_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_resource_read_text_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_value_array(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_array_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_bool(ptr sret(%xiao.value) align 8, i8)
declare void @xiao_runtime_value_dict(ptr sret(%xiao.value) align 8, ptr, i32)
declare void @xiao_runtime_value_dict_owned(ptr sret(%xiao.value) align 8, ptr, i32)
declare void @xiao_runtime_value_float(ptr sret(%xiao.value) align 8, double)
declare void @xiao_runtime_value_int(ptr sret(%xiao.value) align 8, i64)
declare void @xiao_runtime_value_lfloat(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lfloat_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lint(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lint_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_none(ptr sret(%xiao.value) align 8)
declare void @xiao_runtime_value_release_any(ptr)
declare void @xiao_runtime_value_release_strong(ptr)
declare void @xiao_runtime_value_set(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_set_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_sfloat(ptr sret(%xiao.value) align 8, float)
declare void @xiao_runtime_value_sint(ptr sret(%xiao.value) align 8, i32)
declare void @xiao_runtime_value_str(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_table(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_table_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_tuple(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_tuple_owned(ptr sret(%xiao.value) align 8, ptr)

define void @xiao_entry() {
entry:
  %xiao.statement.site0 = alloca %xiao.value
  %xiao.statement.site1 = alloca %xiao.value
  %xiao.statement.site2 = alloca %xiao.value
  %xiao.statement.site3 = alloca %xiao.value
  %xiao.statement.site4 = alloca %xiao.value
  %xiao.statement.site5 = alloca %xiao.value
  %slot3 = alloca %xiao.value
  %slot0 = alloca %xiao.value
  %slot2 = alloca %xiao.value
  %slot4 = alloca %xiao.value
  %slot1 = alloca %xiao.value
  %slot5 = alloca %xiao.value
  %t3 = alloca %xiao.bytes
  %t9 = alloca %xiao.value
  %t10 = alloca %xiao.value
  %t15 = alloca %xiao.value
  %t19 = alloca %xiao.bytes
  %t20 = alloca %xiao.value
  %t21 = alloca %xiao.value
  %t22 = alloca %xiao.value
  %t26 = alloca %xiao.value
  %t27 = alloca %xiao.value
  %t28 = alloca %xiao.value
  %t29 = alloca %xiao.value
  %t34 = alloca %xiao.value
  %t35 = alloca %xiao.value
  %t36 = alloca %xiao.value
  %t37 = alloca %xiao.value
  %t41 = alloca %xiao.bytes
  %t42 = alloca ptr
  %t47 = alloca %xiao.value
  %t53 = alloca %xiao.bytes
  %t54 = alloca ptr
  %t59 = alloca %xiao.value
  %t65 = alloca %xiao.bytes
  %t66 = alloca ptr
  %t71 = alloca %xiao.value
  %t75 = alloca %xiao.value
  %t78 = alloca %xiao.value
  %t83 = alloca %xiao.value
  %t87 = alloca %xiao.bytes
  %t88 = alloca %xiao.value
  %t89 = alloca %xiao.value
  %t90 = alloca %xiao.value
  %t94 = alloca %xiao.value
  %t95 = alloca %xiao.value
  %t96 = alloca %xiao.value
  %t97 = alloca %xiao.value
  %t98 = alloca %xiao.value, i64 0
  %t99 = alloca %xiao.value
  %t103 = alloca %xiao.bytes
  %t107 = alloca %xiao.value, i64 2
  %t110 = alloca %xiao.value
  %t117 = alloca %xiao.bytes
  %t118 = alloca ptr
  %t123 = alloca %xiao.value
  %t127 = alloca %xiao.bytes
  %t130 = alloca %xiao.value
  %t134 = alloca %xiao.bytes
  %t138 = alloca %xiao.value, i64 1
  %t140 = alloca %xiao.value
  %t147 = alloca %xiao.bytes
  %t150 = alloca %xiao.value
  %t154 = alloca %xiao.bytes
  %t158 = alloca %xiao.value
  %t159 = alloca %xiao.value
  %t160 = alloca %xiao.value
  %t161 = alloca %xiao.value
  %t165 = alloca %xiao.bytes
  %t166 = alloca ptr
  %t171 = alloca %xiao.value
  %t177 = alloca %xiao.bytes
  %t178 = alloca ptr
  %t183 = alloca %xiao.value
  %t189 = alloca %xiao.bytes
  %t190 = alloca ptr
  %t195 = alloca %xiao.value
  %t199 = alloca %xiao.value
  store %xiao.value zeroinitializer, ptr %xiao.statement.site0
  store %xiao.value zeroinitializer, ptr %xiao.statement.site1
  store %xiao.value zeroinitializer, ptr %xiao.statement.site2
  store %xiao.value zeroinitializer, ptr %xiao.statement.site3
  store %xiao.value zeroinitializer, ptr %xiao.statement.site4
  store %xiao.value zeroinitializer, ptr %xiao.statement.site5
  call void @xiao_runtime_error_checkpoint_reset()
  call void @xiao_runtime_error_clear()
  call void @xiao_runtime_release_trace_begin()
  store %xiao.value zeroinitializer, ptr %slot3
  store %xiao.value zeroinitializer, ptr %slot0
  store %xiao.value zeroinitializer, ptr %slot2
  store %xiao.value zeroinitializer, ptr %slot4
  store %xiao.value zeroinitializer, ptr %slot1
  store %xiao.value zeroinitializer, ptr %slot5
  %t0 = getelementptr inbounds [6 x i8], ptr @.xiao.bytes0, i64 0, i64 0
  %t1 = insertvalue %xiao.bytes zeroinitializer, ptr %t0, 0
  %t2 = insertvalue %xiao.bytes %t1, i64 5, 1
  store %xiao.bytes %t2, ptr %t3
  %t4 = call i32 @xiao_runtime_language_context_set(ptr %t3)
  %t5 = icmp eq i32 %t4, 0
  br i1 %t5, label %abi.ok0, label %abi.status.fail1
abi.status.fail1:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %xiao.error.terminal
abi.ok0:
  call void @xiao_runtime_concurrency_entry_begin()
  %t6 = call i32 @xiao_runtime_abi_is_compatible(i32 1, i32 20)
  %t7 = icmp eq i32 %t6, 1
  br i1 %t7, label %abi.entry.ok, label %abi.fail
abi.entry.ok:
  store %xiao.value zeroinitializer, ptr %t9
  call void @xiao_runtime_value_int(ptr sret(%xiao.value) %t9, i64 0)
  %t8 = load %xiao.value, ptr %t9
  call void @xiao_runtime_value_release_strong(ptr %slot3)
  store %xiao.value %t8, ptr %slot3
  br label %dynamic.while.cond2
dynamic.while.cond2:
  store %xiao.value zeroinitializer, ptr %t10
  %t11 = call i32 @xiao_runtime_value_copy(ptr %slot3, ptr %t10)
  %t12 = icmp eq i32 %t11, 0
  br i1 %t12, label %abi.ok5, label %abi.status.fail6
abi.status.fail6:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %xiao.error.terminal
abi.ok5:
  %t13 = load %xiao.value, ptr %t10
  store %xiao.value zeroinitializer, ptr %t15
  call void @xiao_runtime_value_int(ptr sret(%xiao.value) %t15, i64 1023)
  %t14 = load %xiao.value, ptr %t15
  %t16 = getelementptr inbounds [3 x i8], ptr @.xiao.bytes1, i64 0, i64 0
  %t17 = insertvalue %xiao.bytes zeroinitializer, ptr %t16, 0
  %t18 = insertvalue %xiao.bytes %t17, i64 2, 1
  store %xiao.bytes %t18, ptr %t19
  store %xiao.value %t13, ptr %t20
  store %xiao.value %t14, ptr %t21
  store %xiao.value zeroinitializer, ptr %t22
  %t23 = call i32 @xiao_runtime_value_binary(ptr %t19, ptr %t20, ptr %t21, ptr %t22)
  %t24 = icmp eq i32 %t23, 0
  br i1 %t24, label %abi.ok10, label %abi.status.fail11
abi.status.fail11:
  call i32 @xiao_runtime_error_attach_span(i64 164, i64 176)
  br label %dynamic.binary.fail8
abi.ok10:
  %t25 = load %xiao.value, ptr %t22
  store %xiao.value %t13, ptr %t26
  call void @xiao_runtime_value_release_strong(ptr %t26)
  store %xiao.value %t14, ptr %t27
  call void @xiao_runtime_value_release_strong(ptr %t27)
  br label %dynamic.binary.continue9
dynamic.binary.fail8:
  store %xiao.value %t14, ptr %t28
  call void @xiao_runtime_value_release_strong(ptr %t28)
  br label %dynamic.binary.left.fail7
dynamic.binary.left.fail7:
  store %xiao.value %t13, ptr %t29
  call void @xiao_runtime_value_release_strong(ptr %t29)
  br label %xiao.error.terminal
dynamic.binary.continue9:
  %t30 = extractvalue %xiao.value %t25, 0
  %t31 = icmp eq i32 %t30, 1
  br i1 %t31, label %dynamic.bool.ok12, label %xiao.error.terminal
dynamic.bool.ok12:
  %t32 = extractvalue %xiao.value %t25, 1
  %t33 = trunc i64 %t32 to i1
  store %xiao.value %t25, ptr %t34
  call void @xiao_runtime_value_release_strong(ptr %t34)
  br i1 %t33, label %dynamic.while.body3, label %dynamic.while.end4
dynamic.while.body3:
  store %xiao.value zeroinitializer, ptr %t35
  store %xiao.value zeroinitializer, ptr %t36
  store %xiao.value zeroinitializer, ptr %t37
  %t38 = getelementptr inbounds [5 x i8], ptr @.xiao.str2, i64 0, i64 0
  %t39 = insertvalue %xiao.bytes zeroinitializer, ptr %t38, 0
  %t40 = insertvalue %xiao.bytes %t39, i64 4, 1
  store %xiao.bytes %t40, ptr %t41
  store ptr null, ptr %t42
  %t43 = call i32 @xiao_runtime_string_new(ptr %t41, ptr %t42)
  %t44 = icmp eq i32 %t43, 0
  br i1 %t44, label %abi.ok15, label %abi.status.fail16
abi.status.fail16:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %log.arguments.fail13
abi.ok15:
  %t45 = load ptr, ptr %t42
  store %xiao.value zeroinitializer, ptr %t47
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t47, ptr %t45)
  %t46 = load %xiao.value, ptr %t47
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  store %xiao.value %t46, ptr %xiao.statement.site0
  %t48 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site0, ptr %t35)
  %t49 = icmp eq i32 %t48, 0
  br i1 %t49, label %abi.ok17, label %abi.status.fail18
abi.status.fail18:
  call i32 @xiao_runtime_error_attach_span(i64 194, i64 200)
  br label %log.arguments.fail13
abi.ok17:
  %t50 = getelementptr inbounds [5 x i8], ptr @.xiao.str3, i64 0, i64 0
  %t51 = insertvalue %xiao.bytes zeroinitializer, ptr %t50, 0
  %t52 = insertvalue %xiao.bytes %t51, i64 4, 1
  store %xiao.bytes %t52, ptr %t53
  store ptr null, ptr %t54
  %t55 = call i32 @xiao_runtime_string_new(ptr %t53, ptr %t54)
  %t56 = icmp eq i32 %t55, 0
  br i1 %t56, label %abi.ok19, label %abi.status.fail20
abi.status.fail20:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %log.arguments.fail13
abi.ok19:
  %t57 = load ptr, ptr %t54
  store %xiao.value zeroinitializer, ptr %t59
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t59, ptr %t57)
  %t58 = load %xiao.value, ptr %t59
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  store %xiao.value %t58, ptr %xiao.statement.site1
  %t60 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site1, ptr %t36)
  %t61 = icmp eq i32 %t60, 0
  br i1 %t61, label %abi.ok21, label %abi.status.fail22
abi.status.fail22:
  call i32 @xiao_runtime_error_attach_span(i64 202, i64 208)
  br label %log.arguments.fail13
abi.ok21:
  %t62 = getelementptr inbounds [7 x i8], ptr @.xiao.str4, i64 0, i64 0
  %t63 = insertvalue %xiao.bytes zeroinitializer, ptr %t62, 0
  %t64 = insertvalue %xiao.bytes %t63, i64 6, 1
  store %xiao.bytes %t64, ptr %t65
  store ptr null, ptr %t66
  %t67 = call i32 @xiao_runtime_string_new(ptr %t65, ptr %t66)
  %t68 = icmp eq i32 %t67, 0
  br i1 %t68, label %abi.ok23, label %abi.status.fail24
abi.status.fail24:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %log.arguments.fail13
abi.ok23:
  %t69 = load ptr, ptr %t66
  store %xiao.value zeroinitializer, ptr %t71
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t71, ptr %t69)
  %t70 = load %xiao.value, ptr %t71
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  store %xiao.value %t70, ptr %xiao.statement.site2
  %t72 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site2, ptr %t37)
  %t73 = icmp eq i32 %t72, 0
  br i1 %t73, label %abi.ok25, label %abi.status.fail26
abi.status.fail26:
  call i32 @xiao_runtime_error_attach_span(i64 210, i64 218)
  br label %log.arguments.fail13
abi.ok25:
  br label %log.arguments.ready14
log.arguments.fail13:
  call void @xiao_runtime_value_release_strong(ptr %t37)
  call void @xiao_runtime_value_release_strong(ptr %t36)
  call void @xiao_runtime_value_release_strong(ptr %t35)
  br label %xiao.error.terminal
log.arguments.ready14:
  %t74 = call i32 @xiao_runtime_log_write(ptr %t35, ptr %t36, ptr %t37, i64 34)
  call void @xiao_runtime_value_release_strong(ptr %t37)
  call void @xiao_runtime_value_release_strong(ptr %t36)
  call void @xiao_runtime_value_release_strong(ptr %t35)
  switch i32 %t74, label %log.abi.failure29 [ i32 0, label %log.ok27 i32 6, label %log.error28 i32 8, label %log.error28 ]
log.abi.failure29:
  call void @xiao_runtime_fatal_abi()
  unreachable
log.error28:
  call i32 @xiao_runtime_error_attach_span(i64 181, i64 219)
  br label %xiao.error.terminal
log.ok27:
  store %xiao.value zeroinitializer, ptr %t75
  call void @xiao_runtime_value_release_strong(ptr %t75)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  %t76 = call i32 @xiao_runtime_error_class()
  %t77 = icmp eq i32 %t76, 0
  br i1 %t77, label %abi.error.ok30, label %abi.error.fail31
abi.error.fail31:
  call i32 @xiao_runtime_error_attach_span(i64 181, i64 219)
  br label %xiao.error.terminal
abi.error.ok30:
  store %xiao.value zeroinitializer, ptr %t78
  %t79 = call i32 @xiao_runtime_value_copy(ptr %slot3, ptr %t78)
  %t80 = icmp eq i32 %t79, 0
  br i1 %t80, label %abi.ok32, label %abi.status.fail33
abi.status.fail33:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %xiao.error.terminal
abi.ok32:
  %t81 = load %xiao.value, ptr %t78
  store %xiao.value zeroinitializer, ptr %t83
  call void @xiao_runtime_value_int(ptr sret(%xiao.value) %t83, i64 1)
  %t82 = load %xiao.value, ptr %t83
  %t84 = getelementptr inbounds [4 x i8], ptr @.xiao.bytes5, i64 0, i64 0
  %t85 = insertvalue %xiao.bytes zeroinitializer, ptr %t84, 0
  %t86 = insertvalue %xiao.bytes %t85, i64 3, 1
  store %xiao.bytes %t86, ptr %t87
  store %xiao.value %t81, ptr %t88
  store %xiao.value %t82, ptr %t89
  store %xiao.value zeroinitializer, ptr %t90
  %t91 = call i32 @xiao_runtime_value_binary(ptr %t87, ptr %t88, ptr %t89, ptr %t90)
  %t92 = icmp eq i32 %t91, 0
  br i1 %t92, label %abi.ok37, label %abi.status.fail38
abi.status.fail38:
  call i32 @xiao_runtime_error_attach_span(i64 232, i64 241)
  br label %dynamic.binary.fail35
abi.ok37:
  %t93 = load %xiao.value, ptr %t90
  store %xiao.value %t81, ptr %t94
  call void @xiao_runtime_value_release_strong(ptr %t94)
  store %xiao.value %t82, ptr %t95
  call void @xiao_runtime_value_release_strong(ptr %t95)
  br label %dynamic.binary.continue36
dynamic.binary.fail35:
  store %xiao.value %t82, ptr %t96
  call void @xiao_runtime_value_release_strong(ptr %t96)
  br label %dynamic.binary.left.fail34
dynamic.binary.left.fail34:
  store %xiao.value %t81, ptr %t97
  call void @xiao_runtime_value_release_strong(ptr %t97)
  br label %xiao.error.terminal
dynamic.binary.continue36:
  call void @xiao_runtime_value_release_strong(ptr %slot3)
  store %xiao.value %t93, ptr %slot3
  br label %dynamic.while.cond2
dynamic.while.end4:
  store %xiao.value zeroinitializer, ptr %t99
  %t100 = getelementptr inbounds [16 x i8], ptr @.xiao.bytes6, i64 0, i64 0
  %t101 = insertvalue %xiao.bytes zeroinitializer, ptr %t100, 0
  %t102 = insertvalue %xiao.bytes %t101, i64 15, 1
  store %xiao.bytes %t102, ptr %t103
  %t104 = call i32 @xiao_runtime_concurrency_call(ptr %t103, ptr %t98, i64 0, ptr %t99)
  %t105 = icmp eq i32 %t104, 0
  br i1 %t105, label %abi.ok40, label %abi.status.fail41
abi.status.fail41:
  call i32 @xiao_runtime_error_attach_span(i64 247, i64 264)
  br label %dynamic.concurrency.fail39
abi.ok40:
  br label %dynamic.concurrency.ready42
dynamic.concurrency.fail39:
  br label %xiao.error.terminal
dynamic.concurrency.ready42:
  %t106 = load %xiao.value, ptr %t99
  call void @xiao_runtime_value_release_strong(ptr %slot4)
  store %xiao.value %t106, ptr %slot4
  %t108 = getelementptr inbounds %xiao.value, ptr %t107, i64 0
  store %xiao.value zeroinitializer, ptr %t108
  %t109 = getelementptr inbounds %xiao.value, ptr %t107, i64 1
  store %xiao.value zeroinitializer, ptr %t109
  store %xiao.value zeroinitializer, ptr %t110
  %t111 = call i32 @xiao_runtime_value_copy(ptr %slot4, ptr %t110)
  %t112 = icmp eq i32 %t111, 0
  br i1 %t112, label %abi.ok44, label %abi.status.fail45
abi.status.fail45:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %dynamic.concurrency.fail43
abi.ok44:
  %t113 = load %xiao.value, ptr %t110
  store %xiao.value %t113, ptr %t108
  %t114 = getelementptr inbounds [7 x i8], ptr @.xiao.str7, i64 0, i64 0
  %t115 = insertvalue %xiao.bytes zeroinitializer, ptr %t114, 0
  %t116 = insertvalue %xiao.bytes %t115, i64 6, 1
  store %xiao.bytes %t116, ptr %t117
  store ptr null, ptr %t118
  %t119 = call i32 @xiao_runtime_string_new(ptr %t117, ptr %t118)
  %t120 = icmp eq i32 %t119, 0
  br i1 %t120, label %abi.ok46, label %abi.status.fail47
abi.status.fail47:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %dynamic.concurrency.fail43
abi.ok46:
  %t121 = load ptr, ptr %t118
  store %xiao.value zeroinitializer, ptr %t123
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t123, ptr %t121)
  %t122 = load %xiao.value, ptr %t123
  store %xiao.value %t122, ptr %t109
  %t124 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes8, i64 0, i64 0
  %t125 = insertvalue %xiao.bytes zeroinitializer, ptr %t124, 0
  %t126 = insertvalue %xiao.bytes %t125, i64 10, 1
  store %xiao.bytes %t126, ptr %t127
  %t128 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t127)
  %t129 = icmp eq i32 %t128, 0
  br i1 %t129, label %abi.ok48, label %abi.status.fail49
abi.status.fail49:
  call i32 @xiao_runtime_error_attach_span(i64 272, i64 299)
  br label %dynamic.concurrency.fail43
abi.ok48:
  store %xiao.value zeroinitializer, ptr %t130
  %t131 = getelementptr inbounds [6 x i8], ptr @.xiao.bytes9, i64 0, i64 0
  %t132 = insertvalue %xiao.bytes zeroinitializer, ptr %t131, 0
  %t133 = insertvalue %xiao.bytes %t132, i64 5, 1
  store %xiao.bytes %t133, ptr %t134
  %t135 = call i32 @xiao_runtime_concurrency_call_with_entry(ptr %t134, ptr @xiao.concurrent.trampoline.6dcd1be4090efe22, ptr null, ptr %t107, i64 2, ptr %t130)
  %t136 = icmp eq i32 %t135, 0
  br i1 %t136, label %abi.ok50, label %abi.status.fail51
abi.status.fail51:
  call i32 @xiao_runtime_error_attach_span(i64 272, i64 299)
  br label %dynamic.concurrency.fail43
abi.ok50:
  br label %dynamic.concurrency.ready52
dynamic.concurrency.fail43:
  call void @xiao_runtime_value_release_strong(ptr %t109)
  call void @xiao_runtime_value_release_strong(ptr %t108)
  br label %xiao.error.terminal
dynamic.concurrency.ready52:
  call void @xiao_runtime_value_release_strong(ptr %t108)
  call void @xiao_runtime_value_release_strong(ptr %t109)
  %t137 = load %xiao.value, ptr %t130
  call void @xiao_runtime_value_release_strong(ptr %slot5)
  store %xiao.value %t137, ptr %slot5
  %t139 = getelementptr inbounds %xiao.value, ptr %t138, i64 0
  store %xiao.value zeroinitializer, ptr %t139
  store %xiao.value zeroinitializer, ptr %t140
  %t141 = call i32 @xiao_runtime_value_copy(ptr %slot5, ptr %t140)
  %t142 = icmp eq i32 %t141, 0
  br i1 %t142, label %abi.ok54, label %abi.status.fail55
abi.status.fail55:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %dynamic.concurrency.fail53
abi.ok54:
  %t143 = load %xiao.value, ptr %t140
  store %xiao.value %t143, ptr %t139
  %t144 = getelementptr inbounds [5 x i8], ptr @.xiao.bytes10, i64 0, i64 0
  %t145 = insertvalue %xiao.bytes zeroinitializer, ptr %t144, 0
  %t146 = insertvalue %xiao.bytes %t145, i64 4, 1
  store %xiao.bytes %t146, ptr %t147
  %t148 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t147)
  %t149 = icmp eq i32 %t148, 0
  br i1 %t149, label %abi.ok56, label %abi.status.fail57
abi.status.fail57:
  call i32 @xiao_runtime_error_attach_span(i64 300, i64 310)
  br label %dynamic.concurrency.fail53
abi.ok56:
  store %xiao.value zeroinitializer, ptr %t150
  %t151 = getelementptr inbounds [5 x i8], ptr @.xiao.bytes11, i64 0, i64 0
  %t152 = insertvalue %xiao.bytes zeroinitializer, ptr %t151, 0
  %t153 = insertvalue %xiao.bytes %t152, i64 4, 1
  store %xiao.bytes %t153, ptr %t154
  %t155 = call i32 @xiao_runtime_concurrency_call(ptr %t154, ptr %t138, i64 1, ptr %t150)
  %t156 = icmp eq i32 %t155, 0
  br i1 %t156, label %abi.ok58, label %abi.status.fail59
abi.status.fail59:
  call i32 @xiao_runtime_error_attach_span(i64 300, i64 310)
  br label %dynamic.concurrency.fail53
abi.ok58:
  br label %dynamic.concurrency.ready60
dynamic.concurrency.fail53:
  call void @xiao_runtime_value_release_strong(ptr %t139)
  br label %xiao.error.terminal
dynamic.concurrency.ready60:
  call void @xiao_runtime_value_release_strong(ptr %t139)
  %t157 = load %xiao.value, ptr %t150
  store %xiao.value %t157, ptr %t158
  call void @xiao_runtime_value_release_strong(ptr %t158)
  store %xiao.value zeroinitializer, ptr %t159
  store %xiao.value zeroinitializer, ptr %t160
  store %xiao.value zeroinitializer, ptr %t161
  %t162 = getelementptr inbounds [6 x i8], ptr @.xiao.str12, i64 0, i64 0
  %t163 = insertvalue %xiao.bytes zeroinitializer, ptr %t162, 0
  %t164 = insertvalue %xiao.bytes %t163, i64 5, 1
  store %xiao.bytes %t164, ptr %t165
  store ptr null, ptr %t166
  %t167 = call i32 @xiao_runtime_string_new(ptr %t165, ptr %t166)
  %t168 = icmp eq i32 %t167, 0
  br i1 %t168, label %abi.ok63, label %abi.status.fail64
abi.status.fail64:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %log.arguments.fail61
abi.ok63:
  %t169 = load ptr, ptr %t166
  store %xiao.value zeroinitializer, ptr %t171
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t171, ptr %t169)
  %t170 = load %xiao.value, ptr %t171
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site3)
  store %xiao.value %t170, ptr %xiao.statement.site3
  %t172 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site3, ptr %t159)
  %t173 = icmp eq i32 %t172, 0
  br i1 %t173, label %abi.ok65, label %abi.status.fail66
abi.status.fail66:
  call i32 @xiao_runtime_error_attach_span(i64 324, i64 331)
  br label %log.arguments.fail61
abi.ok65:
  %t174 = getelementptr inbounds [5 x i8], ptr @.xiao.str13, i64 0, i64 0
  %t175 = insertvalue %xiao.bytes zeroinitializer, ptr %t174, 0
  %t176 = insertvalue %xiao.bytes %t175, i64 4, 1
  store %xiao.bytes %t176, ptr %t177
  store ptr null, ptr %t178
  %t179 = call i32 @xiao_runtime_string_new(ptr %t177, ptr %t178)
  %t180 = icmp eq i32 %t179, 0
  br i1 %t180, label %abi.ok67, label %abi.status.fail68
abi.status.fail68:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %log.arguments.fail61
abi.ok67:
  %t181 = load ptr, ptr %t178
  store %xiao.value zeroinitializer, ptr %t183
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t183, ptr %t181)
  %t182 = load %xiao.value, ptr %t183
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site4)
  store %xiao.value %t182, ptr %xiao.statement.site4
  %t184 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site4, ptr %t160)
  %t185 = icmp eq i32 %t184, 0
  br i1 %t185, label %abi.ok69, label %abi.status.fail70
abi.status.fail70:
  call i32 @xiao_runtime_error_attach_span(i64 333, i64 339)
  br label %log.arguments.fail61
abi.ok69:
  %t186 = getelementptr inbounds [7 x i8], ptr @.xiao.str14, i64 0, i64 0
  %t187 = insertvalue %xiao.bytes zeroinitializer, ptr %t186, 0
  %t188 = insertvalue %xiao.bytes %t187, i64 6, 1
  store %xiao.bytes %t188, ptr %t189
  store ptr null, ptr %t190
  %t191 = call i32 @xiao_runtime_string_new(ptr %t189, ptr %t190)
  %t192 = icmp eq i32 %t191, 0
  br i1 %t192, label %abi.ok71, label %abi.status.fail72
abi.status.fail72:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %log.arguments.fail61
abi.ok71:
  %t193 = load ptr, ptr %t190
  store %xiao.value zeroinitializer, ptr %t195
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t195, ptr %t193)
  %t194 = load %xiao.value, ptr %t195
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site5)
  store %xiao.value %t194, ptr %xiao.statement.site5
  %t196 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site5, ptr %t161)
  %t197 = icmp eq i32 %t196, 0
  br i1 %t197, label %abi.ok73, label %abi.status.fail74
abi.status.fail74:
  call i32 @xiao_runtime_error_attach_span(i64 341, i64 349)
  br label %log.arguments.fail61
abi.ok73:
  br label %log.arguments.ready62
log.arguments.fail61:
  call void @xiao_runtime_value_release_strong(ptr %t161)
  call void @xiao_runtime_value_release_strong(ptr %t160)
  call void @xiao_runtime_value_release_strong(ptr %t159)
  br label %xiao.error.terminal
log.arguments.ready62:
  %t198 = call i32 @xiao_runtime_log_write(ptr %t159, ptr %t160, ptr %t161, i64 34)
  call void @xiao_runtime_value_release_strong(ptr %t161)
  call void @xiao_runtime_value_release_strong(ptr %t160)
  call void @xiao_runtime_value_release_strong(ptr %t159)
  switch i32 %t198, label %log.abi.failure77 [ i32 0, label %log.ok75 i32 6, label %log.error76 i32 8, label %log.error76 ]
log.abi.failure77:
  call void @xiao_runtime_fatal_abi()
  unreachable
log.error76:
  call i32 @xiao_runtime_error_attach_span(i64 311, i64 350)
  br label %xiao.error.terminal
log.ok75:
  store %xiao.value zeroinitializer, ptr %t199
  call void @xiao_runtime_value_release_strong(ptr %t199)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site3)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site4)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site5)
  %t200 = call i32 @xiao_runtime_error_class()
  %t201 = icmp eq i32 %t200, 0
  br i1 %t201, label %abi.error.ok78, label %abi.error.fail79
abi.error.fail79:
  call i32 @xiao_runtime_error_attach_span(i64 311, i64 350)
  br label %xiao.error.terminal
abi.error.ok78:
  call void @xiao_runtime_value_release_strong(ptr %slot5)
  call void @xiao_runtime_value_release_strong(ptr %slot4)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site3)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site4)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site5)
  call i32 @xiao_runtime_concurrency_finish()
  %t202 = call i32 @xiao_runtime_error_class()
  %t203 = icmp eq i32 %t202, 0
  br i1 %t203, label %abi.ok80, label %abi.status.fail81
abi.status.fail81:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %xiao.error.terminal
abi.ok80:
  call void @xiao_runtime_release_trace_flush()
  ret void
xiao.error.terminal:
  %t204 = call i32 @xiao_runtime_error_class()
  %t205 = icmp eq i32 %t204, 2
  br i1 %t205, label %xiao.error.report82, label %xiao.error.unmatched83
xiao.error.unmatched83:
  call void @xiao_runtime_value_release_strong(ptr %slot5)
  call void @xiao_runtime_value_release_strong(ptr %slot4)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site3)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site4)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site5)
  br label %xiao.error.report82
xiao.error.report82:
  call i32 @xiao_runtime_concurrency_finish()
  call void @xiao_runtime_error_report()
  call void @xiao_runtime_release_trace_flush()
  %t206 = call i32 @xiao_runtime_error_exit_code()
  ret void
abi.fail:
  call void @xiao_runtime_fatal_abi()
  unreachable
}

define internal i32 @xiao_application_main() {
entry:
  call void @xiao_entry()
  %xiao_exit_code = call i32 @xiao_runtime_error_exit_code()
  ret i32 %xiao_exit_code
}

define i32 @main() {
entry:
  %status = call i32 @xiao_runtime_env_run_native(ptr @xiao_application_main, i64 34, i32 0)
  ret i32 %status
}

define i32 @xiao.concurrent.trampoline.6dcd1be4090efe22(ptr %xiao.context, ptr %xiao.arguments, i64 %xiao.argument.count, ptr %xiao.result) {
entry:
  %xiao.count.ok = icmp eq i64 %xiao.argument.count, 1
  br i1 %xiao.count.ok, label %xiao.invoke, label %xiao.invalid
xiao.invalid:
  ret i32 2
xiao.invoke:
  %xiao.arg.0 = getelementptr inbounds %xiao.value, ptr %xiao.arguments, i64 0
  call void @xiao.fn.890ef20b09e48da3(ptr %xiao.result, ptr %xiao.arg.0)
  %xiao.error.class = call i32 @xiao_runtime_error_class()
  ret i32 %xiao.error.class
}

define void @xiao.fn.890ef20b09e48da3(ptr %xiao.function.result, ptr %xiao.arg0) {
entry:
  %xiao.statement.site0 = alloca %xiao.value
  %xiao.statement.site1 = alloca %xiao.value
  %xiao.return.site0 = alloca %xiao.value
  %xiao.return.source = alloca ptr
  %xiao.return.temporary = alloca i1
  %slot0 = alloca %xiao.value
  %t6 = alloca %xiao.bytes
  %t9 = alloca %xiao.value
  %t10 = alloca %xiao.value
  %t11 = alloca %xiao.value
  %t15 = alloca %xiao.bytes
  %t16 = alloca ptr
  %t21 = alloca %xiao.value
  %t24 = alloca %xiao.value
  %t31 = alloca %xiao.bytes
  %t32 = alloca ptr
  %t37 = alloca %xiao.value
  %t41 = alloca %xiao.value
  %t47 = alloca %xiao.bytes
  %t51 = alloca %xiao.value
  %t67 = alloca %xiao.bytes
  %t71 = alloca %xiao.bytes
  store %xiao.value zeroinitializer, ptr %xiao.statement.site0
  store %xiao.value zeroinitializer, ptr %xiao.statement.site1
  store %xiao.value zeroinitializer, ptr %xiao.return.site0
  store ptr null, ptr %xiao.return.source
  store i1 false, ptr %xiao.return.temporary
  store %xiao.value zeroinitializer, ptr %slot0
  %t0 = call i32 @xiao_runtime_value_copy(ptr %xiao.arg0, ptr %slot0)
  %t1 = icmp eq i32 %t0, 0
  br i1 %t1, label %abi.ok0, label %abi.status.fail1
abi.status.fail1:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %xiao.fn.error
abi.ok0:
  %t2 = load %xiao.value, ptr %slot0
  %t3 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes15, i64 0, i64 0
  %t4 = insertvalue %xiao.bytes zeroinitializer, ptr %t3, 0
  %t5 = insertvalue %xiao.bytes %t4, i64 10, 1
  store %xiao.bytes %t5, ptr %t6
  %t7 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t6)
  %t8 = icmp eq i32 %t7, 0
  br i1 %t8, label %abi.ok2, label %abi.status.fail3
abi.status.fail3:
  call i32 @xiao_runtime_error_attach_span(i64 91, i64 130)
  br label %xiao.fn.error
abi.ok2:
  store %xiao.value zeroinitializer, ptr %t9
  store %xiao.value zeroinitializer, ptr %t10
  store %xiao.value zeroinitializer, ptr %t11
  %t12 = getelementptr inbounds [5 x i8], ptr @.xiao.str16, i64 0, i64 0
  %t13 = insertvalue %xiao.bytes zeroinitializer, ptr %t12, 0
  %t14 = insertvalue %xiao.bytes %t13, i64 4, 1
  store %xiao.bytes %t14, ptr %t15
  store ptr null, ptr %t16
  %t17 = call i32 @xiao_runtime_string_new(ptr %t15, ptr %t16)
  %t18 = icmp eq i32 %t17, 0
  br i1 %t18, label %abi.ok6, label %abi.status.fail7
abi.status.fail7:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %log.arguments.fail4
abi.ok6:
  %t19 = load ptr, ptr %t16
  store %xiao.value zeroinitializer, ptr %t21
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t21, ptr %t19)
  %t20 = load %xiao.value, ptr %t21
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  store %xiao.value %t20, ptr %xiao.statement.site0
  %t22 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site0, ptr %t9)
  %t23 = icmp eq i32 %t22, 0
  br i1 %t23, label %abi.ok8, label %abi.status.fail9
abi.status.fail9:
  call i32 @xiao_runtime_error_attach_span(i64 104, i64 110)
  br label %log.arguments.fail4
abi.ok8:
  store %xiao.value zeroinitializer, ptr %t24
  %t25 = call i32 @xiao_runtime_value_copy(ptr %slot0, ptr %t24)
  %t26 = icmp eq i32 %t25, 0
  br i1 %t26, label %abi.ok10, label %abi.status.fail11
abi.status.fail11:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %log.arguments.fail4
abi.ok10:
  %t27 = load %xiao.value, ptr %t24
  store %xiao.value %t27, ptr %t10
  %t28 = getelementptr inbounds [7 x i8], ptr @.xiao.str17, i64 0, i64 0
  %t29 = insertvalue %xiao.bytes zeroinitializer, ptr %t28, 0
  %t30 = insertvalue %xiao.bytes %t29, i64 6, 1
  store %xiao.bytes %t30, ptr %t31
  store ptr null, ptr %t32
  %t33 = call i32 @xiao_runtime_string_new(ptr %t31, ptr %t32)
  %t34 = icmp eq i32 %t33, 0
  br i1 %t34, label %abi.ok12, label %abi.status.fail13
abi.status.fail13:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %log.arguments.fail4
abi.ok12:
  %t35 = load ptr, ptr %t32
  store %xiao.value zeroinitializer, ptr %t37
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t37, ptr %t35)
  %t36 = load %xiao.value, ptr %t37
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  store %xiao.value %t36, ptr %xiao.statement.site1
  %t38 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site1, ptr %t11)
  %t39 = icmp eq i32 %t38, 0
  br i1 %t39, label %abi.ok14, label %abi.status.fail15
abi.status.fail15:
  call i32 @xiao_runtime_error_attach_span(i64 121, i64 129)
  br label %log.arguments.fail4
abi.ok14:
  br label %log.arguments.ready5
log.arguments.fail4:
  call void @xiao_runtime_value_release_strong(ptr %t11)
  call void @xiao_runtime_value_release_strong(ptr %t10)
  call void @xiao_runtime_value_release_strong(ptr %t9)
  br label %xiao.fn.error
log.arguments.ready5:
  %t40 = call i32 @xiao_runtime_log_write(ptr %t9, ptr %t10, ptr %t11, i64 34)
  call void @xiao_runtime_value_release_strong(ptr %t11)
  call void @xiao_runtime_value_release_strong(ptr %t10)
  call void @xiao_runtime_value_release_strong(ptr %t9)
  switch i32 %t40, label %log.abi.failure18 [ i32 0, label %log.ok16 i32 6, label %log.error17 i32 8, label %log.error17 ]
log.abi.failure18:
  call void @xiao_runtime_fatal_abi()
  unreachable
log.error17:
  call i32 @xiao_runtime_error_attach_span(i64 91, i64 130)
  br label %xiao.fn.error
log.ok16:
  store %xiao.value zeroinitializer, ptr %t41
  call void @xiao_runtime_value_release_strong(ptr %t41)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  %t42 = call i32 @xiao_runtime_error_class()
  %t43 = icmp eq i32 %t42, 0
  br i1 %t43, label %abi.error.ok19, label %abi.error.fail20
abi.error.fail20:
  call i32 @xiao_runtime_error_attach_span(i64 91, i64 130)
  br label %xiao.fn.error
abi.error.ok19:
  %t44 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes18, i64 0, i64 0
  %t45 = insertvalue %xiao.bytes zeroinitializer, ptr %t44, 0
  %t46 = insertvalue %xiao.bytes %t45, i64 10, 1
  store %xiao.bytes %t46, ptr %t47
  %t48 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t47)
  %t49 = icmp eq i32 %t48, 0
  br i1 %t49, label %abi.ok21, label %abi.status.fail22
abi.status.fail22:
  call i32 @xiao_runtime_error_attach_span(i64 135, i64 143)
  br label %xiao.fn.error
abi.ok21:
  store %xiao.value zeroinitializer, ptr %t51
  call void @xiao_runtime_value_int(ptr sret(%xiao.value) %t51, i64 0)
  %t50 = load %xiao.value, ptr %t51
  call void @xiao_runtime_error_clear()
  call void @xiao_runtime_value_release_strong(ptr %xiao.return.site0)
  store %xiao.value %t50, ptr %xiao.return.site0
  store ptr %xiao.return.site0, ptr %xiao.return.source
  store i1 true, ptr %xiao.return.temporary
  br label %xiao.fn.return
xiao.fn.return:
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  %t52 = call i32 @xiao_runtime_error_class()
  %t53 = icmp eq i32 %t52, 0
  br i1 %t53, label %abi.ok23, label %abi.status.fail24
abi.status.fail24:
  call i32 @xiao_runtime_error_attach_span(i64 56, i64 144)
  br label %xiao.fn.error
abi.ok23:
  %t54 = load ptr, ptr %xiao.return.source
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %xiao.fn.return.value, label %xiao.fn.return.cleanup
xiao.fn.return.value:
  %t56 = load i1, ptr %xiao.return.temporary
  br i1 %t56, label %xiao.fn.return.copy, label %xiao.fn.return.move
xiao.fn.return.copy:
  %t57 = call i32 @xiao_runtime_value_copy(ptr %t54, ptr %xiao.function.result)
  %t58 = icmp eq i32 %t57, 0
  br i1 %t58, label %abi.ok25, label %abi.status.fail26
abi.status.fail26:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 351)
  br label %xiao.fn.error
abi.ok25:
  br label %xiao.fn.return.cleanup
xiao.fn.return.move:
  %t59 = load %xiao.value, ptr %t54
  store %xiao.value %t59, ptr %xiao.function.result
  store %xiao.value zeroinitializer, ptr %t54
  br label %xiao.fn.return.cleanup
xiao.fn.return.cleanup:
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.return.site0)
  %t60 = call i32 @xiao_runtime_error_class()
  %t61 = icmp eq i32 %t60, 0
  br i1 %t61, label %abi.ok27, label %abi.status.fail28
abi.status.fail28:
  call i32 @xiao_runtime_error_attach_span(i64 56, i64 144)
  br label %xiao.fn.error
abi.ok27:
  ret void
xiao.fn.error:
  %t62 = call i32 @xiao_runtime_error_class()
  %t63 = icmp eq i32 %t62, 2
  br i1 %t63, label %xiao.fn.error.return, label %xiao.fn.error.cleanup
xiao.fn.error.cleanup:
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.return.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.function.result)
  br label %xiao.fn.error.return
xiao.fn.error.return:
  %t64 = getelementptr inbounds [6 x i8], ptr @.xiao.bytes19, i64 0, i64 0
  %t65 = insertvalue %xiao.bytes zeroinitializer, ptr %t64, 0
  %t66 = insertvalue %xiao.bytes %t65, i64 5, 1
  store %xiao.bytes %t66, ptr %t67
  %t68 = getelementptr inbounds [7 x i8], ptr @.xiao.bytes20, i64 0, i64 0
  %t69 = insertvalue %xiao.bytes zeroinitializer, ptr %t68, 0
  %t70 = insertvalue %xiao.bytes %t69, i64 6, 1
  store %xiao.bytes %t70, ptr %t71
  call void @xiao_runtime_error_push_native_frame(ptr %t67, ptr %t71, i64 56, i64 144)
  store %xiao.value zeroinitializer, ptr %xiao.function.result
  ret void
}


@xiao_native_metadata = constant [107 x i8] c"\58\49\41\4F\4D\45\54\41\01\00\00\00\6B\00\00\00\14\00\01\00\00\00\00\00\14\00\01\00\00\00\00\00\62\00\00\00\00\00\00\00\1B\00\00\00\40\00\00\00\01\00\00\00\14\00\01\00\00\00\00\00\16\00\00\00\78\38\36\5F\36\34\2D\70\63\2D\77\69\6E\64\6F\77\73\2D\6D\73\76\63\05\00\00\00\30\2E\31\2E\30\08\00\00\00\70\6F\72\74\61\62\6C\65", section ".xiaomta", align 4
@llvm.used = appending global [1 x ptr] [ptr @xiao_native_metadata], section "llvm.metadata"
