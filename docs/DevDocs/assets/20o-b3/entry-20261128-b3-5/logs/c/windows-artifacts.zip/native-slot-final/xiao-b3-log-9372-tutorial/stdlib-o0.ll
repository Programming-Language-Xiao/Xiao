; Xiao N0-B LLVM dynamic module
; target = x86_64-pc-windows-msvc
target triple = "x86_64-pc-windows-msvc"

%xiao.value = type { i32, i64 }
%xiao.bytes = type { ptr, i64 }

%xiao.table.field = type { %xiao.bytes, i32, i8 }
%xiao.table.descriptor = type { %xiao.bytes, i32, ptr, i64 }

%xiao.table.method = type { %xiao.bytes, i64, ptr, i64, i32, i8, ptr }
%xiao.table.descriptor.v2 = type { i32, i32, %xiao.table.descriptor, ptr, i64, ptr, ptr, ptr }

%xiao.error.location = type { i64, i64, i8, [7 x i8] }

; xiao.source-map statement 0..41
; xiao.source-map statement 43..86
; xiao.source-map try 87..195
; xiao.source-map statement 95..136
; xiao.source-map catch 137..195
; xiao.source-map statement 168..194
; xiao.source-map statement 195..266
@.xiao.bytes0 = private unnamed_addr constant [6 x i8] c"zh-CN\00"
@.xiao.str1 = private unnamed_addr constant [5 x i8] c"info\00"
@.xiao.str2 = private unnamed_addr constant [13 x i8] c"task started\00"
@.xiao.str3 = private unnamed_addr constant [7 x i8] c"stdout\00"
@.xiao.str4 = private unnamed_addr constant [5 x i8] c"warn\00"
@.xiao.str5 = private unnamed_addr constant [10 x i8] c"two\0Alines\00"
@.xiao.str6 = private unnamed_addr constant [7 x i8] c"stdout\00"
@.xiao.bytes7 = private unnamed_addr constant [10 x i8] c"TypeError\00"
@.xiao.bytes8 = private unnamed_addr constant [12 x i8] c"error_value\00"
@.xiao.str9 = private unnamed_addr constant [16 x i8] c"X06-RUNTIME-004\00"
@.xiao.bytes10 = private unnamed_addr constant [12 x i8] c"MemoryError\00"
@.xiao.str11 = private unnamed_addr constant [6 x i8] c"error\00"
@.xiao.str12 = private unnamed_addr constant [13 x i8] c"task stopped\00"
@.xiao.str13 = private unnamed_addr constant [7 x i8] c"stdout\00"
@.xiao.bytes14 = private unnamed_addr constant [11 x i8] c"stdlib.log\00"
@.xiao.bytes15 = private unnamed_addr constant [6 x i8] c"write\00"

declare i32 @xiao_runtime_abi_is_compatible(i32, i32)
declare i32 @xiao_runtime_array_new(ptr, i64, ptr)
declare i32 @xiao_runtime_array_push(ptr, ptr)
declare i32 @xiao_runtime_concurrency_call(ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_concurrency_call_with_entry(ptr, ptr, ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_concurrency_cancellation_check(ptr)
declare i32 @xiao_runtime_concurrency_finish()
declare i32 @xiao_runtime_dict_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_dict_new(i32, ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_dynamic_check(ptr, ptr)
declare i32 @xiao_runtime_dynamic_member_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_env_run_native(ptr, i64, i32)
declare i32 @xiao_runtime_error_attach_span(i64, i64)
declare i32 @xiao_runtime_error_checkpoint_finish()
declare i32 @xiao_runtime_error_class()
declare i32 @xiao_runtime_error_code(ptr, ptr)
declare i32 @xiao_runtime_error_exit_code()
declare i32 @xiao_runtime_error_matches(ptr)
declare i32 @xiao_runtime_error_raise_value(ptr, ptr)
declare i32 @xiao_runtime_error_take(ptr)
declare i32 @xiao_runtime_language_context_set(ptr)
declare i32 @xiao_runtime_lfloat_divide(ptr, ptr, ptr, ptr, ptr)
declare i32 @xiao_runtime_log_write(ptr, ptr, ptr, i64)
declare i32 @xiao_runtime_print_values_with_capabilities(ptr, i64, i64)
declare i32 @xiao_runtime_process_close_with_capabilities(ptr, i64)
declare i32 @xiao_runtime_random_seed(ptr)
declare i32 @xiao_runtime_resource_close_with_capabilities(ptr, i64)
declare i32 @xiao_runtime_set_add(ptr, ptr)
declare i32 @xiao_runtime_set_new(ptr, i64, ptr)
declare i32 @xiao_runtime_set_remove(ptr, ptr, ptr)
declare i32 @xiao_runtime_string_new(ptr, ptr)
declare i32 @xiao_runtime_table_call(ptr, ptr, i64, ptr, i64, ptr)
declare i32 @xiao_runtime_table_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_get_value(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_new(ptr, ptr)
declare i32 @xiao_runtime_table_new_v2(ptr, ptr)
declare i32 @xiao_runtime_table_new_v2_with_args(ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_table_set(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_set_value(ptr, ptr, ptr)
declare i32 @xiao_runtime_tuple_new(ptr, i64, ptr)
declare i32 @xiao_runtime_value_binary(ptr, ptr, ptr, ptr)
declare i32 @xiao_runtime_value_cast(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_chr(ptr, ptr)
declare i32 @xiao_runtime_value_copy(ptr, ptr)
declare i32 @xiao_runtime_value_dict_keys(ptr, ptr)
declare i32 @xiao_runtime_value_dict_remove_dynamic(ptr, ptr)
declare i32 @xiao_runtime_value_dict_values(ptr, ptr)
declare i32 @xiao_runtime_value_index_get_dynamic(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_index_set_dynamic(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_iter_get(ptr, i64, ptr)
declare i32 @xiao_runtime_value_iter_len(ptr, ptr)
declare i32 @xiao_runtime_value_iter_snapshot(ptr, ptr)
declare i32 @xiao_runtime_value_release_weak(ptr)
declare i32 @xiao_runtime_value_select(ptr, i64, ptr, ptr)
declare i32 @xiao_runtime_value_unary(ptr, ptr, ptr)
declare ptr @llvm.stacksave()
declare void @llvm.stackrestore(ptr)
declare void @llvm.trap()
declare void @xiao_runtime_concurrency_entry_begin()
declare void @xiao_runtime_error_checkpoint_begin()
declare void @xiao_runtime_error_checkpoint_discard()
declare void @xiao_runtime_error_checkpoint_reset()
declare void @xiao_runtime_error_clear()
declare void @xiao_runtime_error_new(ptr sret(%xiao.value) align 8, ptr, ptr, ptr, ptr)
declare void @xiao_runtime_error_new_values(ptr sret(%xiao.value) align 8, ptr, ptr, ptr, ptr)
declare void @xiao_runtime_error_push_native_frame(ptr, ptr, i64, i64)
declare void @xiao_runtime_error_report()
declare void @xiao_runtime_fatal_abi()
declare void @xiao_runtime_input_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i8, i64)
declare void @xiao_runtime_process_spawn_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_process_wait_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_release(ptr)
declare void @xiao_runtime_release_trace_begin()
declare void @xiao_runtime_release_trace_flush()
declare void @xiao_runtime_resource_open_directory_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_resource_open_file_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_resource_read_text_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_value_array(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_array_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_bool(ptr sret(%xiao.value) align 8, i8)
declare void @xiao_runtime_value_dict(ptr sret(%xiao.value) align 8, ptr, i32)
declare void @xiao_runtime_value_dict_owned(ptr sret(%xiao.value) align 8, ptr, i32)
declare void @xiao_runtime_value_float(ptr sret(%xiao.value) align 8, double)
declare void @xiao_runtime_value_int(ptr sret(%xiao.value) align 8, i64)
declare void @xiao_runtime_value_lfloat(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lfloat_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lint(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lint_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_none(ptr sret(%xiao.value) align 8)
declare void @xiao_runtime_value_release_any(ptr)
declare void @xiao_runtime_value_release_strong(ptr)
declare void @xiao_runtime_value_set(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_set_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_sfloat(ptr sret(%xiao.value) align 8, float)
declare void @xiao_runtime_value_sint(ptr sret(%xiao.value) align 8, i32)
declare void @xiao_runtime_value_str(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_table(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_table_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_tuple(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_tuple_owned(ptr sret(%xiao.value) align 8, ptr)

define void @xiao_entry() {
entry:
  %xiao.statement.site0 = alloca %xiao.value
  %xiao.statement.site1 = alloca %xiao.value
  %xiao.statement.site2 = alloca %xiao.value
  %xiao.statement.site3 = alloca %xiao.value
  %xiao.statement.site4 = alloca %xiao.value
  %xiao.statement.site5 = alloca %xiao.value
  %xiao.statement.site6 = alloca %xiao.value
  %xiao.statement.site7 = alloca %xiao.value
  %xiao.statement.site8 = alloca %xiao.value
  %slot1 = alloca %xiao.value
  %slot0 = alloca %xiao.value
  %t3 = alloca %xiao.bytes
  %t8 = alloca %xiao.value
  %t9 = alloca %xiao.value
  %t10 = alloca %xiao.value
  %t14 = alloca %xiao.bytes
  %t15 = alloca ptr
  %t20 = alloca %xiao.value
  %t26 = alloca %xiao.bytes
  %t27 = alloca ptr
  %t32 = alloca %xiao.value
  %t38 = alloca %xiao.bytes
  %t39 = alloca ptr
  %t44 = alloca %xiao.value
  %t47 = alloca %xiao.value
  %t51 = alloca %xiao.value
  %t54 = alloca %xiao.value
  %t55 = alloca %xiao.value
  %t56 = alloca %xiao.value
  %t60 = alloca %xiao.bytes
  %t61 = alloca ptr
  %t66 = alloca %xiao.value
  %t72 = alloca %xiao.bytes
  %t73 = alloca ptr
  %t78 = alloca %xiao.value
  %t84 = alloca %xiao.bytes
  %t85 = alloca ptr
  %t90 = alloca %xiao.value
  %t93 = alloca %xiao.value
  %t97 = alloca %xiao.value
  %t105 = alloca %xiao.bytes
  %t108 = alloca %xiao.value
  %t112 = alloca %xiao.value
  %t116 = alloca %xiao.value
  %t120 = alloca %xiao.bytes
  %t123 = alloca %xiao.value
  %t124 = alloca %xiao.bytes
  %t127 = alloca %xiao.value
  %t132 = alloca %xiao.bytes
  %t133 = alloca ptr
  %t138 = alloca %xiao.value
  %t139 = alloca %xiao.value
  %t143 = alloca %xiao.bytes
  %t144 = alloca %xiao.error.location
  %t149 = alloca %xiao.value
  %t150 = alloca %xiao.value
  %t153 = alloca %xiao.value
  %t154 = alloca %xiao.error.location
  %t158 = alloca %xiao.value
  %t160 = alloca %xiao.bytes
  %t161 = alloca ptr
  %t164 = alloca %xiao.value
  %t167 = alloca %xiao.value
  %t168 = alloca %xiao.value
  %t169 = alloca %xiao.value, i64 1
  %t173 = alloca %xiao.value
  %t175 = alloca %xiao.value
  %t176 = alloca %xiao.value
  %t179 = alloca %xiao.value
  %t180 = alloca %xiao.value
  %t181 = alloca %xiao.value
  %t185 = alloca %xiao.bytes
  %t186 = alloca ptr
  %t191 = alloca %xiao.value
  %t197 = alloca %xiao.bytes
  %t198 = alloca ptr
  %t203 = alloca %xiao.value
  %t209 = alloca %xiao.bytes
  %t210 = alloca ptr
  %t215 = alloca %xiao.value
  %t218 = alloca %xiao.value
  %t222 = alloca %xiao.value
  store %xiao.value zeroinitializer, ptr %xiao.statement.site0
  store %xiao.value zeroinitializer, ptr %xiao.statement.site1
  store %xiao.value zeroinitializer, ptr %xiao.statement.site2
  store %xiao.value zeroinitializer, ptr %xiao.statement.site3
  store %xiao.value zeroinitializer, ptr %xiao.statement.site4
  store %xiao.value zeroinitializer, ptr %xiao.statement.site5
  store %xiao.value zeroinitializer, ptr %xiao.statement.site6
  store %xiao.value zeroinitializer, ptr %xiao.statement.site7
  store %xiao.value zeroinitializer, ptr %xiao.statement.site8
  call void @xiao_runtime_error_checkpoint_reset()
  call void @xiao_runtime_error_clear()
  call void @xiao_runtime_release_trace_begin()
  store %xiao.value zeroinitializer, ptr %slot1
  store %xiao.value zeroinitializer, ptr %slot0
  %t0 = getelementptr inbounds [6 x i8], ptr @.xiao.bytes0, i64 0, i64 0
  %t1 = insertvalue %xiao.bytes zeroinitializer, ptr %t0, 0
  %t2 = insertvalue %xiao.bytes %t1, i64 5, 1
  store %xiao.bytes %t2, ptr %t3
  %t4 = call i32 @xiao_runtime_language_context_set(ptr %t3)
  %t5 = icmp eq i32 %t4, 0
  br i1 %t5, label %abi.ok0, label %abi.status.fail1
abi.status.fail1:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %xiao.error.terminal
abi.ok0:
  %t6 = call i32 @xiao_runtime_abi_is_compatible(i32 1, i32 20)
  %t7 = icmp eq i32 %t6, 1
  br i1 %t7, label %abi.entry.ok, label %abi.fail
abi.entry.ok:
  store %xiao.value zeroinitializer, ptr %t8
  store %xiao.value zeroinitializer, ptr %t9
  store %xiao.value zeroinitializer, ptr %t10
  %t11 = getelementptr inbounds [5 x i8], ptr @.xiao.str1, i64 0, i64 0
  %t12 = insertvalue %xiao.bytes zeroinitializer, ptr %t11, 0
  %t13 = insertvalue %xiao.bytes %t12, i64 4, 1
  store %xiao.bytes %t13, ptr %t14
  store ptr null, ptr %t15
  %t16 = call i32 @xiao_runtime_string_new(ptr %t14, ptr %t15)
  %t17 = icmp eq i32 %t16, 0
  br i1 %t17, label %abi.ok4, label %abi.status.fail5
abi.status.fail5:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %dynamic.call.arguments.fail2
abi.ok4:
  %t18 = load ptr, ptr %t15
  store %xiao.value zeroinitializer, ptr %t20
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t20, ptr %t18)
  %t19 = load %xiao.value, ptr %t20
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  store %xiao.value %t19, ptr %xiao.statement.site0
  %t21 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site0, ptr %t8)
  %t22 = icmp eq i32 %t21, 0
  br i1 %t22, label %abi.ok6, label %abi.status.fail7
abi.status.fail7:
  call i32 @xiao_runtime_error_attach_span(i64 53, i64 59)
  br label %dynamic.call.arguments.fail2
abi.ok6:
  %t23 = getelementptr inbounds [13 x i8], ptr @.xiao.str2, i64 0, i64 0
  %t24 = insertvalue %xiao.bytes zeroinitializer, ptr %t23, 0
  %t25 = insertvalue %xiao.bytes %t24, i64 12, 1
  store %xiao.bytes %t25, ptr %t26
  store ptr null, ptr %t27
  %t28 = call i32 @xiao_runtime_string_new(ptr %t26, ptr %t27)
  %t29 = icmp eq i32 %t28, 0
  br i1 %t29, label %abi.ok8, label %abi.status.fail9
abi.status.fail9:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %dynamic.call.arguments.fail2
abi.ok8:
  %t30 = load ptr, ptr %t27
  store %xiao.value zeroinitializer, ptr %t32
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t32, ptr %t30)
  %t31 = load %xiao.value, ptr %t32
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  store %xiao.value %t31, ptr %xiao.statement.site1
  %t33 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site1, ptr %t9)
  %t34 = icmp eq i32 %t33, 0
  br i1 %t34, label %abi.ok10, label %abi.status.fail11
abi.status.fail11:
  call i32 @xiao_runtime_error_attach_span(i64 61, i64 75)
  br label %dynamic.call.arguments.fail2
abi.ok10:
  %t35 = getelementptr inbounds [7 x i8], ptr @.xiao.str3, i64 0, i64 0
  %t36 = insertvalue %xiao.bytes zeroinitializer, ptr %t35, 0
  %t37 = insertvalue %xiao.bytes %t36, i64 6, 1
  store %xiao.bytes %t37, ptr %t38
  store ptr null, ptr %t39
  %t40 = call i32 @xiao_runtime_string_new(ptr %t38, ptr %t39)
  %t41 = icmp eq i32 %t40, 0
  br i1 %t41, label %abi.ok12, label %abi.status.fail13
abi.status.fail13:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %dynamic.call.arguments.fail2
abi.ok12:
  %t42 = load ptr, ptr %t39
  store %xiao.value zeroinitializer, ptr %t44
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t44, ptr %t42)
  %t43 = load %xiao.value, ptr %t44
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  store %xiao.value %t43, ptr %xiao.statement.site2
  %t45 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site2, ptr %t10)
  %t46 = icmp eq i32 %t45, 0
  br i1 %t46, label %abi.ok14, label %abi.status.fail15
abi.status.fail15:
  call i32 @xiao_runtime_error_attach_span(i64 77, i64 85)
  br label %dynamic.call.arguments.fail2
abi.ok14:
  br label %dynamic.call.arguments.ready3
dynamic.call.arguments.fail2:
  call void @xiao_runtime_value_release_strong(ptr %t8)
  call void @xiao_runtime_value_release_strong(ptr %t9)
  call void @xiao_runtime_value_release_strong(ptr %t10)
  br label %xiao.error.terminal
dynamic.call.arguments.ready3:
  store %xiao.value zeroinitializer, ptr %t47
  call void @xiao.fn.56e1deb30070798e(ptr %t47, ptr %t8, ptr %t9, ptr %t10)
  call void @xiao_runtime_value_release_strong(ptr %t8)
  call void @xiao_runtime_value_release_strong(ptr %t9)
  call void @xiao_runtime_value_release_strong(ptr %t10)
  %t48 = call i32 @xiao_runtime_error_class()
  %t49 = icmp eq i32 %t48, 0
  br i1 %t49, label %dynamic.call.ok16, label %dynamic.call.fail17
dynamic.call.fail17:
  br label %xiao.error.terminal
dynamic.call.ok16:
  %t50 = load %xiao.value, ptr %t47
  store %xiao.value %t50, ptr %t51
  call void @xiao_runtime_value_release_strong(ptr %t51)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  %t52 = call i32 @xiao_runtime_error_class()
  %t53 = icmp eq i32 %t52, 0
  br i1 %t53, label %abi.error.ok18, label %abi.error.fail19
abi.error.fail19:
  call i32 @xiao_runtime_error_attach_span(i64 43, i64 86)
  br label %xiao.error.terminal
abi.error.ok18:
  store %xiao.value zeroinitializer, ptr %t54
  store %xiao.value zeroinitializer, ptr %t55
  store %xiao.value zeroinitializer, ptr %t56
  %t57 = getelementptr inbounds [5 x i8], ptr @.xiao.str4, i64 0, i64 0
  %t58 = insertvalue %xiao.bytes zeroinitializer, ptr %t57, 0
  %t59 = insertvalue %xiao.bytes %t58, i64 4, 1
  store %xiao.bytes %t59, ptr %t60
  store ptr null, ptr %t61
  %t62 = call i32 @xiao_runtime_string_new(ptr %t60, ptr %t61)
  %t63 = icmp eq i32 %t62, 0
  br i1 %t63, label %abi.ok25, label %abi.status.fail26
abi.status.fail26:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %dynamic.call.arguments.fail23
abi.ok25:
  %t64 = load ptr, ptr %t61
  store %xiao.value zeroinitializer, ptr %t66
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t66, ptr %t64)
  %t65 = load %xiao.value, ptr %t66
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site3)
  store %xiao.value %t65, ptr %xiao.statement.site3
  %t67 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site3, ptr %t54)
  %t68 = icmp eq i32 %t67, 0
  br i1 %t68, label %abi.ok27, label %abi.status.fail28
abi.status.fail28:
  call i32 @xiao_runtime_error_attach_span(i64 105, i64 111)
  br label %dynamic.call.arguments.fail23
abi.ok27:
  %t69 = getelementptr inbounds [10 x i8], ptr @.xiao.str5, i64 0, i64 0
  %t70 = insertvalue %xiao.bytes zeroinitializer, ptr %t69, 0
  %t71 = insertvalue %xiao.bytes %t70, i64 9, 1
  store %xiao.bytes %t71, ptr %t72
  store ptr null, ptr %t73
  %t74 = call i32 @xiao_runtime_string_new(ptr %t72, ptr %t73)
  %t75 = icmp eq i32 %t74, 0
  br i1 %t75, label %abi.ok29, label %abi.status.fail30
abi.status.fail30:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %dynamic.call.arguments.fail23
abi.ok29:
  %t76 = load ptr, ptr %t73
  store %xiao.value zeroinitializer, ptr %t78
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t78, ptr %t76)
  %t77 = load %xiao.value, ptr %t78
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site4)
  store %xiao.value %t77, ptr %xiao.statement.site4
  %t79 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site4, ptr %t55)
  %t80 = icmp eq i32 %t79, 0
  br i1 %t80, label %abi.ok31, label %abi.status.fail32
abi.status.fail32:
  call i32 @xiao_runtime_error_attach_span(i64 113, i64 125)
  br label %dynamic.call.arguments.fail23
abi.ok31:
  %t81 = getelementptr inbounds [7 x i8], ptr @.xiao.str6, i64 0, i64 0
  %t82 = insertvalue %xiao.bytes zeroinitializer, ptr %t81, 0
  %t83 = insertvalue %xiao.bytes %t82, i64 6, 1
  store %xiao.bytes %t83, ptr %t84
  store ptr null, ptr %t85
  %t86 = call i32 @xiao_runtime_string_new(ptr %t84, ptr %t85)
  %t87 = icmp eq i32 %t86, 0
  br i1 %t87, label %abi.ok33, label %abi.status.fail34
abi.status.fail34:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %dynamic.call.arguments.fail23
abi.ok33:
  %t88 = load ptr, ptr %t85
  store %xiao.value zeroinitializer, ptr %t90
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t90, ptr %t88)
  %t89 = load %xiao.value, ptr %t90
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site5)
  store %xiao.value %t89, ptr %xiao.statement.site5
  %t91 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site5, ptr %t56)
  %t92 = icmp eq i32 %t91, 0
  br i1 %t92, label %abi.ok35, label %abi.status.fail36
abi.status.fail36:
  call i32 @xiao_runtime_error_attach_span(i64 127, i64 135)
  br label %dynamic.call.arguments.fail23
abi.ok35:
  br label %dynamic.call.arguments.ready24
dynamic.call.arguments.fail23:
  call void @xiao_runtime_value_release_strong(ptr %t54)
  call void @xiao_runtime_value_release_strong(ptr %t55)
  call void @xiao_runtime_value_release_strong(ptr %t56)
  br label %dynamic.try.dispatch20
dynamic.call.arguments.ready24:
  store %xiao.value zeroinitializer, ptr %t93
  call void @xiao.fn.56e1deb30070798e(ptr %t93, ptr %t54, ptr %t55, ptr %t56)
  call void @xiao_runtime_value_release_strong(ptr %t54)
  call void @xiao_runtime_value_release_strong(ptr %t55)
  call void @xiao_runtime_value_release_strong(ptr %t56)
  %t94 = call i32 @xiao_runtime_error_class()
  %t95 = icmp eq i32 %t94, 0
  br i1 %t95, label %dynamic.call.ok37, label %dynamic.call.fail38
dynamic.call.fail38:
  br label %dynamic.try.dispatch20
dynamic.call.ok37:
  %t96 = load %xiao.value, ptr %t93
  store %xiao.value %t96, ptr %t97
  call void @xiao_runtime_value_release_strong(ptr %t97)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site3)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site4)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site5)
  %t98 = call i32 @xiao_runtime_error_class()
  %t99 = icmp eq i32 %t98, 0
  br i1 %t99, label %abi.error.ok39, label %abi.error.fail40
abi.error.fail40:
  call i32 @xiao_runtime_error_attach_span(i64 95, i64 136)
  br label %dynamic.try.dispatch20
abi.error.ok39:
  br label %dynamic.try.normal21
dynamic.try.normal21:
  br label %dynamic.try.continue22
dynamic.try.dispatch20:
  %t100 = call i32 @xiao_runtime_error_class()
  %t101 = icmp eq i32 %t100, 2
  br i1 %t101, label %xiao.error.terminal, label %dynamic.try.recoverable41
dynamic.try.recoverable41:
  %t102 = getelementptr inbounds [10 x i8], ptr @.xiao.bytes7, i64 0, i64 0
  %t103 = insertvalue %xiao.bytes zeroinitializer, ptr %t102, 0
  %t104 = insertvalue %xiao.bytes %t103, i64 9, 1
  store %xiao.bytes %t104, ptr %t105
  %t106 = call i32 @xiao_runtime_error_matches(ptr %t105)
  %t107 = icmp eq i32 %t106, 1
  br i1 %t107, label %dynamic.try.catch043, label %dynamic.try.unmatched42
dynamic.try.unmatched42:
  br label %xiao.error.terminal
dynamic.try.catch043:
  br label %dynamic.try.catch0.body44
dynamic.try.catch0.body44:
  store %xiao.value zeroinitializer, ptr %t108
  %t109 = call i32 @xiao_runtime_error_take(ptr %t108)
  %t110 = icmp eq i32 %t109, 0
  br i1 %t110, label %abi.ok45, label %abi.status.fail46
abi.status.fail46:
  call i32 @xiao_runtime_error_attach_span(i64 137, i64 195)
  br label %xiao.error.terminal
abi.ok45:
  %t111 = load %xiao.value, ptr %t108
  call void @xiao_runtime_value_release_strong(ptr %slot1)
  store %xiao.value %t111, ptr %slot1
  store %xiao.value zeroinitializer, ptr %t112
  %t113 = call i32 @xiao_runtime_value_copy(ptr %slot1, ptr %t112)
  %t114 = icmp eq i32 %t113, 0
  br i1 %t114, label %abi.ok48, label %abi.status.fail49
abi.status.fail49:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %dynamic.try.catch0.fail47
abi.ok48:
  %t115 = load %xiao.value, ptr %t112
  store %xiao.value %t115, ptr %t116
  %t117 = getelementptr inbounds [12 x i8], ptr @.xiao.bytes8, i64 0, i64 0
  %t118 = insertvalue %xiao.bytes zeroinitializer, ptr %t117, 0
  %t119 = insertvalue %xiao.bytes %t118, i64 11, 1
  store %xiao.bytes %t119, ptr %t120
  %t121 = call i32 @xiao_runtime_dynamic_check(ptr %t120, ptr %t116)
  %t122 = icmp eq i32 %t121, 0
  br i1 %t122, label %error.code.operation.ok50, label %error.code.operation.fail51
error.code.operation.fail51:
  store %xiao.value %t115, ptr %t123
  call void @xiao_runtime_value_release_strong(ptr %t123)
  call i32 @xiao_runtime_error_attach_span(i64 174, i64 193)
  br label %dynamic.try.catch0.fail47
error.code.operation.ok50:
  store %xiao.bytes zeroinitializer, ptr %t124
  %t125 = call i32 @xiao_runtime_error_code(ptr %t116, ptr %t124)
  %t126 = icmp eq i32 %t125, 0
  br i1 %t126, label %error.code.view.ok52, label %error.code.view.fail53
error.code.view.fail53:
  store %xiao.value %t115, ptr %t127
  call void @xiao_runtime_value_release_strong(ptr %t127)
  %t128 = icmp eq i32 %t125, 3
  br i1 %t128, label %error.code.invalid.handle54, label %error.code.invalid.abi55
error.code.invalid.abi55:
  call void @xiao_runtime_fatal_abi()
  unreachable
error.code.invalid.handle54:
  %t129 = getelementptr inbounds [16 x i8], ptr @.xiao.str9, i64 0, i64 0
  %t130 = insertvalue %xiao.bytes zeroinitializer, ptr %t129, 0
  %t131 = insertvalue %xiao.bytes %t130, i64 15, 1
  store %xiao.bytes %t131, ptr %t132
  store ptr null, ptr %t133
  %t134 = call i32 @xiao_runtime_string_new(ptr %t132, ptr %t133)
  %t135 = icmp eq i32 %t134, 0
  br i1 %t135, label %abi.ok56, label %abi.status.fail57
abi.status.fail57:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %dynamic.try.catch0.fail47
abi.ok56:
  %t136 = load ptr, ptr %t133
  store %xiao.value zeroinitializer, ptr %t138
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t138, ptr %t136)
  %t137 = load %xiao.value, ptr %t138
  store %xiao.value %t137, ptr %t139
  %t140 = getelementptr inbounds [12 x i8], ptr @.xiao.bytes10, i64 0, i64 0
  %t141 = insertvalue %xiao.bytes zeroinitializer, ptr %t140, 0
  %t142 = insertvalue %xiao.bytes %t141, i64 11, 1
  store %xiao.bytes %t142, ptr %t143
  %t145 = insertvalue %xiao.error.location zeroinitializer, i64 174, 0
  %t146 = insertvalue %xiao.error.location %t145, i64 193, 1
  %t147 = insertvalue %xiao.error.location %t146, i8 1, 2
  store %xiao.error.location %t147, ptr %t144
  store %xiao.value zeroinitializer, ptr %t149
  call void @xiao_runtime_error_new_values(ptr sret(%xiao.value) %t149, ptr %t143, ptr %t139, ptr null, ptr %t144)
  %t148 = load %xiao.value, ptr %t149
  store %xiao.value %t137, ptr %t150
  call void @xiao_runtime_value_release_strong(ptr %t150)
  %t151 = call i32 @xiao_runtime_error_class()
  %t152 = icmp eq i32 %t151, 0
  br i1 %t152, label %abi.error.ok58, label %abi.error.fail59
abi.error.fail59:
  call i32 @xiao_runtime_error_attach_span(i64 174, i64 193)
  br label %dynamic.try.catch0.fail47
abi.error.ok58:
  store %xiao.value %t148, ptr %t153
  %t155 = insertvalue %xiao.error.location zeroinitializer, i64 174, 0
  %t156 = insertvalue %xiao.error.location %t155, i64 193, 1
  %t157 = insertvalue %xiao.error.location %t156, i8 1, 2
  store %xiao.error.location %t157, ptr %t154
  call i32 @xiao_runtime_error_raise_value(ptr %t153, ptr %t154)
  store %xiao.value %t148, ptr %t158
  call void @xiao_runtime_value_release_strong(ptr %t158)
  br label %dynamic.try.catch0.fail47
error.code.view.ok52:
  %t159 = load %xiao.bytes, ptr %t124
  store %xiao.bytes %t159, ptr %t160
  store ptr null, ptr %t161
  %t162 = call i32 @xiao_runtime_string_new(ptr %t160, ptr %t161)
  %t163 = icmp eq i32 %t162, 0
  br i1 %t163, label %error.code.operation.ok60, label %error.code.operation.fail61
error.code.operation.fail61:
  store %xiao.value %t115, ptr %t164
  call void @xiao_runtime_value_release_strong(ptr %t164)
  call i32 @xiao_runtime_error_attach_span(i64 174, i64 193)
  br label %dynamic.try.catch0.fail47
error.code.operation.ok60:
  %t165 = load ptr, ptr %t161
  store %xiao.value zeroinitializer, ptr %t167
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t167, ptr %t165)
  %t166 = load %xiao.value, ptr %t167
  store %xiao.value %t115, ptr %t168
  call void @xiao_runtime_value_release_strong(ptr %t168)
  %t170 = getelementptr inbounds %xiao.value, ptr %t169, i64 0
  store %xiao.value %t166, ptr %t170
  %t171 = call i32 @xiao_runtime_print_values_with_capabilities(ptr %t169, i64 1, i64 34)
  %t172 = icmp eq i32 %t171, 0
  br i1 %t172, label %abi.ok62, label %abi.status.fail63
abi.status.fail63:
  call i32 @xiao_runtime_error_attach_span(i64 168, i64 194)
  br label %dynamic.try.catch0.fail47
abi.ok62:
  store %xiao.value %t166, ptr %t173
  call void @xiao_runtime_value_release_strong(ptr %t173)
  store %xiao.value zeroinitializer, ptr %t175
  call void @xiao_runtime_value_none(ptr sret(%xiao.value) %t175)
  %t174 = load %xiao.value, ptr %t175
  store %xiao.value %t174, ptr %t176
  call void @xiao_runtime_value_release_strong(ptr %t176)
  call void @xiao_runtime_value_release_strong(ptr %slot1)
  br label %dynamic.try.continue22
dynamic.try.catch0.fail47:
  %t177 = call i32 @xiao_runtime_error_class()
  %t178 = icmp eq i32 %t177, 2
  br i1 %t178, label %xiao.error.terminal, label %dynamic.error-cleanup.recoverable64
dynamic.error-cleanup.recoverable64:
  call void @xiao_runtime_value_release_strong(ptr %slot1)
  br label %xiao.error.terminal
dynamic.try.continue22:
  store %xiao.value zeroinitializer, ptr %t179
  store %xiao.value zeroinitializer, ptr %t180
  store %xiao.value zeroinitializer, ptr %t181
  %t182 = getelementptr inbounds [6 x i8], ptr @.xiao.str11, i64 0, i64 0
  %t183 = insertvalue %xiao.bytes zeroinitializer, ptr %t182, 0
  %t184 = insertvalue %xiao.bytes %t183, i64 5, 1
  store %xiao.bytes %t184, ptr %t185
  store ptr null, ptr %t186
  %t187 = call i32 @xiao_runtime_string_new(ptr %t185, ptr %t186)
  %t188 = icmp eq i32 %t187, 0
  br i1 %t188, label %abi.ok67, label %abi.status.fail68
abi.status.fail68:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %dynamic.call.arguments.fail65
abi.ok67:
  %t189 = load ptr, ptr %t186
  store %xiao.value zeroinitializer, ptr %t191
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t191, ptr %t189)
  %t190 = load %xiao.value, ptr %t191
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site6)
  store %xiao.value %t190, ptr %xiao.statement.site6
  %t192 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site6, ptr %t179)
  %t193 = icmp eq i32 %t192, 0
  br i1 %t193, label %abi.ok69, label %abi.status.fail70
abi.status.fail70:
  call i32 @xiao_runtime_error_attach_span(i64 213, i64 220)
  br label %dynamic.call.arguments.fail65
abi.ok69:
  %t194 = getelementptr inbounds [13 x i8], ptr @.xiao.str12, i64 0, i64 0
  %t195 = insertvalue %xiao.bytes zeroinitializer, ptr %t194, 0
  %t196 = insertvalue %xiao.bytes %t195, i64 12, 1
  store %xiao.bytes %t196, ptr %t197
  store ptr null, ptr %t198
  %t199 = call i32 @xiao_runtime_string_new(ptr %t197, ptr %t198)
  %t200 = icmp eq i32 %t199, 0
  br i1 %t200, label %abi.ok71, label %abi.status.fail72
abi.status.fail72:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %dynamic.call.arguments.fail65
abi.ok71:
  %t201 = load ptr, ptr %t198
  store %xiao.value zeroinitializer, ptr %t203
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t203, ptr %t201)
  %t202 = load %xiao.value, ptr %t203
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site7)
  store %xiao.value %t202, ptr %xiao.statement.site7
  %t204 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site7, ptr %t180)
  %t205 = icmp eq i32 %t204, 0
  br i1 %t205, label %abi.ok73, label %abi.status.fail74
abi.status.fail74:
  call i32 @xiao_runtime_error_attach_span(i64 232, i64 246)
  br label %dynamic.call.arguments.fail65
abi.ok73:
  %t206 = getelementptr inbounds [7 x i8], ptr @.xiao.str13, i64 0, i64 0
  %t207 = insertvalue %xiao.bytes zeroinitializer, ptr %t206, 0
  %t208 = insertvalue %xiao.bytes %t207, i64 6, 1
  store %xiao.bytes %t208, ptr %t209
  store ptr null, ptr %t210
  %t211 = call i32 @xiao_runtime_string_new(ptr %t209, ptr %t210)
  %t212 = icmp eq i32 %t211, 0
  br i1 %t212, label %abi.ok75, label %abi.status.fail76
abi.status.fail76:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %dynamic.call.arguments.fail65
abi.ok75:
  %t213 = load ptr, ptr %t210
  store %xiao.value zeroinitializer, ptr %t215
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t215, ptr %t213)
  %t214 = load %xiao.value, ptr %t215
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site8)
  store %xiao.value %t214, ptr %xiao.statement.site8
  %t216 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site8, ptr %t181)
  %t217 = icmp eq i32 %t216, 0
  br i1 %t217, label %abi.ok77, label %abi.status.fail78
abi.status.fail78:
  call i32 @xiao_runtime_error_attach_span(i64 257, i64 265)
  br label %dynamic.call.arguments.fail65
abi.ok77:
  br label %dynamic.call.arguments.ready66
dynamic.call.arguments.fail65:
  call void @xiao_runtime_value_release_strong(ptr %t179)
  call void @xiao_runtime_value_release_strong(ptr %t180)
  call void @xiao_runtime_value_release_strong(ptr %t181)
  br label %xiao.error.terminal
dynamic.call.arguments.ready66:
  store %xiao.value zeroinitializer, ptr %t218
  call void @xiao.fn.56e1deb30070798e(ptr %t218, ptr %t179, ptr %t180, ptr %t181)
  call void @xiao_runtime_value_release_strong(ptr %t179)
  call void @xiao_runtime_value_release_strong(ptr %t180)
  call void @xiao_runtime_value_release_strong(ptr %t181)
  %t219 = call i32 @xiao_runtime_error_class()
  %t220 = icmp eq i32 %t219, 0
  br i1 %t220, label %dynamic.call.ok79, label %dynamic.call.fail80
dynamic.call.fail80:
  br label %xiao.error.terminal
dynamic.call.ok79:
  %t221 = load %xiao.value, ptr %t218
  store %xiao.value %t221, ptr %t222
  call void @xiao_runtime_value_release_strong(ptr %t222)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site6)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site7)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site8)
  %t223 = call i32 @xiao_runtime_error_class()
  %t224 = icmp eq i32 %t223, 0
  br i1 %t224, label %abi.error.ok81, label %abi.error.fail82
abi.error.fail82:
  call i32 @xiao_runtime_error_attach_span(i64 195, i64 266)
  br label %xiao.error.terminal
abi.error.ok81:
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site3)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site4)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site5)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site6)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site7)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site8)
  %t225 = call i32 @xiao_runtime_error_class()
  %t226 = icmp eq i32 %t225, 0
  br i1 %t226, label %abi.ok83, label %abi.status.fail84
abi.status.fail84:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %xiao.error.terminal
abi.ok83:
  call void @xiao_runtime_release_trace_flush()
  ret void
xiao.error.terminal:
  %t227 = call i32 @xiao_runtime_error_class()
  %t228 = icmp eq i32 %t227, 2
  br i1 %t228, label %xiao.error.report85, label %xiao.error.unmatched86
xiao.error.unmatched86:
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site3)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site4)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site5)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site6)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site7)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site8)
  br label %xiao.error.report85
xiao.error.report85:
  call void @xiao_runtime_error_report()
  call void @xiao_runtime_release_trace_flush()
  %t229 = call i32 @xiao_runtime_error_exit_code()
  ret void
abi.fail:
  call void @xiao_runtime_fatal_abi()
  unreachable
}

define internal i32 @xiao_application_main() {
entry:
  call void @xiao_entry()
  %xiao_exit_code = call i32 @xiao_runtime_error_exit_code()
  ret i32 %xiao_exit_code
}

define i32 @main() {
entry:
  %status = call i32 @xiao_runtime_env_run_native(ptr @xiao_application_main, i64 34, i32 0)
  ret i32 %status
}

define void @xiao.fn.56e1deb30070798e(ptr %xiao.function.result, ptr %xiao.arg0, ptr %xiao.arg1, ptr %xiao.arg2) {
entry:
  %xiao.return.source = alloca ptr
  %xiao.return.temporary = alloca i1
  %slot0 = alloca %xiao.value
  %slot1 = alloca %xiao.value
  %slot2 = alloca %xiao.value
  %t9 = alloca %xiao.value
  %t10 = alloca %xiao.value
  %t11 = alloca %xiao.value
  %t12 = alloca %xiao.value
  %t16 = alloca %xiao.value
  %t20 = alloca %xiao.value
  %t25 = alloca %xiao.value
  %t27 = alloca %xiao.value
  %t37 = alloca %xiao.bytes
  %t41 = alloca %xiao.bytes
  store ptr null, ptr %xiao.return.source
  store i1 false, ptr %xiao.return.temporary
  store %xiao.value zeroinitializer, ptr %slot0
  store %xiao.value zeroinitializer, ptr %slot1
  store %xiao.value zeroinitializer, ptr %slot2
  %t0 = call i32 @xiao_runtime_value_copy(ptr %xiao.arg0, ptr %slot0)
  %t1 = icmp eq i32 %t0, 0
  br i1 %t1, label %abi.ok0, label %abi.status.fail1
abi.status.fail1:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %xiao.fn.error
abi.ok0:
  %t2 = call i32 @xiao_runtime_value_copy(ptr %xiao.arg1, ptr %slot1)
  %t3 = icmp eq i32 %t2, 0
  br i1 %t3, label %abi.ok2, label %abi.status.fail3
abi.status.fail3:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %xiao.fn.error
abi.ok2:
  %t4 = call i32 @xiao_runtime_value_copy(ptr %xiao.arg2, ptr %slot2)
  %t5 = icmp eq i32 %t4, 0
  br i1 %t5, label %abi.ok4, label %abi.status.fail5
abi.status.fail5:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %xiao.fn.error
abi.ok4:
  %t6 = load %xiao.value, ptr %slot0
  %t7 = load %xiao.value, ptr %slot1
  %t8 = load %xiao.value, ptr %slot2
  store %xiao.value zeroinitializer, ptr %t9
  store %xiao.value zeroinitializer, ptr %t10
  store %xiao.value zeroinitializer, ptr %t11
  store %xiao.value zeroinitializer, ptr %t12
  %t13 = call i32 @xiao_runtime_value_copy(ptr %slot0, ptr %t12)
  %t14 = icmp eq i32 %t13, 0
  br i1 %t14, label %abi.ok8, label %abi.status.fail9
abi.status.fail9:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %log.arguments.fail6
abi.ok8:
  %t15 = load %xiao.value, ptr %t12
  store %xiao.value %t15, ptr %t9
  store %xiao.value zeroinitializer, ptr %t16
  %t17 = call i32 @xiao_runtime_value_copy(ptr %slot1, ptr %t16)
  %t18 = icmp eq i32 %t17, 0
  br i1 %t18, label %abi.ok10, label %abi.status.fail11
abi.status.fail11:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %log.arguments.fail6
abi.ok10:
  %t19 = load %xiao.value, ptr %t16
  store %xiao.value %t19, ptr %t10
  store %xiao.value zeroinitializer, ptr %t20
  %t21 = call i32 @xiao_runtime_value_copy(ptr %slot2, ptr %t20)
  %t22 = icmp eq i32 %t21, 0
  br i1 %t22, label %abi.ok12, label %abi.status.fail13
abi.status.fail13:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 267)
  br label %log.arguments.fail6
abi.ok12:
  %t23 = load %xiao.value, ptr %t20
  store %xiao.value %t23, ptr %t11
  br label %log.arguments.ready7
log.arguments.fail6:
  call void @xiao_runtime_value_release_strong(ptr %t11)
  call void @xiao_runtime_value_release_strong(ptr %t10)
  call void @xiao_runtime_value_release_strong(ptr %t9)
  br label %xiao.fn.error
log.arguments.ready7:
  %t24 = call i32 @xiao_runtime_log_write(ptr %t9, ptr %t10, ptr %t11, i64 34)
  call void @xiao_runtime_value_release_strong(ptr %t11)
  call void @xiao_runtime_value_release_strong(ptr %t10)
  call void @xiao_runtime_value_release_strong(ptr %t9)
  switch i32 %t24, label %log.abi.failure16 [ i32 0, label %log.ok14 i32 6, label %log.error15 i32 8, label %log.error15 ]
log.abi.failure16:
  call void @xiao_runtime_fatal_abi()
  unreachable
log.error15:
  call i32 @xiao_runtime_error_attach_span(i64 58, i64 94)
  br label %xiao.fn.error
log.ok14:
  store %xiao.value zeroinitializer, ptr %t25
  call void @xiao_runtime_value_release_strong(ptr %t25)
  store ptr null, ptr %xiao.return.source
  store %xiao.value zeroinitializer, ptr %t27
  call void @xiao_runtime_value_none(ptr sret(%xiao.value) %t27)
  %t26 = load %xiao.value, ptr %t27
  store %xiao.value %t26, ptr %xiao.function.result
  br label %xiao.fn.return
xiao.fn.return:
  call void @xiao_runtime_value_release_strong(ptr %slot2)
  call void @xiao_runtime_value_release_strong(ptr %slot1)
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  %t28 = call i32 @xiao_runtime_error_class()
  %t29 = icmp eq i32 %t28, 0
  br i1 %t29, label %abi.ok17, label %abi.status.fail18
abi.status.fail18:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 95)
  br label %xiao.fn.error
abi.ok17:
  br label %xiao.fn.return.cleanup
xiao.fn.return.cleanup:
  %t30 = call i32 @xiao_runtime_error_class()
  %t31 = icmp eq i32 %t30, 0
  br i1 %t31, label %abi.ok19, label %abi.status.fail20
abi.status.fail20:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 95)
  br label %xiao.fn.error
abi.ok19:
  ret void
xiao.fn.error:
  %t32 = call i32 @xiao_runtime_error_class()
  %t33 = icmp eq i32 %t32, 2
  br i1 %t33, label %xiao.fn.error.return, label %xiao.fn.error.cleanup
xiao.fn.error.cleanup:
  call void @xiao_runtime_value_release_strong(ptr %slot2)
  call void @xiao_runtime_value_release_strong(ptr %slot1)
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.function.result)
  br label %xiao.fn.error.return
xiao.fn.error.return:
  %t34 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes14, i64 0, i64 0
  %t35 = insertvalue %xiao.bytes zeroinitializer, ptr %t34, 0
  %t36 = insertvalue %xiao.bytes %t35, i64 10, 1
  store %xiao.bytes %t36, ptr %t37
  %t38 = getelementptr inbounds [6 x i8], ptr @.xiao.bytes15, i64 0, i64 0
  %t39 = insertvalue %xiao.bytes zeroinitializer, ptr %t38, 0
  %t40 = insertvalue %xiao.bytes %t39, i64 5, 1
  store %xiao.bytes %t40, ptr %t41
  call void @xiao_runtime_error_push_native_frame(ptr %t37, ptr %t41, i64 0, i64 95)
  store %xiao.value zeroinitializer, ptr %xiao.function.result
  ret void
}


@xiao_native_metadata = constant [107 x i8] c"\58\49\41\4F\4D\45\54\41\01\00\00\00\6B\00\00\00\14\00\01\00\00\00\00\00\14\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\1B\00\00\00\40\00\00\00\01\00\00\00\14\00\01\00\00\00\00\00\16\00\00\00\78\38\36\5F\36\34\2D\70\63\2D\77\69\6E\64\6F\77\73\2D\6D\73\76\63\05\00\00\00\30\2E\31\2E\30\08\00\00\00\70\6F\72\74\61\62\6C\65", section ".xiaomta", align 4
@llvm.used = appending global [1 x ptr] [ptr @xiao_native_metadata], section "llvm.metadata"
