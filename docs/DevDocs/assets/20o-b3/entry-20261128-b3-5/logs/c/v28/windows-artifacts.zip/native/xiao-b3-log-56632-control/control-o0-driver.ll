; Xiao N0-B LLVM dynamic module
; target = x86_64-pc-windows-msvc
target triple = "x86_64-pc-windows-msvc"

%xiao.value = type { i32, i64 }
%xiao.bytes = type { ptr, i64 }

%xiao.table.field = type { %xiao.bytes, i32, i8 }
%xiao.table.descriptor = type { %xiao.bytes, i32, ptr, i64 }

%xiao.table.method = type { %xiao.bytes, i64, ptr, i64, i32, i8, ptr }
%xiao.table.descriptor.v2 = type { i32, i32, %xiao.table.descriptor, ptr, i64, ptr, ptr, ptr }

%xiao.error.location = type { i64, i64, i8, [7 x i8] }

; xiao.source-map statement 0..41
; xiao.source-map while 42..126
; xiao.source-map statement 57..80
; xiao.source-map statement 85..125
@.xiao.bytes0 = private unnamed_addr constant [6 x i8] c"zh-CN\00"
@.xiao.str1 = private unnamed_addr constant [5 x i8] c"info\00"
@.xiao.str2 = private unnamed_addr constant [8 x i8] c"entered\00"
@.xiao.str3 = private unnamed_addr constant [7 x i8] c"stdout\00"
@.xiao.str4 = private unnamed_addr constant [3 x i8] c"ms\00"
@.xiao.str5 = private unnamed_addr constant [5 x i8] c"info\00"
@.xiao.str6 = private unnamed_addr constant [7 x i8] c"active\00"
@.xiao.str7 = private unnamed_addr constant [7 x i8] c"stdout\00"

declare i32 @xiao_runtime_abi_is_compatible(i32, i32)
declare i32 @xiao_runtime_array_new(ptr, i64, ptr)
declare i32 @xiao_runtime_array_push(ptr, ptr)
declare i32 @xiao_runtime_concurrency_call(ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_concurrency_call_with_entry(ptr, ptr, ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_concurrency_cancellation_check(ptr)
declare i32 @xiao_runtime_concurrency_finish()
declare i32 @xiao_runtime_dict_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_dict_new(i32, ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_dynamic_check(ptr, ptr)
declare i32 @xiao_runtime_dynamic_member_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_env_run_native(ptr, i64, i32)
declare i32 @xiao_runtime_error_attach_span(i64, i64)
declare i32 @xiao_runtime_error_checkpoint_finish()
declare i32 @xiao_runtime_error_class()
declare i32 @xiao_runtime_error_code(ptr, ptr)
declare i32 @xiao_runtime_error_exit_code()
declare i32 @xiao_runtime_error_matches(ptr)
declare i32 @xiao_runtime_error_raise_value(ptr, ptr)
declare i32 @xiao_runtime_error_take(ptr)
declare i32 @xiao_runtime_language_context_set(ptr)
declare i32 @xiao_runtime_lfloat_divide(ptr, ptr, ptr, ptr, ptr)
declare i32 @xiao_runtime_log_write(ptr, ptr, ptr, i64)
declare i32 @xiao_runtime_print_values_with_capabilities(ptr, i64, i64)
declare i32 @xiao_runtime_process_close_with_capabilities(ptr, i64)
declare i32 @xiao_runtime_random_seed(ptr)
declare i32 @xiao_runtime_resource_close_with_capabilities(ptr, i64)
declare i32 @xiao_runtime_set_add(ptr, ptr)
declare i32 @xiao_runtime_set_new(ptr, i64, ptr)
declare i32 @xiao_runtime_set_remove(ptr, ptr, ptr)
declare i32 @xiao_runtime_string_new(ptr, ptr)
declare i32 @xiao_runtime_table_call(ptr, ptr, i64, ptr, i64, ptr)
declare i32 @xiao_runtime_table_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_get_value(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_new(ptr, ptr)
declare i32 @xiao_runtime_table_new_v2(ptr, ptr)
declare i32 @xiao_runtime_table_new_v2_with_args(ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_table_set(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_set_value(ptr, ptr, ptr)
declare i32 @xiao_runtime_time_sleep(ptr, ptr, i64)
declare i32 @xiao_runtime_tuple_new(ptr, i64, ptr)
declare i32 @xiao_runtime_value_binary(ptr, ptr, ptr, ptr)
declare i32 @xiao_runtime_value_cast(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_chr(ptr, ptr)
declare i32 @xiao_runtime_value_copy(ptr, ptr)
declare i32 @xiao_runtime_value_dict_keys(ptr, ptr)
declare i32 @xiao_runtime_value_dict_remove_dynamic(ptr, ptr)
declare i32 @xiao_runtime_value_dict_values(ptr, ptr)
declare i32 @xiao_runtime_value_index_get_dynamic(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_index_set_dynamic(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_iter_get(ptr, i64, ptr)
declare i32 @xiao_runtime_value_iter_len(ptr, ptr)
declare i32 @xiao_runtime_value_iter_snapshot(ptr, ptr)
declare i32 @xiao_runtime_value_release_weak(ptr)
declare i32 @xiao_runtime_value_select(ptr, i64, ptr, ptr)
declare i32 @xiao_runtime_value_unary(ptr, ptr, ptr)
declare ptr @llvm.stacksave()
declare void @llvm.stackrestore(ptr)
declare void @llvm.trap()
declare void @xiao_runtime_concurrency_entry_begin()
declare void @xiao_runtime_error_checkpoint_begin()
declare void @xiao_runtime_error_checkpoint_discard()
declare void @xiao_runtime_error_checkpoint_reset()
declare void @xiao_runtime_error_clear()
declare void @xiao_runtime_error_new(ptr sret(%xiao.value) align 8, ptr, ptr, ptr, ptr)
declare void @xiao_runtime_error_new_values(ptr sret(%xiao.value) align 8, ptr, ptr, ptr, ptr)
declare void @xiao_runtime_error_push_native_frame(ptr, ptr, i64, i64)
declare void @xiao_runtime_error_report()
declare void @xiao_runtime_fatal_abi()
declare void @xiao_runtime_input_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i8, i64)
declare void @xiao_runtime_process_spawn_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_process_wait_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_release(ptr)
declare void @xiao_runtime_release_trace_begin()
declare void @xiao_runtime_release_trace_flush()
declare void @xiao_runtime_resource_open_directory_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_resource_open_file_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_resource_read_text_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_value_array(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_array_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_bool(ptr sret(%xiao.value) align 8, i8)
declare void @xiao_runtime_value_dict(ptr sret(%xiao.value) align 8, ptr, i32)
declare void @xiao_runtime_value_dict_owned(ptr sret(%xiao.value) align 8, ptr, i32)
declare void @xiao_runtime_value_float(ptr sret(%xiao.value) align 8, double)
declare void @xiao_runtime_value_int(ptr sret(%xiao.value) align 8, i64)
declare void @xiao_runtime_value_lfloat(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lfloat_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lint(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lint_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_none(ptr sret(%xiao.value) align 8)
declare void @xiao_runtime_value_release_any(ptr)
declare void @xiao_runtime_value_release_strong(ptr)
declare void @xiao_runtime_value_set(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_set_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_sfloat(ptr sret(%xiao.value) align 8, float)
declare void @xiao_runtime_value_sint(ptr sret(%xiao.value) align 8, i32)
declare void @xiao_runtime_value_str(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_table(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_table_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_tuple(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_tuple_owned(ptr sret(%xiao.value) align 8, ptr)

define void @xiao_entry() {
entry:
  %xiao.statement.site0 = alloca %xiao.value
  %xiao.statement.site1 = alloca %xiao.value
  %xiao.statement.site2 = alloca %xiao.value
  %xiao.statement.site3 = alloca %xiao.value
  %xiao.statement.site4 = alloca %xiao.value
  %xiao.statement.site5 = alloca %xiao.value
  %xiao.statement.site6 = alloca %xiao.value
  %t3 = alloca %xiao.bytes
  %t8 = alloca %xiao.value
  %t9 = alloca %xiao.value
  %t10 = alloca %xiao.value
  %t14 = alloca %xiao.bytes
  %t15 = alloca ptr
  %t20 = alloca %xiao.value
  %t26 = alloca %xiao.bytes
  %t27 = alloca ptr
  %t32 = alloca %xiao.value
  %t38 = alloca %xiao.bytes
  %t39 = alloca ptr
  %t44 = alloca %xiao.value
  %t48 = alloca %xiao.value
  %t52 = alloca %xiao.value
  %t57 = alloca %xiao.value
  %t58 = alloca %xiao.value
  %t59 = alloca %xiao.value
  %t61 = alloca %xiao.value
  %t65 = alloca %xiao.bytes
  %t66 = alloca ptr
  %t71 = alloca %xiao.value
  %t75 = alloca %xiao.value
  %t78 = alloca %xiao.value
  %t79 = alloca %xiao.value
  %t80 = alloca %xiao.value
  %t84 = alloca %xiao.bytes
  %t85 = alloca ptr
  %t90 = alloca %xiao.value
  %t96 = alloca %xiao.bytes
  %t97 = alloca ptr
  %t102 = alloca %xiao.value
  %t108 = alloca %xiao.bytes
  %t109 = alloca ptr
  %t114 = alloca %xiao.value
  %t118 = alloca %xiao.value
  store %xiao.value zeroinitializer, ptr %xiao.statement.site0
  store %xiao.value zeroinitializer, ptr %xiao.statement.site1
  store %xiao.value zeroinitializer, ptr %xiao.statement.site2
  store %xiao.value zeroinitializer, ptr %xiao.statement.site3
  store %xiao.value zeroinitializer, ptr %xiao.statement.site4
  store %xiao.value zeroinitializer, ptr %xiao.statement.site5
  store %xiao.value zeroinitializer, ptr %xiao.statement.site6
  call void @xiao_runtime_error_checkpoint_reset()
  call void @xiao_runtime_error_clear()
  call void @xiao_runtime_release_trace_begin()
  %t0 = getelementptr inbounds [6 x i8], ptr @.xiao.bytes0, i64 0, i64 0
  %t1 = insertvalue %xiao.bytes zeroinitializer, ptr %t0, 0
  %t2 = insertvalue %xiao.bytes %t1, i64 5, 1
  store %xiao.bytes %t2, ptr %t3
  %t4 = call i32 @xiao_runtime_language_context_set(ptr %t3)
  %t5 = icmp eq i32 %t4, 0
  br i1 %t5, label %abi.ok0, label %abi.status.fail1
abi.status.fail1:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 126)
  br label %xiao.error.terminal
abi.ok0:
  %t6 = call i32 @xiao_runtime_abi_is_compatible(i32 1, i32 20)
  %t7 = icmp eq i32 %t6, 1
  br i1 %t7, label %abi.entry.ok, label %abi.fail
abi.entry.ok:
  store %xiao.value zeroinitializer, ptr %t8
  store %xiao.value zeroinitializer, ptr %t9
  store %xiao.value zeroinitializer, ptr %t10
  %t11 = getelementptr inbounds [5 x i8], ptr @.xiao.str1, i64 0, i64 0
  %t12 = insertvalue %xiao.bytes zeroinitializer, ptr %t11, 0
  %t13 = insertvalue %xiao.bytes %t12, i64 4, 1
  store %xiao.bytes %t13, ptr %t14
  store ptr null, ptr %t15
  %t16 = call i32 @xiao_runtime_string_new(ptr %t14, ptr %t15)
  %t17 = icmp eq i32 %t16, 0
  br i1 %t17, label %abi.ok4, label %abi.status.fail5
abi.status.fail5:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 126)
  br label %log.arguments.fail2
abi.ok4:
  %t18 = load ptr, ptr %t15
  store %xiao.value zeroinitializer, ptr %t20
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t20, ptr %t18)
  %t19 = load %xiao.value, ptr %t20
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  store %xiao.value %t19, ptr %xiao.statement.site0
  %t21 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site0, ptr %t8)
  %t22 = icmp eq i32 %t21, 0
  br i1 %t22, label %abi.ok6, label %abi.status.fail7
abi.status.fail7:
  call i32 @xiao_runtime_error_attach_span(i64 13, i64 19)
  br label %log.arguments.fail2
abi.ok6:
  %t23 = getelementptr inbounds [8 x i8], ptr @.xiao.str2, i64 0, i64 0
  %t24 = insertvalue %xiao.bytes zeroinitializer, ptr %t23, 0
  %t25 = insertvalue %xiao.bytes %t24, i64 7, 1
  store %xiao.bytes %t25, ptr %t26
  store ptr null, ptr %t27
  %t28 = call i32 @xiao_runtime_string_new(ptr %t26, ptr %t27)
  %t29 = icmp eq i32 %t28, 0
  br i1 %t29, label %abi.ok8, label %abi.status.fail9
abi.status.fail9:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 126)
  br label %log.arguments.fail2
abi.ok8:
  %t30 = load ptr, ptr %t27
  store %xiao.value zeroinitializer, ptr %t32
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t32, ptr %t30)
  %t31 = load %xiao.value, ptr %t32
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  store %xiao.value %t31, ptr %xiao.statement.site1
  %t33 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site1, ptr %t9)
  %t34 = icmp eq i32 %t33, 0
  br i1 %t34, label %abi.ok10, label %abi.status.fail11
abi.status.fail11:
  call i32 @xiao_runtime_error_attach_span(i64 21, i64 30)
  br label %log.arguments.fail2
abi.ok10:
  %t35 = getelementptr inbounds [7 x i8], ptr @.xiao.str3, i64 0, i64 0
  %t36 = insertvalue %xiao.bytes zeroinitializer, ptr %t35, 0
  %t37 = insertvalue %xiao.bytes %t36, i64 6, 1
  store %xiao.bytes %t37, ptr %t38
  store ptr null, ptr %t39
  %t40 = call i32 @xiao_runtime_string_new(ptr %t38, ptr %t39)
  %t41 = icmp eq i32 %t40, 0
  br i1 %t41, label %abi.ok12, label %abi.status.fail13
abi.status.fail13:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 126)
  br label %log.arguments.fail2
abi.ok12:
  %t42 = load ptr, ptr %t39
  store %xiao.value zeroinitializer, ptr %t44
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t44, ptr %t42)
  %t43 = load %xiao.value, ptr %t44
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  store %xiao.value %t43, ptr %xiao.statement.site2
  %t45 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site2, ptr %t10)
  %t46 = icmp eq i32 %t45, 0
  br i1 %t46, label %abi.ok14, label %abi.status.fail15
abi.status.fail15:
  call i32 @xiao_runtime_error_attach_span(i64 32, i64 40)
  br label %log.arguments.fail2
abi.ok14:
  br label %log.arguments.ready3
log.arguments.fail2:
  call void @xiao_runtime_value_release_strong(ptr %t10)
  call void @xiao_runtime_value_release_strong(ptr %t9)
  call void @xiao_runtime_value_release_strong(ptr %t8)
  br label %xiao.error.terminal
log.arguments.ready3:
  %t47 = call i32 @xiao_runtime_log_write(ptr %t8, ptr %t9, ptr %t10, i64 34)
  call void @xiao_runtime_value_release_strong(ptr %t10)
  call void @xiao_runtime_value_release_strong(ptr %t9)
  call void @xiao_runtime_value_release_strong(ptr %t8)
  switch i32 %t47, label %log.abi.failure18 [ i32 0, label %log.ok16 i32 6, label %log.error17 i32 8, label %log.error17 ]
log.abi.failure18:
  call void @xiao_runtime_fatal_abi()
  unreachable
log.error17:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 41)
  br label %xiao.error.terminal
log.ok16:
  store %xiao.value zeroinitializer, ptr %t48
  call void @xiao_runtime_value_release_strong(ptr %t48)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  %t49 = call i32 @xiao_runtime_error_class()
  %t50 = icmp eq i32 %t49, 0
  br i1 %t50, label %abi.error.ok19, label %abi.error.fail20
abi.error.fail20:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 41)
  br label %xiao.error.terminal
abi.error.ok19:
  br label %dynamic.while.cond21
dynamic.while.cond21:
  store %xiao.value zeroinitializer, ptr %t52
  call void @xiao_runtime_value_bool(ptr sret(%xiao.value) %t52, i8 1)
  %t51 = load %xiao.value, ptr %t52
  %t53 = extractvalue %xiao.value %t51, 0
  %t54 = icmp eq i32 %t53, 1
  br i1 %t54, label %dynamic.bool.ok24, label %xiao.error.terminal
dynamic.bool.ok24:
  %t55 = extractvalue %xiao.value %t51, 1
  %t56 = trunc i64 %t55 to i1
  store %xiao.value %t51, ptr %t57
  call void @xiao_runtime_value_release_strong(ptr %t57)
  br i1 %t56, label %dynamic.while.body22, label %dynamic.while.end23
dynamic.while.body22:
  store %xiao.value zeroinitializer, ptr %t58
  store %xiao.value zeroinitializer, ptr %t59
  store %xiao.value zeroinitializer, ptr %t61
  call void @xiao_runtime_value_int(ptr sret(%xiao.value) %t61, i64 25)
  %t60 = load %xiao.value, ptr %t61
  store %xiao.value %t60, ptr %t58
  %t62 = getelementptr inbounds [3 x i8], ptr @.xiao.str4, i64 0, i64 0
  %t63 = insertvalue %xiao.bytes zeroinitializer, ptr %t62, 0
  %t64 = insertvalue %xiao.bytes %t63, i64 2, 1
  store %xiao.bytes %t64, ptr %t65
  store ptr null, ptr %t66
  %t67 = call i32 @xiao_runtime_string_new(ptr %t65, ptr %t66)
  %t68 = icmp eq i32 %t67, 0
  br i1 %t68, label %abi.ok27, label %abi.status.fail28
abi.status.fail28:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 126)
  br label %time.arguments.fail25
abi.ok27:
  %t69 = load ptr, ptr %t66
  store %xiao.value zeroinitializer, ptr %t71
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t71, ptr %t69)
  %t70 = load %xiao.value, ptr %t71
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site3)
  store %xiao.value %t70, ptr %xiao.statement.site3
  %t72 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site3, ptr %t59)
  %t73 = icmp eq i32 %t72, 0
  br i1 %t73, label %abi.ok29, label %abi.status.fail30
abi.status.fail30:
  call i32 @xiao_runtime_error_attach_span(i64 75, i64 79)
  br label %time.arguments.fail25
abi.ok29:
  br label %time.arguments.ready26
time.arguments.fail25:
  call void @xiao_runtime_value_release_strong(ptr %t59)
  call void @xiao_runtime_value_release_strong(ptr %t58)
  br label %xiao.error.terminal
time.arguments.ready26:
  %t74 = call i32 @xiao_runtime_time_sleep(ptr %t58, ptr %t59, i64 34)
  call void @xiao_runtime_value_release_strong(ptr %t59)
  call void @xiao_runtime_value_release_strong(ptr %t58)
  switch i32 %t74, label %time.abi.failure33 [ i32 0, label %time.ok31 i32 6, label %time.error32 ]
time.abi.failure33:
  call void @xiao_runtime_fatal_abi()
  unreachable
time.error32:
  call i32 @xiao_runtime_error_attach_span(i64 57, i64 80)
  br label %xiao.error.terminal
time.ok31:
  store %xiao.value zeroinitializer, ptr %t75
  call void @xiao_runtime_value_release_strong(ptr %t75)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site3)
  %t76 = call i32 @xiao_runtime_error_class()
  %t77 = icmp eq i32 %t76, 0
  br i1 %t77, label %abi.error.ok34, label %abi.error.fail35
abi.error.fail35:
  call i32 @xiao_runtime_error_attach_span(i64 57, i64 80)
  br label %xiao.error.terminal
abi.error.ok34:
  store %xiao.value zeroinitializer, ptr %t78
  store %xiao.value zeroinitializer, ptr %t79
  store %xiao.value zeroinitializer, ptr %t80
  %t81 = getelementptr inbounds [5 x i8], ptr @.xiao.str5, i64 0, i64 0
  %t82 = insertvalue %xiao.bytes zeroinitializer, ptr %t81, 0
  %t83 = insertvalue %xiao.bytes %t82, i64 4, 1
  store %xiao.bytes %t83, ptr %t84
  store ptr null, ptr %t85
  %t86 = call i32 @xiao_runtime_string_new(ptr %t84, ptr %t85)
  %t87 = icmp eq i32 %t86, 0
  br i1 %t87, label %abi.ok38, label %abi.status.fail39
abi.status.fail39:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 126)
  br label %log.arguments.fail36
abi.ok38:
  %t88 = load ptr, ptr %t85
  store %xiao.value zeroinitializer, ptr %t90
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t90, ptr %t88)
  %t89 = load %xiao.value, ptr %t90
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site4)
  store %xiao.value %t89, ptr %xiao.statement.site4
  %t91 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site4, ptr %t78)
  %t92 = icmp eq i32 %t91, 0
  br i1 %t92, label %abi.ok40, label %abi.status.fail41
abi.status.fail41:
  call i32 @xiao_runtime_error_attach_span(i64 98, i64 104)
  br label %log.arguments.fail36
abi.ok40:
  %t93 = getelementptr inbounds [7 x i8], ptr @.xiao.str6, i64 0, i64 0
  %t94 = insertvalue %xiao.bytes zeroinitializer, ptr %t93, 0
  %t95 = insertvalue %xiao.bytes %t94, i64 6, 1
  store %xiao.bytes %t95, ptr %t96
  store ptr null, ptr %t97
  %t98 = call i32 @xiao_runtime_string_new(ptr %t96, ptr %t97)
  %t99 = icmp eq i32 %t98, 0
  br i1 %t99, label %abi.ok42, label %abi.status.fail43
abi.status.fail43:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 126)
  br label %log.arguments.fail36
abi.ok42:
  %t100 = load ptr, ptr %t97
  store %xiao.value zeroinitializer, ptr %t102
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t102, ptr %t100)
  %t101 = load %xiao.value, ptr %t102
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site5)
  store %xiao.value %t101, ptr %xiao.statement.site5
  %t103 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site5, ptr %t79)
  %t104 = icmp eq i32 %t103, 0
  br i1 %t104, label %abi.ok44, label %abi.status.fail45
abi.status.fail45:
  call i32 @xiao_runtime_error_attach_span(i64 106, i64 114)
  br label %log.arguments.fail36
abi.ok44:
  %t105 = getelementptr inbounds [7 x i8], ptr @.xiao.str7, i64 0, i64 0
  %t106 = insertvalue %xiao.bytes zeroinitializer, ptr %t105, 0
  %t107 = insertvalue %xiao.bytes %t106, i64 6, 1
  store %xiao.bytes %t107, ptr %t108
  store ptr null, ptr %t109
  %t110 = call i32 @xiao_runtime_string_new(ptr %t108, ptr %t109)
  %t111 = icmp eq i32 %t110, 0
  br i1 %t111, label %abi.ok46, label %abi.status.fail47
abi.status.fail47:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 126)
  br label %log.arguments.fail36
abi.ok46:
  %t112 = load ptr, ptr %t109
  store %xiao.value zeroinitializer, ptr %t114
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t114, ptr %t112)
  %t113 = load %xiao.value, ptr %t114
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site6)
  store %xiao.value %t113, ptr %xiao.statement.site6
  %t115 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site6, ptr %t80)
  %t116 = icmp eq i32 %t115, 0
  br i1 %t116, label %abi.ok48, label %abi.status.fail49
abi.status.fail49:
  call i32 @xiao_runtime_error_attach_span(i64 116, i64 124)
  br label %log.arguments.fail36
abi.ok48:
  br label %log.arguments.ready37
log.arguments.fail36:
  call void @xiao_runtime_value_release_strong(ptr %t80)
  call void @xiao_runtime_value_release_strong(ptr %t79)
  call void @xiao_runtime_value_release_strong(ptr %t78)
  br label %xiao.error.terminal
log.arguments.ready37:
  %t117 = call i32 @xiao_runtime_log_write(ptr %t78, ptr %t79, ptr %t80, i64 34)
  call void @xiao_runtime_value_release_strong(ptr %t80)
  call void @xiao_runtime_value_release_strong(ptr %t79)
  call void @xiao_runtime_value_release_strong(ptr %t78)
  switch i32 %t117, label %log.abi.failure52 [ i32 0, label %log.ok50 i32 6, label %log.error51 i32 8, label %log.error51 ]
log.abi.failure52:
  call void @xiao_runtime_fatal_abi()
  unreachable
log.error51:
  call i32 @xiao_runtime_error_attach_span(i64 85, i64 125)
  br label %xiao.error.terminal
log.ok50:
  store %xiao.value zeroinitializer, ptr %t118
  call void @xiao_runtime_value_release_strong(ptr %t118)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site4)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site5)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site6)
  %t119 = call i32 @xiao_runtime_error_class()
  %t120 = icmp eq i32 %t119, 0
  br i1 %t120, label %abi.error.ok53, label %abi.error.fail54
abi.error.fail54:
  call i32 @xiao_runtime_error_attach_span(i64 85, i64 125)
  br label %xiao.error.terminal
abi.error.ok53:
  br label %dynamic.while.cond21
dynamic.while.end23:
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site3)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site4)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site5)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site6)
  %t121 = call i32 @xiao_runtime_error_class()
  %t122 = icmp eq i32 %t121, 0
  br i1 %t122, label %abi.ok55, label %abi.status.fail56
abi.status.fail56:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 126)
  br label %xiao.error.terminal
abi.ok55:
  call void @xiao_runtime_release_trace_flush()
  ret void
xiao.error.terminal:
  %t123 = call i32 @xiao_runtime_error_class()
  %t124 = icmp eq i32 %t123, 2
  br i1 %t124, label %xiao.error.report57, label %xiao.error.unmatched58
xiao.error.unmatched58:
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site2)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site3)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site4)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site5)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site6)
  br label %xiao.error.report57
xiao.error.report57:
  call void @xiao_runtime_error_report()
  call void @xiao_runtime_release_trace_flush()
  %t125 = call i32 @xiao_runtime_error_exit_code()
  ret void
abi.fail:
  call void @xiao_runtime_fatal_abi()
  unreachable
}

define internal i32 @xiao_application_main() {
entry:
  call void @xiao_entry()
  %xiao_exit_code = call i32 @xiao_runtime_error_exit_code()
  ret i32 %xiao_exit_code
}

define i32 @main() {
entry:
  %status = call i32 @xiao_runtime_env_run_native(ptr @xiao_application_main, i64 34, i32 0)
  ret i32 %status
}


@xiao_native_metadata = constant [107 x i8] c"\58\49\41\4F\4D\45\54\41\01\00\00\00\6B\00\00\00\14\00\01\00\00\00\00\00\14\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\1C\00\00\00\40\00\00\00\01\00\00\00\14\00\01\00\00\00\00\00\16\00\00\00\78\38\36\5F\36\34\2D\70\63\2D\77\69\6E\64\6F\77\73\2D\6D\73\76\63\05\00\00\00\30\2E\31\2E\30\08\00\00\00\70\6F\72\74\61\62\6C\65", section ".xiaomta", align 4
@llvm.used = appending global [1 x ptr] [ptr @xiao_native_metadata], section "llvm.metadata"
