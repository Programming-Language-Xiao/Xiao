; Xiao N0-B LLVM dynamic module
; target = x86_64-pc-windows-msvc
target triple = "x86_64-pc-windows-msvc"

%xiao.value = type { i32, i64 }
%xiao.bytes = type { ptr, i64 }

%xiao.table.field = type { %xiao.bytes, i32, i8 }
%xiao.table.descriptor = type { %xiao.bytes, i32, ptr, i64 }

%xiao.table.method = type { %xiao.bytes, i64, ptr, i64, i32, i8, ptr }
%xiao.table.descriptor.v2 = type { i32, i32, %xiao.table.descriptor, ptr, i64, ptr, ptr, ptr }

%xiao.error.location = type { i64, i64, i8, [7 x i8] }

; xiao.source-map statement 0..34
@.xiao.bytes0 = private unnamed_addr constant [6 x i8] c"zh-CN\00"
@.xiao.str1 = private unnamed_addr constant [3 x i8] c"ms\00"

declare i32 @xiao_runtime_abi_is_compatible(i32, i32)
declare i32 @xiao_runtime_array_new(ptr, i64, ptr)
declare i32 @xiao_runtime_array_push(ptr, ptr)
declare i32 @xiao_runtime_concurrency_call(ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_concurrency_call_with_entry(ptr, ptr, ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_concurrency_cancellation_check(ptr)
declare i32 @xiao_runtime_concurrency_finish()
declare i32 @xiao_runtime_dict_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_dict_new(i32, ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_dynamic_check(ptr, ptr)
declare i32 @xiao_runtime_dynamic_member_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_error_attach_span(i64, i64)
declare i32 @xiao_runtime_error_checkpoint_finish()
declare i32 @xiao_runtime_error_class()
declare i32 @xiao_runtime_error_code(ptr, ptr)
declare i32 @xiao_runtime_error_exit_code()
declare i32 @xiao_runtime_error_matches(ptr)
declare i32 @xiao_runtime_error_raise_value(ptr, ptr)
declare i32 @xiao_runtime_error_take(ptr)
declare i32 @xiao_runtime_language_context_set(ptr)
declare i32 @xiao_runtime_lfloat_divide(ptr, ptr, ptr, ptr, ptr)
declare i32 @xiao_runtime_print_values_with_capabilities(ptr, i64, i64)
declare i32 @xiao_runtime_process_close_with_capabilities(ptr, i64)
declare i32 @xiao_runtime_random_seed(ptr)
declare i32 @xiao_runtime_resource_close_with_capabilities(ptr, i64)
declare i32 @xiao_runtime_set_add(ptr, ptr)
declare i32 @xiao_runtime_set_new(ptr, i64, ptr)
declare i32 @xiao_runtime_set_remove(ptr, ptr, ptr)
declare i32 @xiao_runtime_string_new(ptr, ptr)
declare i32 @xiao_runtime_table_call(ptr, ptr, i64, ptr, i64, ptr)
declare i32 @xiao_runtime_table_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_get_value(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_new(ptr, ptr)
declare i32 @xiao_runtime_table_new_v2(ptr, ptr)
declare i32 @xiao_runtime_table_new_v2_with_args(ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_table_set(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_set_value(ptr, ptr, ptr)
declare i32 @xiao_runtime_time_format_utc(ptr, ptr, ptr, i64)
declare i32 @xiao_runtime_tuple_new(ptr, i64, ptr)
declare i32 @xiao_runtime_value_binary(ptr, ptr, ptr, ptr)
declare i32 @xiao_runtime_value_cast(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_chr(ptr, ptr)
declare i32 @xiao_runtime_value_copy(ptr, ptr)
declare i32 @xiao_runtime_value_dict_keys(ptr, ptr)
declare i32 @xiao_runtime_value_dict_remove_dynamic(ptr, ptr)
declare i32 @xiao_runtime_value_dict_values(ptr, ptr)
declare i32 @xiao_runtime_value_index_get_dynamic(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_index_set_dynamic(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_iter_get(ptr, i64, ptr)
declare i32 @xiao_runtime_value_iter_len(ptr, ptr)
declare i32 @xiao_runtime_value_iter_snapshot(ptr, ptr)
declare i32 @xiao_runtime_value_release_weak(ptr)
declare i32 @xiao_runtime_value_select(ptr, i64, ptr, ptr)
declare i32 @xiao_runtime_value_unary(ptr, ptr, ptr)
declare ptr @llvm.stacksave()
declare void @llvm.stackrestore(ptr)
declare void @llvm.trap()
declare void @xiao_runtime_concurrency_entry_begin()
declare void @xiao_runtime_error_checkpoint_begin()
declare void @xiao_runtime_error_checkpoint_discard()
declare void @xiao_runtime_error_checkpoint_reset()
declare void @xiao_runtime_error_clear()
declare void @xiao_runtime_error_new(ptr sret(%xiao.value) align 8, ptr, ptr, ptr, ptr)
declare void @xiao_runtime_error_new_values(ptr sret(%xiao.value) align 8, ptr, ptr, ptr, ptr)
declare void @xiao_runtime_error_push_native_frame(ptr, ptr, i64, i64)
declare void @xiao_runtime_error_report()
declare void @xiao_runtime_fatal_abi()
declare void @xiao_runtime_input_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i8, i64)
declare void @xiao_runtime_process_spawn_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_process_wait_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_release(ptr)
declare void @xiao_runtime_release_trace_begin()
declare void @xiao_runtime_release_trace_flush()
declare void @xiao_runtime_resource_open_directory_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_resource_open_file_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_resource_read_text_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_value_array(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_array_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_bool(ptr sret(%xiao.value) align 8, i8)
declare void @xiao_runtime_value_dict(ptr sret(%xiao.value) align 8, ptr, i32)
declare void @xiao_runtime_value_dict_owned(ptr sret(%xiao.value) align 8, ptr, i32)
declare void @xiao_runtime_value_float(ptr sret(%xiao.value) align 8, double)
declare void @xiao_runtime_value_int(ptr sret(%xiao.value) align 8, i64)
declare void @xiao_runtime_value_lfloat(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lfloat_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lint(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lint_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_none(ptr sret(%xiao.value) align 8)
declare void @xiao_runtime_value_release_any(ptr)
declare void @xiao_runtime_value_release_strong(ptr)
declare void @xiao_runtime_value_set(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_set_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_sfloat(ptr sret(%xiao.value) align 8, float)
declare void @xiao_runtime_value_sint(ptr sret(%xiao.value) align 8, i32)
declare void @xiao_runtime_value_str(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_table(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_table_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_tuple(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_tuple_owned(ptr sret(%xiao.value) align 8, ptr)

define void @xiao_entry() {
entry:
  %xiao.statement.site0 = alloca %xiao.value
  %xiao.statement.site1 = alloca %xiao.value
  %t3 = alloca %xiao.bytes
  %t8 = alloca %xiao.value
  %t9 = alloca %xiao.value
  %t11 = alloca %xiao.value
  %t15 = alloca %xiao.bytes
  %t16 = alloca ptr
  %t21 = alloca %xiao.value
  %t24 = alloca %xiao.value
  %t27 = alloca %xiao.value, i64 1
  %t32 = alloca %xiao.value
  %t33 = alloca %xiao.value
  store %xiao.value zeroinitializer, ptr %xiao.statement.site0
  store %xiao.value zeroinitializer, ptr %xiao.statement.site1
  call void @xiao_runtime_error_checkpoint_reset()
  call void @xiao_runtime_error_clear()
  call void @xiao_runtime_release_trace_begin()
  %t0 = getelementptr inbounds [6 x i8], ptr @.xiao.bytes0, i64 0, i64 0
  %t1 = insertvalue %xiao.bytes zeroinitializer, ptr %t0, 0
  %t2 = insertvalue %xiao.bytes %t1, i64 5, 1
  store %xiao.bytes %t2, ptr %t3
  %t4 = call i32 @xiao_runtime_language_context_set(ptr %t3)
  %t5 = icmp eq i32 %t4, 0
  br i1 %t5, label %abi.ok0, label %abi.status.fail1
abi.status.fail1:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 35)
  br label %xiao.error.terminal
abi.ok0:
  %t6 = call i32 @xiao_runtime_abi_is_compatible(i32 1, i32 20)
  %t7 = icmp eq i32 %t6, 1
  br i1 %t7, label %abi.entry.ok, label %abi.fail
abi.entry.ok:
  store %xiao.value zeroinitializer, ptr %t8
  store %xiao.value zeroinitializer, ptr %t9
  store %xiao.value zeroinitializer, ptr %t11
  call void @xiao_runtime_value_int(ptr sret(%xiao.value) %t11, i64 0)
  %t10 = load %xiao.value, ptr %t11
  store %xiao.value %t10, ptr %t8
  %t12 = getelementptr inbounds [3 x i8], ptr @.xiao.str1, i64 0, i64 0
  %t13 = insertvalue %xiao.bytes zeroinitializer, ptr %t12, 0
  %t14 = insertvalue %xiao.bytes %t13, i64 2, 1
  store %xiao.bytes %t14, ptr %t15
  store ptr null, ptr %t16
  %t17 = call i32 @xiao_runtime_string_new(ptr %t15, ptr %t16)
  %t18 = icmp eq i32 %t17, 0
  br i1 %t18, label %abi.ok4, label %abi.status.fail5
abi.status.fail5:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 35)
  br label %time.arguments.fail2
abi.ok4:
  %t19 = load ptr, ptr %t16
  store %xiao.value zeroinitializer, ptr %t21
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t21, ptr %t19)
  %t20 = load %xiao.value, ptr %t21
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  store %xiao.value %t20, ptr %xiao.statement.site0
  %t22 = call i32 @xiao_runtime_value_copy(ptr %xiao.statement.site0, ptr %t9)
  %t23 = icmp eq i32 %t22, 0
  br i1 %t23, label %abi.ok6, label %abi.status.fail7
abi.status.fail7:
  call i32 @xiao_runtime_error_attach_span(i64 28, i64 32)
  br label %time.arguments.fail2
abi.ok6:
  br label %time.arguments.ready3
time.arguments.fail2:
  call void @xiao_runtime_value_release_strong(ptr %t9)
  call void @xiao_runtime_value_release_strong(ptr %t8)
  br label %xiao.error.terminal
time.arguments.ready3:
  store %xiao.value zeroinitializer, ptr %t24
  %t25 = call i32 @xiao_runtime_time_format_utc(ptr %t8, ptr %t9, ptr %t24, i64 34)
  call void @xiao_runtime_value_release_strong(ptr %t9)
  call void @xiao_runtime_value_release_strong(ptr %t8)
  switch i32 %t25, label %time.abi.failure10 [ i32 0, label %time.ok8 i32 6, label %time.error9 ]
time.abi.failure10:
  call void @xiao_runtime_value_release_strong(ptr %t24)
  call void @xiao_runtime_fatal_abi()
  unreachable
time.error9:
  call void @xiao_runtime_value_release_strong(ptr %t24)
  call i32 @xiao_runtime_error_attach_span(i64 6, i64 33)
  br label %xiao.error.terminal
time.ok8:
  %t26 = load %xiao.value, ptr %t24
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  store %xiao.value %t26, ptr %xiao.statement.site1
  %t28 = getelementptr inbounds %xiao.value, ptr %t27, i64 0
  store %xiao.value %t26, ptr %t28
  %t29 = call i32 @xiao_runtime_print_values_with_capabilities(ptr %t27, i64 1, i64 34)
  %t30 = icmp eq i32 %t29, 0
  br i1 %t30, label %abi.ok11, label %abi.status.fail12
abi.status.fail12:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 34)
  br label %xiao.error.terminal
abi.ok11:
  store %xiao.value zeroinitializer, ptr %t32
  call void @xiao_runtime_value_none(ptr sret(%xiao.value) %t32)
  %t31 = load %xiao.value, ptr %t32
  store %xiao.value %t31, ptr %t33
  call void @xiao_runtime_value_release_strong(ptr %t33)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  %t34 = call i32 @xiao_runtime_error_class()
  %t35 = icmp eq i32 %t34, 0
  br i1 %t35, label %abi.error.ok13, label %abi.error.fail14
abi.error.fail14:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 34)
  br label %xiao.error.terminal
abi.error.ok13:
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  %t36 = call i32 @xiao_runtime_error_class()
  %t37 = icmp eq i32 %t36, 0
  br i1 %t37, label %abi.ok15, label %abi.status.fail16
abi.status.fail16:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 35)
  br label %xiao.error.terminal
abi.ok15:
  call void @xiao_runtime_release_trace_flush()
  ret void
xiao.error.terminal:
  %t38 = call i32 @xiao_runtime_error_class()
  %t39 = icmp eq i32 %t38, 2
  br i1 %t39, label %xiao.error.report17, label %xiao.error.unmatched18
xiao.error.unmatched18:
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.statement.site1)
  br label %xiao.error.report17
xiao.error.report17:
  call void @xiao_runtime_error_report()
  call void @xiao_runtime_release_trace_flush()
  %t40 = call i32 @xiao_runtime_error_exit_code()
  ret void
abi.fail:
  call void @xiao_runtime_fatal_abi()
  unreachable
}

define i32 @main() {
entry:
  call void @xiao_entry()
  %xiao_exit_code = call i32 @xiao_runtime_error_exit_code()
  ret i32 %xiao_exit_code
}


@xiao_native_metadata = constant [107 x i8] c"\58\49\41\4F\4D\45\54\41\01\00\00\00\6B\00\00\00\14\00\01\00\00\00\00\00\14\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\1B\00\00\00\40\00\00\00\01\00\00\00\14\00\01\00\00\00\00\00\16\00\00\00\78\38\36\5F\36\34\2D\70\63\2D\77\69\6E\64\6F\77\73\2D\6D\73\76\63\05\00\00\00\30\2E\31\2E\30\08\00\00\00\70\6F\72\74\61\62\6C\65", section ".xiaomta", align 4
@llvm.used = appending global [1 x ptr] [ptr @xiao_native_metadata], section "llvm.metadata"
