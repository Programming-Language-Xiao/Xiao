; Xiao N0-B LLVM dynamic module
; target = x86_64-pc-windows-msvc
target triple = "x86_64-pc-windows-msvc"

%xiao.value = type { i32, i64 }
%xiao.bytes = type { ptr, i64 }

%xiao.table.field = type { %xiao.bytes, i32, i8 }
%xiao.table.descriptor = type { %xiao.bytes, i32, ptr, i64 }

%xiao.table.method = type { %xiao.bytes, i64, ptr, i64, i32, i8, ptr }
%xiao.table.descriptor.v2 = type { i32, i32, %xiao.table.descriptor, ptr, i64, ptr, ptr, ptr }

%xiao.error.location = type { i64, i64, i8, [7 x i8] }

; xiao.source-map statement 0..104
; xiao.source-map statement 105..199
; xiao.source-map statement 152..170
; xiao.source-map return 175..198
; xiao.source-map statement 199..307
; xiao.source-map statement 259..277
; xiao.source-map statement 282..306
; xiao.source-map statement 307..568
; xiao.source-map try 374..559
; xiao.source-map statement 386..406
; xiao.source-map statement 415..433
; xiao.source-map return 442..465
; xiao.source-map statement 486..507
; xiao.source-map raise 516..554
; xiao.source-map return 559..567
; xiao.source-map statement 568..590
; xiao.source-map statement 591..611
; xiao.source-map statement 612..633
; xiao.source-map statement 634..651
; xiao.source-map statement 652..691
; xiao.source-map while 692..734
; xiao.source-map statement 724..733
; xiao.source-map statement 734..748
; xiao.source-map try 749..817
; xiao.source-map statement 757..769
; xiao.source-map catch 770..817
; xiao.source-map statement 793..816
@.xiao.bytes0 = private unnamed_addr constant [6 x i8] c"zh-CN\00"
@.xiao.bytes1 = private unnamed_addr constant [16 x i8] c"current_runtime\00"
@.xiao.bytes2 = private unnamed_addr constant [11 x i8] c"shared_mut\00"
@.xiao.bytes3 = private unnamed_addr constant [11 x i8] c"shared_mut\00"
@.xiao.bytes4 = private unnamed_addr constant [10 x i8] c"lock_wait\00"
@.xiao.bytes5 = private unnamed_addr constant [5 x i8] c"lock\00"
@.xiao.bytes6 = private unnamed_addr constant [11 x i8] c"safe_point\00"
@.xiao.bytes7 = private unnamed_addr constant [6 x i8] c"spawn\00"
@.xiao.bytes8 = private unnamed_addr constant [3 x i8] c"eq\00"
@.xiao.bytes9 = private unnamed_addr constant [7 x i8] c"cancel\00"
@.xiao.bytes10 = private unnamed_addr constant [5 x i8] c"wait\00"
@.xiao.bytes11 = private unnamed_addr constant [5 x i8] c"join\00"
@.xiao.bytes12 = private unnamed_addr constant [6 x i8] c"Error\00"
@.xiao.str13 = private unnamed_addr constant [15 x i8] c"must-not-catch\00"
@.xiao.bytes14 = private unnamed_addr constant [11 x i8] c"safe_point\00"
@.xiao.bytes15 = private unnamed_addr constant [10 x i8] c"lock_wait\00"
@.xiao.bytes16 = private unnamed_addr constant [5 x i8] c"lock\00"
@.xiao.bytes17 = private unnamed_addr constant [11 x i8] c"safe_point\00"
@.xiao.bytes18 = private unnamed_addr constant [10 x i8] c"lock_read\00"
@.xiao.bytes19 = private unnamed_addr constant [6 x i8] c"entry\00"
@.xiao.bytes20 = private unnamed_addr constant [10 x i8] c"read_flag\00"
@.xiao.bytes21 = private unnamed_addr constant [11 x i8] c"safe_point\00"
@.xiao.bytes22 = private unnamed_addr constant [11 x i8] c"safe_point\00"
@.xiao.bytes23 = private unnamed_addr constant [11 x i8] c"safe_point\00"
@.xiao.bytes24 = private unnamed_addr constant [10 x i8] c"lock_wait\00"
@.xiao.bytes25 = private unnamed_addr constant [5 x i8] c"lock\00"
@.xiao.bytes26 = private unnamed_addr constant [11 x i8] c"safe_point\00"
@.xiao.bytes27 = private unnamed_addr constant [10 x i8] c"lock_read\00"
@.xiao.str28 = private unnamed_addr constant [13 x i8] c"lock-finally\00"
@.xiao.str29 = private unnamed_addr constant [13 x i8] c"lock-cleanup\00"
@.xiao.bytes30 = private unnamed_addr constant [10 x i8] c"TypeError\00"
@.xiao.str31 = private unnamed_addr constant [13 x i8] c"lock-finally\00"
@.xiao.str32 = private unnamed_addr constant [13 x i8] c"lock-cleanup\00"
@.xiao.bytes33 = private unnamed_addr constant [10 x i8] c"TypeError\00"
@.xiao.str34 = private unnamed_addr constant [13 x i8] c"lock-finally\00"
@.xiao.str35 = private unnamed_addr constant [13 x i8] c"lock-cleanup\00"
@.xiao.bytes36 = private unnamed_addr constant [10 x i8] c"TypeError\00"
@.xiao.bytes37 = private unnamed_addr constant [11 x i8] c"safe_point\00"
@.xiao.bytes38 = private unnamed_addr constant [6 x i8] c"entry\00"
@.xiao.bytes39 = private unnamed_addr constant [7 x i8] c"worker\00"
@.xiao.bytes40 = private unnamed_addr constant [11 x i8] c"safe_point\00"
@.xiao.bytes41 = private unnamed_addr constant [10 x i8] c"lock_wait\00"
@.xiao.bytes42 = private unnamed_addr constant [5 x i8] c"lock\00"
@.xiao.bytes43 = private unnamed_addr constant [11 x i8] c"safe_point\00"
@.xiao.bytes44 = private unnamed_addr constant [11 x i8] c"lock_write\00"
@.xiao.bytes45 = private unnamed_addr constant [6 x i8] c"entry\00"
@.xiao.bytes46 = private unnamed_addr constant [11 x i8] c"write_flag\00"

declare i32 @xiao_runtime_abi_is_compatible(i32, i32)
declare i32 @xiao_runtime_array_new(ptr, i64, ptr)
declare i32 @xiao_runtime_array_push(ptr, ptr)
declare i32 @xiao_runtime_concurrency_call(ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_concurrency_call_with_entry(ptr, ptr, ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_concurrency_cancellation_check(ptr)
declare i32 @xiao_runtime_concurrency_finish()
declare i32 @xiao_runtime_dict_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_dict_new(i32, ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_dynamic_check(ptr, ptr)
declare i32 @xiao_runtime_dynamic_member_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_error_attach_span(i64, i64)
declare i32 @xiao_runtime_error_checkpoint_finish()
declare i32 @xiao_runtime_error_class()
declare i32 @xiao_runtime_error_code(ptr, ptr)
declare i32 @xiao_runtime_error_exit_code()
declare i32 @xiao_runtime_error_matches(ptr)
declare i32 @xiao_runtime_error_raise_value(ptr, ptr)
declare i32 @xiao_runtime_error_take(ptr)
declare i32 @xiao_runtime_language_context_set(ptr)
declare i32 @xiao_runtime_lfloat_divide(ptr, ptr, ptr, ptr, ptr)
declare i32 @xiao_runtime_print_values_with_capabilities(ptr, i64, i64)
declare i32 @xiao_runtime_process_close_with_capabilities(ptr, i64)
declare i32 @xiao_runtime_random_seed(ptr)
declare i32 @xiao_runtime_resource_close_with_capabilities(ptr, i64)
declare i32 @xiao_runtime_set_add(ptr, ptr)
declare i32 @xiao_runtime_set_new(ptr, i64, ptr)
declare i32 @xiao_runtime_set_remove(ptr, ptr, ptr)
declare i32 @xiao_runtime_string_new(ptr, ptr)
declare i32 @xiao_runtime_table_call(ptr, ptr, i64, ptr, i64, ptr)
declare i32 @xiao_runtime_table_get(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_get_value(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_new(ptr, ptr)
declare i32 @xiao_runtime_table_new_v2(ptr, ptr)
declare i32 @xiao_runtime_table_new_v2_with_args(ptr, ptr, i64, ptr)
declare i32 @xiao_runtime_table_set(ptr, ptr, ptr)
declare i32 @xiao_runtime_table_set_value(ptr, ptr, ptr)
declare i32 @xiao_runtime_tuple_new(ptr, i64, ptr)
declare i32 @xiao_runtime_value_binary(ptr, ptr, ptr, ptr)
declare i32 @xiao_runtime_value_cast(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_chr(ptr, ptr)
declare i32 @xiao_runtime_value_copy(ptr, ptr)
declare i32 @xiao_runtime_value_dict_keys(ptr, ptr)
declare i32 @xiao_runtime_value_dict_remove_dynamic(ptr, ptr)
declare i32 @xiao_runtime_value_dict_values(ptr, ptr)
declare i32 @xiao_runtime_value_index_get_dynamic(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_index_set_dynamic(ptr, ptr, ptr)
declare i32 @xiao_runtime_value_iter_get(ptr, i64, ptr)
declare i32 @xiao_runtime_value_iter_len(ptr, ptr)
declare i32 @xiao_runtime_value_iter_snapshot(ptr, ptr)
declare i32 @xiao_runtime_value_release_weak(ptr)
declare i32 @xiao_runtime_value_select(ptr, i64, ptr, ptr)
declare i32 @xiao_runtime_value_unary(ptr, ptr, ptr)
declare ptr @llvm.stacksave()
declare void @llvm.stackrestore(ptr)
declare void @llvm.trap()
declare void @xiao_runtime_concurrency_entry_begin()
declare void @xiao_runtime_error_checkpoint_begin()
declare void @xiao_runtime_error_checkpoint_discard()
declare void @xiao_runtime_error_checkpoint_reset()
declare void @xiao_runtime_error_clear()
declare void @xiao_runtime_error_new(ptr sret(%xiao.value) align 8, ptr, ptr, ptr, ptr)
declare void @xiao_runtime_error_new_values(ptr sret(%xiao.value) align 8, ptr, ptr, ptr, ptr)
declare void @xiao_runtime_error_push_native_frame(ptr, ptr, i64, i64)
declare void @xiao_runtime_error_report()
declare void @xiao_runtime_fatal_abi()
declare void @xiao_runtime_input_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i8, i64)
declare void @xiao_runtime_process_spawn_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_process_wait_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_release(ptr)
declare void @xiao_runtime_release_trace_begin()
declare void @xiao_runtime_release_trace_flush()
declare void @xiao_runtime_resource_open_directory_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_resource_open_file_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_resource_read_text_with_capabilities(ptr sret(%xiao.value) align 8, ptr, i64)
declare void @xiao_runtime_value_array(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_array_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_bool(ptr sret(%xiao.value) align 8, i8)
declare void @xiao_runtime_value_dict(ptr sret(%xiao.value) align 8, ptr, i32)
declare void @xiao_runtime_value_dict_owned(ptr sret(%xiao.value) align 8, ptr, i32)
declare void @xiao_runtime_value_float(ptr sret(%xiao.value) align 8, double)
declare void @xiao_runtime_value_int(ptr sret(%xiao.value) align 8, i64)
declare void @xiao_runtime_value_lfloat(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lfloat_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lint(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_lint_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_none(ptr sret(%xiao.value) align 8)
declare void @xiao_runtime_value_release_any(ptr)
declare void @xiao_runtime_value_release_strong(ptr)
declare void @xiao_runtime_value_set(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_set_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_sfloat(ptr sret(%xiao.value) align 8, float)
declare void @xiao_runtime_value_sint(ptr sret(%xiao.value) align 8, i32)
declare void @xiao_runtime_value_str(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_table(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_table_owned(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_tuple(ptr sret(%xiao.value) align 8, ptr)
declare void @xiao_runtime_value_tuple_owned(ptr sret(%xiao.value) align 8, ptr)

define void @xiao_entry() {
entry:
  %slot4 = alloca %xiao.value
  %slot0 = alloca %xiao.value
  %slot14 = alloca %xiao.value
  %slot9 = alloca %xiao.value
  %slot11 = alloca %xiao.value
  %slot3 = alloca %xiao.value
  %slot5 = alloca %xiao.value
  %slot6 = alloca %xiao.value
  %slot7 = alloca %xiao.value
  %slot10 = alloca %xiao.value
  %slot8 = alloca %xiao.value
  %slot1 = alloca %xiao.value
  %slot2 = alloca %xiao.value
  %slot12 = alloca %xiao.value
  %slot13 = alloca %xiao.value
  %t3 = alloca %xiao.bytes
  %t8 = alloca %xiao.value, i64 0
  %t9 = alloca %xiao.value
  %t13 = alloca %xiao.bytes
  %t18 = alloca %xiao.value
  %t19 = alloca %xiao.value, i64 1
  %t21 = alloca %xiao.value
  %t25 = alloca %xiao.bytes
  %t28 = alloca %xiao.value
  %t29 = alloca %xiao.value
  %t32 = alloca %xiao.value
  %t33 = alloca %xiao.value, i64 1
  %t35 = alloca %xiao.value
  %t39 = alloca %xiao.bytes
  %t42 = alloca %xiao.value
  %t43 = alloca %xiao.value
  %t45 = alloca %xiao.value
  %t52 = alloca %xiao.bytes
  %t55 = alloca %xiao.value, i64 1
  %t57 = alloca %xiao.value
  %t61 = alloca %xiao.bytes
  %t64 = alloca %xiao.value
  %t65 = alloca %xiao.value
  %t67 = alloca %xiao.value
  %t71 = alloca %xiao.value
  %t75 = alloca %xiao.value
  %t82 = alloca %xiao.bytes
  %t85 = alloca %xiao.value, i64 3
  %t89 = alloca %xiao.value
  %t93 = alloca %xiao.bytes
  %t96 = alloca %xiao.value
  %t97 = alloca %xiao.value
  %t98 = alloca %xiao.value
  %t99 = alloca %xiao.value
  %t100 = alloca %xiao.value
  %t101 = alloca %xiao.value
  %t103 = alloca %xiao.value
  %t104 = alloca %xiao.value
  %t108 = alloca %xiao.value
  %t113 = alloca %xiao.value
  %t117 = alloca %xiao.bytes
  %t118 = alloca %xiao.value
  %t119 = alloca %xiao.value
  %t120 = alloca %xiao.value
  %t124 = alloca %xiao.value
  %t125 = alloca %xiao.value
  %t126 = alloca %xiao.value
  %t127 = alloca %xiao.value
  %t132 = alloca %xiao.value
  %t134 = alloca %xiao.value
  %t135 = alloca %xiao.value
  %t139 = alloca %xiao.value, i64 1
  %t141 = alloca %xiao.value
  %t145 = alloca %xiao.bytes
  %t148 = alloca %xiao.value
  %t149 = alloca %xiao.value
  %t151 = alloca %xiao.value
  %t152 = alloca %xiao.value
  %t159 = alloca %xiao.bytes
  %t162 = alloca %xiao.value, i64 1
  %t164 = alloca %xiao.value
  %t168 = alloca %xiao.bytes
  %t171 = alloca %xiao.value
  %t172 = alloca %xiao.value
  %t174 = alloca %xiao.value
  %t180 = alloca %xiao.bytes
  %t183 = alloca %xiao.value
  %t190 = alloca %xiao.bytes
  %t191 = alloca ptr
  %t196 = alloca %xiao.value
  %t197 = alloca %xiao.value, i64 1
  %t201 = alloca %xiao.value
  %t203 = alloca %xiao.value
  %t204 = alloca %xiao.value
  call void @xiao_runtime_error_checkpoint_reset()
  call void @xiao_runtime_error_clear()
  call void @xiao_runtime_release_trace_begin()
  store %xiao.value zeroinitializer, ptr %slot4
  store %xiao.value zeroinitializer, ptr %slot0
  store %xiao.value zeroinitializer, ptr %slot14
  store %xiao.value zeroinitializer, ptr %slot9
  store %xiao.value zeroinitializer, ptr %slot11
  store %xiao.value zeroinitializer, ptr %slot3
  store %xiao.value zeroinitializer, ptr %slot5
  store %xiao.value zeroinitializer, ptr %slot6
  store %xiao.value zeroinitializer, ptr %slot7
  store %xiao.value zeroinitializer, ptr %slot10
  store %xiao.value zeroinitializer, ptr %slot8
  store %xiao.value zeroinitializer, ptr %slot1
  store %xiao.value zeroinitializer, ptr %slot2
  store %xiao.value zeroinitializer, ptr %slot12
  store %xiao.value zeroinitializer, ptr %slot13
  %t0 = getelementptr inbounds [6 x i8], ptr @.xiao.bytes0, i64 0, i64 0
  %t1 = insertvalue %xiao.bytes zeroinitializer, ptr %t0, 0
  %t2 = insertvalue %xiao.bytes %t1, i64 5, 1
  store %xiao.bytes %t2, ptr %t3
  %t4 = call i32 @xiao_runtime_language_context_set(ptr %t3)
  %t5 = icmp eq i32 %t4, 0
  br i1 %t5, label %abi.ok0, label %abi.status.fail1
abi.status.fail1:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.error.terminal
abi.ok0:
  call void @xiao_runtime_concurrency_entry_begin()
  %t6 = call i32 @xiao_runtime_abi_is_compatible(i32 1, i32 20)
  %t7 = icmp eq i32 %t6, 1
  br i1 %t7, label %abi.entry.ok, label %abi.fail
abi.entry.ok:
  store %xiao.value zeroinitializer, ptr %t9
  %t10 = getelementptr inbounds [16 x i8], ptr @.xiao.bytes1, i64 0, i64 0
  %t11 = insertvalue %xiao.bytes zeroinitializer, ptr %t10, 0
  %t12 = insertvalue %xiao.bytes %t11, i64 15, 1
  store %xiao.bytes %t12, ptr %t13
  %t14 = call i32 @xiao_runtime_concurrency_call(ptr %t13, ptr %t8, i64 0, ptr %t9)
  %t15 = icmp eq i32 %t14, 0
  br i1 %t15, label %dynamic.concurrency.ok2, label %dynamic.concurrency.fail3
dynamic.concurrency.fail3:
  call i32 @xiao_runtime_error_attach_span(i64 573, i64 590)
  br label %xiao.error.terminal
dynamic.concurrency.ok2:
  %t16 = load %xiao.value, ptr %t9
  call void @xiao_runtime_value_release_strong(ptr %slot8)
  store %xiao.value %t16, ptr %slot8
  store %xiao.value zeroinitializer, ptr %t18
  call void @xiao_runtime_value_int(ptr sret(%xiao.value) %t18, i64 7)
  %t17 = load %xiao.value, ptr %t18
  %t20 = getelementptr inbounds %xiao.value, ptr %t19, i64 0
  store %xiao.value %t17, ptr %t20
  store %xiao.value zeroinitializer, ptr %t21
  %t22 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes2, i64 0, i64 0
  %t23 = insertvalue %xiao.bytes zeroinitializer, ptr %t22, 0
  %t24 = insertvalue %xiao.bytes %t23, i64 10, 1
  store %xiao.bytes %t24, ptr %t25
  %t26 = call i32 @xiao_runtime_concurrency_call(ptr %t25, ptr %t19, i64 1, ptr %t21)
  %t27 = icmp eq i32 %t26, 0
  br i1 %t27, label %dynamic.concurrency.ok4, label %dynamic.concurrency.fail5
dynamic.concurrency.fail5:
  store %xiao.value %t17, ptr %t28
  call void @xiao_runtime_value_release_strong(ptr %t28)
  call i32 @xiao_runtime_error_attach_span(i64 598, i64 611)
  br label %xiao.error.terminal
dynamic.concurrency.ok4:
  store %xiao.value %t17, ptr %t29
  call void @xiao_runtime_value_release_strong(ptr %t29)
  %t30 = load %xiao.value, ptr %t21
  call void @xiao_runtime_value_release_strong(ptr %slot9)
  store %xiao.value %t30, ptr %slot9
  store %xiao.value zeroinitializer, ptr %t32
  call void @xiao_runtime_value_int(ptr sret(%xiao.value) %t32, i64 0)
  %t31 = load %xiao.value, ptr %t32
  %t34 = getelementptr inbounds %xiao.value, ptr %t33, i64 0
  store %xiao.value %t31, ptr %t34
  store %xiao.value zeroinitializer, ptr %t35
  %t36 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes3, i64 0, i64 0
  %t37 = insertvalue %xiao.bytes zeroinitializer, ptr %t36, 0
  %t38 = insertvalue %xiao.bytes %t37, i64 10, 1
  store %xiao.bytes %t38, ptr %t39
  %t40 = call i32 @xiao_runtime_concurrency_call(ptr %t39, ptr %t33, i64 1, ptr %t35)
  %t41 = icmp eq i32 %t40, 0
  br i1 %t41, label %dynamic.concurrency.ok6, label %dynamic.concurrency.fail7
dynamic.concurrency.fail7:
  store %xiao.value %t31, ptr %t42
  call void @xiao_runtime_value_release_strong(ptr %t42)
  call i32 @xiao_runtime_error_attach_span(i64 620, i64 633)
  br label %xiao.error.terminal
dynamic.concurrency.ok6:
  store %xiao.value %t31, ptr %t43
  call void @xiao_runtime_value_release_strong(ptr %t43)
  %t44 = load %xiao.value, ptr %t35
  call void @xiao_runtime_value_release_strong(ptr %slot10)
  store %xiao.value %t44, ptr %slot10
  store %xiao.value zeroinitializer, ptr %t45
  %t46 = call i32 @xiao_runtime_value_copy(ptr %slot9, ptr %t45)
  %t47 = icmp eq i32 %t46, 0
  br i1 %t47, label %abi.ok8, label %abi.status.fail9
abi.status.fail9:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.error.terminal
abi.ok8:
  %t48 = load %xiao.value, ptr %t45
  %t49 = getelementptr inbounds [10 x i8], ptr @.xiao.bytes4, i64 0, i64 0
  %t50 = insertvalue %xiao.bytes zeroinitializer, ptr %t49, 0
  %t51 = insertvalue %xiao.bytes %t50, i64 9, 1
  store %xiao.bytes %t51, ptr %t52
  %t53 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t52)
  %t54 = icmp eq i32 %t53, 0
  br i1 %t54, label %abi.ok10, label %abi.status.fail11
abi.status.fail11:
  call i32 @xiao_runtime_error_attach_span(i64 641, i64 651)
  br label %xiao.error.terminal
abi.ok10:
  %t56 = getelementptr inbounds %xiao.value, ptr %t55, i64 0
  store %xiao.value %t48, ptr %t56
  store %xiao.value zeroinitializer, ptr %t57
  %t58 = getelementptr inbounds [5 x i8], ptr @.xiao.bytes5, i64 0, i64 0
  %t59 = insertvalue %xiao.bytes zeroinitializer, ptr %t58, 0
  %t60 = insertvalue %xiao.bytes %t59, i64 4, 1
  store %xiao.bytes %t60, ptr %t61
  %t62 = call i32 @xiao_runtime_concurrency_call(ptr %t61, ptr %t55, i64 1, ptr %t57)
  %t63 = icmp eq i32 %t62, 0
  br i1 %t63, label %dynamic.concurrency.ok12, label %dynamic.concurrency.fail13
dynamic.concurrency.fail13:
  store %xiao.value %t48, ptr %t64
  call void @xiao_runtime_value_release_strong(ptr %t64)
  call i32 @xiao_runtime_error_attach_span(i64 641, i64 651)
  br label %xiao.error.terminal
dynamic.concurrency.ok12:
  store %xiao.value %t48, ptr %t65
  call void @xiao_runtime_value_release_strong(ptr %t65)
  %t66 = load %xiao.value, ptr %t57
  call void @xiao_runtime_value_release_strong(ptr %slot11)
  store %xiao.value %t66, ptr %slot11
  store %xiao.value zeroinitializer, ptr %t67
  %t68 = call i32 @xiao_runtime_value_copy(ptr %slot8, ptr %t67)
  %t69 = icmp eq i32 %t68, 0
  br i1 %t69, label %abi.ok14, label %abi.status.fail15
abi.status.fail15:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.error.terminal
abi.ok14:
  %t70 = load %xiao.value, ptr %t67
  store %xiao.value zeroinitializer, ptr %t71
  %t72 = call i32 @xiao_runtime_value_copy(ptr %slot9, ptr %t71)
  %t73 = icmp eq i32 %t72, 0
  br i1 %t73, label %abi.ok16, label %abi.status.fail17
abi.status.fail17:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.error.terminal
abi.ok16:
  %t74 = load %xiao.value, ptr %t71
  store %xiao.value zeroinitializer, ptr %t75
  %t76 = call i32 @xiao_runtime_value_copy(ptr %slot10, ptr %t75)
  %t77 = icmp eq i32 %t76, 0
  br i1 %t77, label %abi.ok18, label %abi.status.fail19
abi.status.fail19:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.error.terminal
abi.ok18:
  %t78 = load %xiao.value, ptr %t75
  %t79 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes6, i64 0, i64 0
  %t80 = insertvalue %xiao.bytes zeroinitializer, ptr %t79, 0
  %t81 = insertvalue %xiao.bytes %t80, i64 10, 1
  store %xiao.bytes %t81, ptr %t82
  %t83 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t82)
  %t84 = icmp eq i32 %t83, 0
  br i1 %t84, label %abi.ok20, label %abi.status.fail21
abi.status.fail21:
  call i32 @xiao_runtime_error_attach_span(i64 661, i64 691)
  br label %xiao.error.terminal
abi.ok20:
  %t86 = getelementptr inbounds %xiao.value, ptr %t85, i64 0
  store %xiao.value %t70, ptr %t86
  %t87 = getelementptr inbounds %xiao.value, ptr %t85, i64 1
  store %xiao.value %t74, ptr %t87
  %t88 = getelementptr inbounds %xiao.value, ptr %t85, i64 2
  store %xiao.value %t78, ptr %t88
  store %xiao.value zeroinitializer, ptr %t89
  %t90 = getelementptr inbounds [6 x i8], ptr @.xiao.bytes7, i64 0, i64 0
  %t91 = insertvalue %xiao.bytes zeroinitializer, ptr %t90, 0
  %t92 = insertvalue %xiao.bytes %t91, i64 5, 1
  store %xiao.bytes %t92, ptr %t93
  %t94 = call i32 @xiao_runtime_concurrency_call_with_entry(ptr %t93, ptr @xiao.concurrent.trampoline.5f60aea99e1f98b2, ptr null, ptr %t85, i64 3, ptr %t89)
  %t95 = icmp eq i32 %t94, 0
  br i1 %t95, label %dynamic.concurrency.ok22, label %dynamic.concurrency.fail23
dynamic.concurrency.fail23:
  store %xiao.value %t78, ptr %t96
  call void @xiao_runtime_value_release_strong(ptr %t96)
  store %xiao.value %t74, ptr %t97
  call void @xiao_runtime_value_release_strong(ptr %t97)
  store %xiao.value %t70, ptr %t98
  call void @xiao_runtime_value_release_strong(ptr %t98)
  call i32 @xiao_runtime_error_attach_span(i64 661, i64 691)
  br label %xiao.error.terminal
dynamic.concurrency.ok22:
  store %xiao.value %t70, ptr %t99
  call void @xiao_runtime_value_release_strong(ptr %t99)
  store %xiao.value %t74, ptr %t100
  call void @xiao_runtime_value_release_strong(ptr %t100)
  store %xiao.value %t78, ptr %t101
  call void @xiao_runtime_value_release_strong(ptr %t101)
  %t102 = load %xiao.value, ptr %t89
  call void @xiao_runtime_value_release_strong(ptr %slot12)
  store %xiao.value %t102, ptr %slot12
  br label %dynamic.while.cond24
dynamic.while.cond24:
  store %xiao.value zeroinitializer, ptr %t103
  store %xiao.value zeroinitializer, ptr %t104
  %t105 = call i32 @xiao_runtime_value_copy(ptr %slot10, ptr %t104)
  %t106 = icmp eq i32 %t105, 0
  br i1 %t106, label %abi.ok29, label %abi.status.fail30
abi.status.fail30:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %dynamic.call.arguments.fail27
abi.ok29:
  %t107 = load %xiao.value, ptr %t104
  store %xiao.value %t107, ptr %t103
  br label %dynamic.call.arguments.ready28
dynamic.call.arguments.fail27:
  call void @xiao_runtime_value_release_strong(ptr %t103)
  br label %xiao.error.terminal
dynamic.call.arguments.ready28:
  store %xiao.value zeroinitializer, ptr %t108
  call void @xiao.fn.4142de2154b7205b(ptr %t108, ptr %t103)
  call void @xiao_runtime_value_release_strong(ptr %t103)
  %t109 = call i32 @xiao_runtime_error_class()
  %t110 = icmp eq i32 %t109, 0
  br i1 %t110, label %dynamic.call.ok31, label %dynamic.call.fail32
dynamic.call.fail32:
  br label %xiao.error.terminal
dynamic.call.ok31:
  %t111 = load %xiao.value, ptr %t108
  store %xiao.value zeroinitializer, ptr %t113
  call void @xiao_runtime_value_int(ptr sret(%xiao.value) %t113, i64 0)
  %t112 = load %xiao.value, ptr %t113
  %t114 = getelementptr inbounds [3 x i8], ptr @.xiao.bytes8, i64 0, i64 0
  %t115 = insertvalue %xiao.bytes zeroinitializer, ptr %t114, 0
  %t116 = insertvalue %xiao.bytes %t115, i64 2, 1
  store %xiao.bytes %t116, ptr %t117
  store %xiao.value %t111, ptr %t118
  store %xiao.value %t112, ptr %t119
  store %xiao.value zeroinitializer, ptr %t120
  %t121 = call i32 @xiao_runtime_value_binary(ptr %t117, ptr %t118, ptr %t119, ptr %t120)
  %t122 = icmp eq i32 %t121, 0
  br i1 %t122, label %abi.ok36, label %abi.status.fail37
abi.status.fail37:
  call i32 @xiao_runtime_error_attach_span(i64 698, i64 719)
  br label %dynamic.binary.fail34
abi.ok36:
  %t123 = load %xiao.value, ptr %t120
  store %xiao.value %t111, ptr %t124
  call void @xiao_runtime_value_release_strong(ptr %t124)
  store %xiao.value %t112, ptr %t125
  call void @xiao_runtime_value_release_strong(ptr %t125)
  br label %dynamic.binary.continue35
dynamic.binary.fail34:
  store %xiao.value %t112, ptr %t126
  call void @xiao_runtime_value_release_strong(ptr %t126)
  br label %dynamic.binary.left.fail33
dynamic.binary.left.fail33:
  store %xiao.value %t111, ptr %t127
  call void @xiao_runtime_value_release_strong(ptr %t127)
  br label %xiao.error.terminal
dynamic.binary.continue35:
  %t128 = extractvalue %xiao.value %t123, 0
  %t129 = icmp eq i32 %t128, 1
  br i1 %t129, label %dynamic.bool.ok38, label %xiao.error.terminal
dynamic.bool.ok38:
  %t130 = extractvalue %xiao.value %t123, 1
  %t131 = trunc i64 %t130 to i1
  store %xiao.value %t123, ptr %t132
  call void @xiao_runtime_value_release_strong(ptr %t132)
  br i1 %t131, label %dynamic.while.body25, label %dynamic.while.end26
dynamic.while.body25:
  store %xiao.value zeroinitializer, ptr %t134
  call void @xiao_runtime_value_int(ptr sret(%xiao.value) %t134, i64 1)
  %t133 = load %xiao.value, ptr %t134
  call void @xiao_runtime_value_release_strong(ptr %slot13)
  store %xiao.value %t133, ptr %slot13
  br label %dynamic.while.cond24
dynamic.while.end26:
  store %xiao.value zeroinitializer, ptr %t135
  %t136 = call i32 @xiao_runtime_value_copy(ptr %slot12, ptr %t135)
  %t137 = icmp eq i32 %t136, 0
  br i1 %t137, label %abi.ok39, label %abi.status.fail40
abi.status.fail40:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.error.terminal
abi.ok39:
  %t138 = load %xiao.value, ptr %t135
  %t140 = getelementptr inbounds %xiao.value, ptr %t139, i64 0
  store %xiao.value %t138, ptr %t140
  store %xiao.value zeroinitializer, ptr %t141
  %t142 = getelementptr inbounds [7 x i8], ptr @.xiao.bytes9, i64 0, i64 0
  %t143 = insertvalue %xiao.bytes zeroinitializer, ptr %t142, 0
  %t144 = insertvalue %xiao.bytes %t143, i64 6, 1
  store %xiao.bytes %t144, ptr %t145
  %t146 = call i32 @xiao_runtime_concurrency_call(ptr %t145, ptr %t139, i64 1, ptr %t141)
  %t147 = icmp eq i32 %t146, 0
  br i1 %t147, label %dynamic.concurrency.ok41, label %dynamic.concurrency.fail42
dynamic.concurrency.fail42:
  store %xiao.value %t138, ptr %t148
  call void @xiao_runtime_value_release_strong(ptr %t148)
  call i32 @xiao_runtime_error_attach_span(i64 734, i64 748)
  br label %xiao.error.terminal
dynamic.concurrency.ok41:
  store %xiao.value %t138, ptr %t149
  call void @xiao_runtime_value_release_strong(ptr %t149)
  %t150 = load %xiao.value, ptr %t141
  store %xiao.value %t150, ptr %t151
  call void @xiao_runtime_value_release_strong(ptr %t151)
  store %xiao.value zeroinitializer, ptr %t152
  %t153 = call i32 @xiao_runtime_value_copy(ptr %slot12, ptr %t152)
  %t154 = icmp eq i32 %t153, 0
  br i1 %t154, label %abi.ok46, label %abi.status.fail47
abi.status.fail47:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %dynamic.try.dispatch43
abi.ok46:
  %t155 = load %xiao.value, ptr %t152
  %t156 = getelementptr inbounds [5 x i8], ptr @.xiao.bytes10, i64 0, i64 0
  %t157 = insertvalue %xiao.bytes zeroinitializer, ptr %t156, 0
  %t158 = insertvalue %xiao.bytes %t157, i64 4, 1
  store %xiao.bytes %t158, ptr %t159
  %t160 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t159)
  %t161 = icmp eq i32 %t160, 0
  br i1 %t161, label %abi.ok48, label %abi.status.fail49
abi.status.fail49:
  call i32 @xiao_runtime_error_attach_span(i64 757, i64 769)
  br label %dynamic.try.dispatch43
abi.ok48:
  %t163 = getelementptr inbounds %xiao.value, ptr %t162, i64 0
  store %xiao.value %t155, ptr %t163
  store %xiao.value zeroinitializer, ptr %t164
  %t165 = getelementptr inbounds [5 x i8], ptr @.xiao.bytes11, i64 0, i64 0
  %t166 = insertvalue %xiao.bytes zeroinitializer, ptr %t165, 0
  %t167 = insertvalue %xiao.bytes %t166, i64 4, 1
  store %xiao.bytes %t167, ptr %t168
  %t169 = call i32 @xiao_runtime_concurrency_call(ptr %t168, ptr %t162, i64 1, ptr %t164)
  %t170 = icmp eq i32 %t169, 0
  br i1 %t170, label %dynamic.concurrency.ok50, label %dynamic.concurrency.fail51
dynamic.concurrency.fail51:
  store %xiao.value %t155, ptr %t171
  call void @xiao_runtime_value_release_strong(ptr %t171)
  call i32 @xiao_runtime_error_attach_span(i64 757, i64 769)
  br label %dynamic.try.dispatch43
dynamic.concurrency.ok50:
  store %xiao.value %t155, ptr %t172
  call void @xiao_runtime_value_release_strong(ptr %t172)
  %t173 = load %xiao.value, ptr %t164
  store %xiao.value %t173, ptr %t174
  call void @xiao_runtime_value_release_strong(ptr %t174)
  br label %dynamic.try.normal44
dynamic.try.normal44:
  br label %dynamic.try.continue45
dynamic.try.dispatch43:
  %t175 = call i32 @xiao_runtime_error_class()
  %t176 = icmp eq i32 %t175, 2
  br i1 %t176, label %xiao.error.terminal, label %dynamic.try.recoverable52
dynamic.try.recoverable52:
  %t177 = getelementptr inbounds [6 x i8], ptr @.xiao.bytes12, i64 0, i64 0
  %t178 = insertvalue %xiao.bytes zeroinitializer, ptr %t177, 0
  %t179 = insertvalue %xiao.bytes %t178, i64 5, 1
  store %xiao.bytes %t179, ptr %t180
  %t181 = call i32 @xiao_runtime_error_matches(ptr %t180)
  %t182 = icmp eq i32 %t181, 1
  br i1 %t182, label %dynamic.try.catch054, label %dynamic.try.unmatched53
dynamic.try.unmatched53:
  br label %xiao.error.terminal
dynamic.try.catch054:
  br label %dynamic.try.catch0.body55
dynamic.try.catch0.body55:
  store %xiao.value zeroinitializer, ptr %t183
  %t184 = call i32 @xiao_runtime_error_take(ptr %t183)
  %t185 = icmp eq i32 %t184, 0
  br i1 %t185, label %abi.ok56, label %abi.status.fail57
abi.status.fail57:
  call i32 @xiao_runtime_error_attach_span(i64 770, i64 817)
  br label %xiao.error.terminal
abi.ok56:
  %t186 = load %xiao.value, ptr %t183
  call void @xiao_runtime_value_release_strong(ptr %slot14)
  store %xiao.value %t186, ptr %slot14
  %t187 = getelementptr inbounds [15 x i8], ptr @.xiao.str13, i64 0, i64 0
  %t188 = insertvalue %xiao.bytes zeroinitializer, ptr %t187, 0
  %t189 = insertvalue %xiao.bytes %t188, i64 14, 1
  store %xiao.bytes %t189, ptr %t190
  store ptr null, ptr %t191
  %t192 = call i32 @xiao_runtime_string_new(ptr %t190, ptr %t191)
  %t193 = icmp eq i32 %t192, 0
  br i1 %t193, label %abi.ok59, label %abi.status.fail60
abi.status.fail60:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %dynamic.try.catch0.fail58
abi.ok59:
  %t194 = load ptr, ptr %t191
  store %xiao.value zeroinitializer, ptr %t196
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t196, ptr %t194)
  %t195 = load %xiao.value, ptr %t196
  %t198 = getelementptr inbounds %xiao.value, ptr %t197, i64 0
  store %xiao.value %t195, ptr %t198
  %t199 = call i32 @xiao_runtime_print_values_with_capabilities(ptr %t197, i64 1, i64 127)
  %t200 = icmp eq i32 %t199, 0
  br i1 %t200, label %abi.ok61, label %abi.status.fail62
abi.status.fail62:
  call i32 @xiao_runtime_error_attach_span(i64 793, i64 816)
  br label %dynamic.try.catch0.fail58
abi.ok61:
  store %xiao.value %t195, ptr %t201
  call void @xiao_runtime_value_release_strong(ptr %t201)
  store %xiao.value zeroinitializer, ptr %t203
  call void @xiao_runtime_value_none(ptr sret(%xiao.value) %t203)
  %t202 = load %xiao.value, ptr %t203
  store %xiao.value %t202, ptr %t204
  call void @xiao_runtime_value_release_strong(ptr %t204)
  call void @xiao_runtime_value_release_strong(ptr %slot14)
  br label %dynamic.try.continue45
dynamic.try.catch0.fail58:
  %t205 = call i32 @xiao_runtime_error_class()
  %t206 = icmp eq i32 %t205, 2
  br i1 %t206, label %xiao.error.terminal, label %dynamic.error-cleanup.recoverable63
dynamic.error-cleanup.recoverable63:
  call void @xiao_runtime_value_release_strong(ptr %slot14)
  br label %xiao.error.terminal
dynamic.try.continue45:
  call void @xiao_runtime_value_release_strong(ptr %slot12)
  call void @xiao_runtime_value_release_strong(ptr %slot11)
  call void @xiao_runtime_value_release_strong(ptr %slot8)
  call void @xiao_runtime_value_release_strong(ptr %slot9)
  call void @xiao_runtime_value_release_strong(ptr %slot10)
  call i32 @xiao_runtime_concurrency_finish()
  %t207 = call i32 @xiao_runtime_error_class()
  %t208 = icmp eq i32 %t207, 0
  br i1 %t208, label %abi.ok64, label %abi.status.fail65
abi.status.fail65:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.error.terminal
abi.ok64:
  call void @xiao_runtime_release_trace_flush()
  ret void
xiao.error.terminal:
  %t209 = call i32 @xiao_runtime_error_class()
  %t210 = icmp eq i32 %t209, 2
  br i1 %t210, label %xiao.error.report66, label %xiao.error.unmatched67
xiao.error.unmatched67:
  call void @xiao_runtime_value_release_strong(ptr %slot12)
  call void @xiao_runtime_value_release_strong(ptr %slot11)
  call void @xiao_runtime_value_release_strong(ptr %slot10)
  call void @xiao_runtime_value_release_strong(ptr %slot9)
  call void @xiao_runtime_value_release_strong(ptr %slot8)
  call void @xiao_runtime_value_release_strong(ptr %slot9)
  call void @xiao_runtime_value_release_strong(ptr %slot10)
  br label %xiao.error.report66
xiao.error.report66:
  call i32 @xiao_runtime_concurrency_finish()
  call void @xiao_runtime_error_report()
  call void @xiao_runtime_release_trace_flush()
  %t211 = call i32 @xiao_runtime_error_exit_code()
  ret void
abi.fail:
  call void @xiao_runtime_fatal_abi()
  unreachable
}

define i32 @main() {
entry:
  call void @xiao_entry()
  %xiao_exit_code = call i32 @xiao_runtime_error_exit_code()
  ret i32 %xiao_exit_code
}

define i32 @xiao.concurrent.trampoline.d6e20fff9a137c42(ptr %xiao.context, ptr %xiao.arguments, i64 %xiao.argument.count, ptr %xiao.result) {
entry:
  %xiao.count.ok = icmp eq i64 %xiao.argument.count, 1
  br i1 %xiao.count.ok, label %xiao.invoke, label %xiao.invalid
xiao.invalid:
  ret i32 2
xiao.invoke:
  %xiao.arg.0 = getelementptr inbounds %xiao.value, ptr %xiao.arguments, i64 0
  call void @xiao.fn.4142de2154b7205b(ptr %xiao.result, ptr %xiao.arg.0)
  %xiao.error.class = call i32 @xiao_runtime_error_class()
  ret i32 %xiao.error.class
}

define i32 @xiao.concurrent.trampoline.5f60aea99e1f98b2(ptr %xiao.context, ptr %xiao.arguments, i64 %xiao.argument.count, ptr %xiao.result) {
entry:
  %xiao.count.ok = icmp eq i64 %xiao.argument.count, 2
  br i1 %xiao.count.ok, label %xiao.invoke, label %xiao.invalid
xiao.invalid:
  ret i32 2
xiao.invoke:
  %xiao.arg.0 = getelementptr inbounds %xiao.value, ptr %xiao.arguments, i64 0
  %xiao.arg.1 = getelementptr inbounds %xiao.value, ptr %xiao.arguments, i64 1
  call void @xiao.fn.2d7ff1e31eabfb8e(ptr %xiao.result, ptr %xiao.arg.0, ptr %xiao.arg.1)
  %xiao.error.class = call i32 @xiao_runtime_error_class()
  ret i32 %xiao.error.class
}

define i32 @xiao.concurrent.trampoline.e28927aed751589f(ptr %xiao.context, ptr %xiao.arguments, i64 %xiao.argument.count, ptr %xiao.result) {
entry:
  %xiao.count.ok = icmp eq i64 %xiao.argument.count, 2
  br i1 %xiao.count.ok, label %xiao.invoke, label %xiao.invalid
xiao.invalid:
  ret i32 2
xiao.invoke:
  %xiao.arg.0 = getelementptr inbounds %xiao.value, ptr %xiao.arguments, i64 0
  %xiao.arg.1 = getelementptr inbounds %xiao.value, ptr %xiao.arguments, i64 1
  call void @xiao.fn.15caa14cc209c2c0(ptr %xiao.result, ptr %xiao.arg.0, ptr %xiao.arg.1)
  %xiao.error.class = call i32 @xiao_runtime_error_class()
  ret i32 %xiao.error.class
}

define void @xiao.fn.4142de2154b7205b(ptr %xiao.function.result, ptr %xiao.arg0) {
entry:
  %xiao.return.site0 = alloca %xiao.value
  %xiao.return.source = alloca ptr
  %xiao.return.temporary = alloca i1
  %slot1 = alloca %xiao.value
  %slot0 = alloca %xiao.value
  %t6 = alloca %xiao.bytes
  %t9 = alloca %xiao.value
  %t16 = alloca %xiao.bytes
  %t19 = alloca %xiao.value, i64 1
  %t21 = alloca %xiao.value
  %t25 = alloca %xiao.bytes
  %t28 = alloca %xiao.value
  %t29 = alloca %xiao.value
  %t34 = alloca %xiao.bytes
  %t37 = alloca %xiao.value
  %t41 = alloca %xiao.value, i64 1
  %t43 = alloca %xiao.value
  %t47 = alloca %xiao.bytes
  %t50 = alloca %xiao.value
  %t51 = alloca %xiao.value
  %t68 = alloca %xiao.bytes
  %t72 = alloca %xiao.bytes
  store %xiao.value zeroinitializer, ptr %xiao.return.site0
  store ptr null, ptr %xiao.return.source
  store i1 false, ptr %xiao.return.temporary
  store %xiao.value zeroinitializer, ptr %slot1
  store %xiao.value zeroinitializer, ptr %slot0
  %t0 = call i32 @xiao_runtime_value_copy(ptr %xiao.arg0, ptr %slot1)
  %t1 = icmp eq i32 %t0, 0
  br i1 %t1, label %abi.ok0, label %abi.status.fail1
abi.status.fail1:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.fn.error
abi.ok0:
  %t2 = load %xiao.value, ptr %slot1
  %t3 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes14, i64 0, i64 0
  %t4 = insertvalue %xiao.bytes zeroinitializer, ptr %t3, 0
  %t5 = insertvalue %xiao.bytes %t4, i64 10, 1
  store %xiao.bytes %t5, ptr %t6
  %t7 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t6)
  %t8 = icmp eq i32 %t7, 0
  br i1 %t8, label %abi.ok2, label %abi.status.fail3
abi.status.fail3:
  call i32 @xiao_runtime_error_attach_span(i64 152, i64 170)
  br label %xiao.fn.error
abi.ok2:
  store %xiao.value zeroinitializer, ptr %t9
  %t10 = call i32 @xiao_runtime_value_copy(ptr %slot1, ptr %t9)
  %t11 = icmp eq i32 %t10, 0
  br i1 %t11, label %abi.ok4, label %abi.status.fail5
abi.status.fail5:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.fn.error
abi.ok4:
  %t12 = load %xiao.value, ptr %t9
  %t13 = getelementptr inbounds [10 x i8], ptr @.xiao.bytes15, i64 0, i64 0
  %t14 = insertvalue %xiao.bytes zeroinitializer, ptr %t13, 0
  %t15 = insertvalue %xiao.bytes %t14, i64 9, 1
  store %xiao.bytes %t15, ptr %t16
  %t17 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t16)
  %t18 = icmp eq i32 %t17, 0
  br i1 %t18, label %abi.ok6, label %abi.status.fail7
abi.status.fail7:
  call i32 @xiao_runtime_error_attach_span(i64 160, i64 170)
  br label %xiao.fn.error
abi.ok6:
  %t20 = getelementptr inbounds %xiao.value, ptr %t19, i64 0
  store %xiao.value %t12, ptr %t20
  store %xiao.value zeroinitializer, ptr %t21
  %t22 = getelementptr inbounds [5 x i8], ptr @.xiao.bytes16, i64 0, i64 0
  %t23 = insertvalue %xiao.bytes zeroinitializer, ptr %t22, 0
  %t24 = insertvalue %xiao.bytes %t23, i64 4, 1
  store %xiao.bytes %t24, ptr %t25
  %t26 = call i32 @xiao_runtime_concurrency_call(ptr %t25, ptr %t19, i64 1, ptr %t21)
  %t27 = icmp eq i32 %t26, 0
  br i1 %t27, label %dynamic.concurrency.ok8, label %dynamic.concurrency.fail9
dynamic.concurrency.fail9:
  store %xiao.value %t12, ptr %t28
  call void @xiao_runtime_value_release_strong(ptr %t28)
  call i32 @xiao_runtime_error_attach_span(i64 160, i64 170)
  br label %xiao.fn.error
dynamic.concurrency.ok8:
  store %xiao.value %t12, ptr %t29
  call void @xiao_runtime_value_release_strong(ptr %t29)
  %t30 = load %xiao.value, ptr %t21
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  store %xiao.value %t30, ptr %slot0
  %t31 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes17, i64 0, i64 0
  %t32 = insertvalue %xiao.bytes zeroinitializer, ptr %t31, 0
  %t33 = insertvalue %xiao.bytes %t32, i64 10, 1
  store %xiao.bytes %t33, ptr %t34
  %t35 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t34)
  %t36 = icmp eq i32 %t35, 0
  br i1 %t36, label %abi.ok10, label %abi.status.fail11
abi.status.fail11:
  call i32 @xiao_runtime_error_attach_span(i64 175, i64 198)
  br label %xiao.fn.error
abi.ok10:
  store %xiao.value zeroinitializer, ptr %t37
  %t38 = call i32 @xiao_runtime_value_copy(ptr %slot0, ptr %t37)
  %t39 = icmp eq i32 %t38, 0
  br i1 %t39, label %abi.ok12, label %abi.status.fail13
abi.status.fail13:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.fn.error
abi.ok12:
  %t40 = load %xiao.value, ptr %t37
  %t42 = getelementptr inbounds %xiao.value, ptr %t41, i64 0
  store %xiao.value %t40, ptr %t42
  store %xiao.value zeroinitializer, ptr %t43
  %t44 = getelementptr inbounds [10 x i8], ptr @.xiao.bytes18, i64 0, i64 0
  %t45 = insertvalue %xiao.bytes zeroinitializer, ptr %t44, 0
  %t46 = insertvalue %xiao.bytes %t45, i64 9, 1
  store %xiao.bytes %t46, ptr %t47
  %t48 = call i32 @xiao_runtime_concurrency_call(ptr %t47, ptr %t41, i64 1, ptr %t43)
  %t49 = icmp eq i32 %t48, 0
  br i1 %t49, label %dynamic.concurrency.ok14, label %dynamic.concurrency.fail15
dynamic.concurrency.fail15:
  store %xiao.value %t40, ptr %t50
  call void @xiao_runtime_value_release_strong(ptr %t50)
  call i32 @xiao_runtime_error_attach_span(i64 182, i64 198)
  br label %xiao.fn.error
dynamic.concurrency.ok14:
  store %xiao.value %t40, ptr %t51
  call void @xiao_runtime_value_release_strong(ptr %t51)
  %t52 = load %xiao.value, ptr %t43
  call void @xiao_runtime_error_clear()
  call void @xiao_runtime_value_release_strong(ptr %xiao.return.site0)
  store %xiao.value %t52, ptr %xiao.return.site0
  store ptr %xiao.return.site0, ptr %xiao.return.source
  store i1 true, ptr %xiao.return.temporary
  br label %xiao.fn.return
xiao.fn.return:
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  call void @xiao_runtime_value_release_strong(ptr %slot1)
  %t53 = call i32 @xiao_runtime_error_class()
  %t54 = icmp eq i32 %t53, 0
  br i1 %t54, label %abi.ok16, label %abi.status.fail17
abi.status.fail17:
  call i32 @xiao_runtime_error_attach_span(i64 105, i64 199)
  br label %xiao.fn.error
abi.ok16:
  %t55 = load ptr, ptr %xiao.return.source
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %xiao.fn.return.value, label %xiao.fn.return.cleanup
xiao.fn.return.value:
  %t57 = load i1, ptr %xiao.return.temporary
  br i1 %t57, label %xiao.fn.return.copy, label %xiao.fn.return.move
xiao.fn.return.copy:
  %t58 = call i32 @xiao_runtime_value_copy(ptr %t55, ptr %xiao.function.result)
  %t59 = icmp eq i32 %t58, 0
  br i1 %t59, label %abi.ok18, label %abi.status.fail19
abi.status.fail19:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.fn.error
abi.ok18:
  br label %xiao.fn.return.cleanup
xiao.fn.return.move:
  %t60 = load %xiao.value, ptr %t55
  store %xiao.value %t60, ptr %xiao.function.result
  store %xiao.value zeroinitializer, ptr %t55
  br label %xiao.fn.return.cleanup
xiao.fn.return.cleanup:
  call void @xiao_runtime_value_release_strong(ptr %xiao.return.site0)
  %t61 = call i32 @xiao_runtime_error_class()
  %t62 = icmp eq i32 %t61, 0
  br i1 %t62, label %abi.ok20, label %abi.status.fail21
abi.status.fail21:
  call i32 @xiao_runtime_error_attach_span(i64 105, i64 199)
  br label %xiao.fn.error
abi.ok20:
  ret void
xiao.fn.error:
  %t63 = call i32 @xiao_runtime_error_class()
  %t64 = icmp eq i32 %t63, 2
  br i1 %t64, label %xiao.fn.error.return, label %xiao.fn.error.cleanup
xiao.fn.error.cleanup:
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  call void @xiao_runtime_value_release_strong(ptr %slot1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.return.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.function.result)
  br label %xiao.fn.error.return
xiao.fn.error.return:
  %t65 = getelementptr inbounds [6 x i8], ptr @.xiao.bytes19, i64 0, i64 0
  %t66 = insertvalue %xiao.bytes zeroinitializer, ptr %t65, 0
  %t67 = insertvalue %xiao.bytes %t66, i64 5, 1
  store %xiao.bytes %t67, ptr %t68
  %t69 = getelementptr inbounds [10 x i8], ptr @.xiao.bytes20, i64 0, i64 0
  %t70 = insertvalue %xiao.bytes zeroinitializer, ptr %t69, 0
  %t71 = insertvalue %xiao.bytes %t70, i64 9, 1
  store %xiao.bytes %t71, ptr %t72
  call void @xiao_runtime_error_push_native_frame(ptr %t68, ptr %t72, i64 105, i64 199)
  store %xiao.value zeroinitializer, ptr %xiao.function.result
  ret void
}

define void @xiao.fn.2d7ff1e31eabfb8e(ptr %xiao.function.result, ptr %xiao.arg0, ptr %xiao.arg1) {
entry:
  %xiao.return.site0 = alloca %xiao.value
  %xiao.return.site1 = alloca %xiao.value
  %xiao.return.source = alloca ptr
  %xiao.return.temporary = alloca i1
  %slot1 = alloca %xiao.value
  %slot0 = alloca %xiao.value
  %slot2 = alloca %xiao.value
  %t9 = alloca %xiao.bytes
  %t15 = alloca %xiao.bytes
  %t18 = alloca %xiao.value
  %t19 = alloca %xiao.value
  %t20 = alloca %xiao.value
  %t25 = alloca %xiao.value
  %t26 = alloca %xiao.value
  %t30 = alloca %xiao.value
  %t34 = alloca %xiao.bytes
  %t37 = alloca %xiao.value
  %t44 = alloca %xiao.bytes
  %t47 = alloca %xiao.value, i64 1
  %t49 = alloca %xiao.value
  %t53 = alloca %xiao.bytes
  %t56 = alloca %xiao.value
  %t57 = alloca %xiao.value
  %t62 = alloca %xiao.bytes
  %t65 = alloca %xiao.value
  %t69 = alloca %xiao.value, i64 1
  %t71 = alloca %xiao.value
  %t75 = alloca %xiao.bytes
  %t78 = alloca %xiao.value
  %t79 = alloca %xiao.value
  %t85 = alloca %xiao.bytes
  %t86 = alloca ptr
  %t91 = alloca %xiao.value
  %t92 = alloca %xiao.value, i64 1
  %t96 = alloca %xiao.value
  %t98 = alloca %xiao.value
  %t99 = alloca %xiao.value
  %t103 = alloca %xiao.bytes
  %t104 = alloca ptr
  %t109 = alloca %xiao.value
  %t110 = alloca %xiao.value
  %t114 = alloca %xiao.bytes
  %t115 = alloca %xiao.error.location
  %t120 = alloca %xiao.value
  %t121 = alloca %xiao.value
  %t124 = alloca %xiao.value
  %t125 = alloca %xiao.error.location
  %t137 = alloca %xiao.bytes
  %t138 = alloca ptr
  %t143 = alloca %xiao.value
  %t144 = alloca %xiao.value, i64 1
  %t148 = alloca %xiao.value
  %t150 = alloca %xiao.value
  %t151 = alloca %xiao.value
  %t155 = alloca %xiao.bytes
  %t156 = alloca ptr
  %t161 = alloca %xiao.value
  %t162 = alloca %xiao.value
  %t166 = alloca %xiao.bytes
  %t167 = alloca %xiao.error.location
  %t172 = alloca %xiao.value
  %t173 = alloca %xiao.value
  %t176 = alloca %xiao.value
  %t177 = alloca %xiao.error.location
  %t191 = alloca %xiao.bytes
  %t192 = alloca ptr
  %t197 = alloca %xiao.value
  %t198 = alloca %xiao.value, i64 1
  %t202 = alloca %xiao.value
  %t204 = alloca %xiao.value
  %t205 = alloca %xiao.value
  %t209 = alloca %xiao.bytes
  %t210 = alloca ptr
  %t215 = alloca %xiao.value
  %t216 = alloca %xiao.value
  %t220 = alloca %xiao.bytes
  %t221 = alloca %xiao.error.location
  %t226 = alloca %xiao.value
  %t227 = alloca %xiao.value
  %t230 = alloca %xiao.value
  %t231 = alloca %xiao.error.location
  %t242 = alloca %xiao.bytes
  %t246 = alloca %xiao.value
  %t262 = alloca %xiao.bytes
  %t266 = alloca %xiao.bytes
  store %xiao.value zeroinitializer, ptr %xiao.return.site0
  store %xiao.value zeroinitializer, ptr %xiao.return.site1
  store ptr null, ptr %xiao.return.source
  store i1 false, ptr %xiao.return.temporary
  store %xiao.value zeroinitializer, ptr %slot1
  store %xiao.value zeroinitializer, ptr %slot0
  store %xiao.value zeroinitializer, ptr %slot2
  %t0 = call i32 @xiao_runtime_value_copy(ptr %xiao.arg0, ptr %slot1)
  %t1 = icmp eq i32 %t0, 0
  br i1 %t1, label %abi.ok0, label %abi.status.fail1
abi.status.fail1:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.fn.error
abi.ok0:
  %t2 = call i32 @xiao_runtime_value_copy(ptr %xiao.arg1, ptr %slot2)
  %t3 = icmp eq i32 %t2, 0
  br i1 %t3, label %abi.ok2, label %abi.status.fail3
abi.status.fail3:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.fn.error
abi.ok2:
  %t4 = load %xiao.value, ptr %slot1
  %t5 = load %xiao.value, ptr %slot2
  %t6 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes21, i64 0, i64 0
  %t7 = insertvalue %xiao.bytes zeroinitializer, ptr %t6, 0
  %t8 = insertvalue %xiao.bytes %t7, i64 10, 1
  store %xiao.bytes %t8, ptr %t9
  %t10 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t9)
  %t11 = icmp eq i32 %t10, 0
  br i1 %t11, label %abi.ok4, label %abi.status.fail5
abi.status.fail5:
  call i32 @xiao_runtime_error_attach_span(i64 374, i64 559)
  br label %xiao.fn.error
abi.ok4:
  %t12 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes22, i64 0, i64 0
  %t13 = insertvalue %xiao.bytes zeroinitializer, ptr %t12, 0
  %t14 = insertvalue %xiao.bytes %t13, i64 10, 1
  store %xiao.bytes %t14, ptr %t15
  %t16 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t15)
  %t17 = icmp eq i32 %t16, 0
  br i1 %t17, label %abi.ok9, label %abi.status.fail10
abi.status.fail10:
  call i32 @xiao_runtime_error_attach_span(i64 386, i64 406)
  br label %dynamic.try.dispatch6
abi.ok9:
  store %xiao.value zeroinitializer, ptr %t18
  store %xiao.value zeroinitializer, ptr %t19
  store %xiao.value zeroinitializer, ptr %t20
  %t21 = call i32 @xiao_runtime_value_copy(ptr %slot2, ptr %t20)
  %t22 = icmp eq i32 %t21, 0
  br i1 %t22, label %abi.ok13, label %abi.status.fail14
abi.status.fail14:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %dynamic.call.arguments.fail11
abi.ok13:
  %t23 = load %xiao.value, ptr %t20
  store %xiao.value %t23, ptr %t18
  store %xiao.value zeroinitializer, ptr %t25
  call void @xiao_runtime_value_int(ptr sret(%xiao.value) %t25, i64 1)
  %t24 = load %xiao.value, ptr %t25
  store %xiao.value %t24, ptr %t19
  br label %dynamic.call.arguments.ready12
dynamic.call.arguments.fail11:
  call void @xiao_runtime_value_release_strong(ptr %t18)
  call void @xiao_runtime_value_release_strong(ptr %t19)
  br label %dynamic.try.dispatch6
dynamic.call.arguments.ready12:
  store %xiao.value zeroinitializer, ptr %t26
  call void @xiao.fn.15caa14cc209c2c0(ptr %t26, ptr %t18, ptr %t19)
  call void @xiao_runtime_value_release_strong(ptr %t18)
  call void @xiao_runtime_value_release_strong(ptr %t19)
  %t27 = call i32 @xiao_runtime_error_class()
  %t28 = icmp eq i32 %t27, 0
  br i1 %t28, label %dynamic.call.ok15, label %dynamic.call.fail16
dynamic.call.fail16:
  br label %dynamic.try.dispatch6
dynamic.call.ok15:
  %t29 = load %xiao.value, ptr %t26
  store %xiao.value %t29, ptr %t30
  call void @xiao_runtime_value_release_strong(ptr %t30)
  %t31 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes23, i64 0, i64 0
  %t32 = insertvalue %xiao.bytes zeroinitializer, ptr %t31, 0
  %t33 = insertvalue %xiao.bytes %t32, i64 10, 1
  store %xiao.bytes %t33, ptr %t34
  %t35 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t34)
  %t36 = icmp eq i32 %t35, 0
  br i1 %t36, label %abi.ok17, label %abi.status.fail18
abi.status.fail18:
  call i32 @xiao_runtime_error_attach_span(i64 415, i64 433)
  br label %dynamic.try.dispatch6
abi.ok17:
  store %xiao.value zeroinitializer, ptr %t37
  %t38 = call i32 @xiao_runtime_value_copy(ptr %slot1, ptr %t37)
  %t39 = icmp eq i32 %t38, 0
  br i1 %t39, label %abi.ok19, label %abi.status.fail20
abi.status.fail20:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %dynamic.try.dispatch6
abi.ok19:
  %t40 = load %xiao.value, ptr %t37
  %t41 = getelementptr inbounds [10 x i8], ptr @.xiao.bytes24, i64 0, i64 0
  %t42 = insertvalue %xiao.bytes zeroinitializer, ptr %t41, 0
  %t43 = insertvalue %xiao.bytes %t42, i64 9, 1
  store %xiao.bytes %t43, ptr %t44
  %t45 = call i32 @wait_for_lock_cancel(ptr %t44)
  %t46 = icmp eq i32 %t45, 0
  br i1 %t46, label %abi.ok21, label %abi.status.fail22
abi.status.fail22:
  call void @xiao_runtime_value_release_strong(ptr %t37)
  call i32 @xiao_runtime_error_attach_span(i64 423, i64 433)
  br label %dynamic.try.dispatch6
abi.ok21:
  %t48 = getelementptr inbounds %xiao.value, ptr %t47, i64 0
  store %xiao.value %t40, ptr %t48
  store %xiao.value zeroinitializer, ptr %t49
  %t50 = getelementptr inbounds [5 x i8], ptr @.xiao.bytes25, i64 0, i64 0
  %t51 = insertvalue %xiao.bytes zeroinitializer, ptr %t50, 0
  %t52 = insertvalue %xiao.bytes %t51, i64 4, 1
  store %xiao.bytes %t52, ptr %t53
  %t54 = call i32 @xiao_runtime_concurrency_call(ptr %t53, ptr %t47, i64 1, ptr %t49)
  %t55 = icmp eq i32 %t54, 0
  br i1 %t55, label %dynamic.concurrency.ok23, label %dynamic.concurrency.fail24
dynamic.concurrency.fail24:
  store %xiao.value %t40, ptr %t56
  call void @xiao_runtime_value_release_strong(ptr %t56)
  call i32 @xiao_runtime_error_attach_span(i64 423, i64 433)
  br label %dynamic.try.dispatch6
dynamic.concurrency.ok23:
  store %xiao.value %t40, ptr %t57
  call void @xiao_runtime_value_release_strong(ptr %t57)
  %t58 = load %xiao.value, ptr %t49
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  store %xiao.value %t58, ptr %slot0
  %t59 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes26, i64 0, i64 0
  %t60 = insertvalue %xiao.bytes zeroinitializer, ptr %t59, 0
  %t61 = insertvalue %xiao.bytes %t60, i64 10, 1
  store %xiao.bytes %t61, ptr %t62
  %t63 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t62)
  %t64 = icmp eq i32 %t63, 0
  br i1 %t64, label %abi.ok25, label %abi.status.fail26
abi.status.fail26:
  call i32 @xiao_runtime_error_attach_span(i64 442, i64 465)
  br label %dynamic.try.dispatch6
abi.ok25:
  store %xiao.value zeroinitializer, ptr %t65
  %t66 = call i32 @xiao_runtime_value_copy(ptr %slot0, ptr %t65)
  %t67 = icmp eq i32 %t66, 0
  br i1 %t67, label %abi.ok27, label %abi.status.fail28
abi.status.fail28:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %dynamic.try.dispatch6
abi.ok27:
  %t68 = load %xiao.value, ptr %t65
  %t70 = getelementptr inbounds %xiao.value, ptr %t69, i64 0
  store %xiao.value %t68, ptr %t70
  store %xiao.value zeroinitializer, ptr %t71
  %t72 = getelementptr inbounds [10 x i8], ptr @.xiao.bytes27, i64 0, i64 0
  %t73 = insertvalue %xiao.bytes zeroinitializer, ptr %t72, 0
  %t74 = insertvalue %xiao.bytes %t73, i64 9, 1
  store %xiao.bytes %t74, ptr %t75
  %t76 = call i32 @xiao_runtime_concurrency_call(ptr %t75, ptr %t69, i64 1, ptr %t71)
  %t77 = icmp eq i32 %t76, 0
  br i1 %t77, label %dynamic.concurrency.ok29, label %dynamic.concurrency.fail30
dynamic.concurrency.fail30:
  store %xiao.value %t68, ptr %t78
  call void @xiao_runtime_value_release_strong(ptr %t78)
  call i32 @xiao_runtime_error_attach_span(i64 449, i64 465)
  br label %dynamic.try.dispatch6
dynamic.concurrency.ok29:
  store %xiao.value %t68, ptr %t79
  call void @xiao_runtime_value_release_strong(ptr %t79)
  %t80 = load %xiao.value, ptr %t71
  call void @xiao_runtime_error_clear()
  call void @xiao_runtime_value_release_strong(ptr %xiao.return.site0)
  store %xiao.value %t80, ptr %xiao.return.site0
  store ptr %xiao.return.site0, ptr %xiao.return.source
  store i1 true, ptr %xiao.return.temporary
  call void @xiao_runtime_error_checkpoint_begin()
  %t81 = call ptr @llvm.stacksave()
  %t82 = getelementptr inbounds [13 x i8], ptr @.xiao.str28, i64 0, i64 0
  %t83 = insertvalue %xiao.bytes zeroinitializer, ptr %t82, 0
  %t84 = insertvalue %xiao.bytes %t83, i64 12, 1
  store %xiao.bytes %t84, ptr %t85
  store ptr null, ptr %t86
  %t87 = call i32 @xiao_runtime_string_new(ptr %t85, ptr %t86)
  %t88 = icmp eq i32 %t87, 0
  br i1 %t88, label %abi.ok33, label %abi.status.fail34
abi.status.fail34:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %dynamic.nonlocal.finally.fail31
abi.ok33:
  %t89 = load ptr, ptr %t86
  store %xiao.value zeroinitializer, ptr %t91
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t91, ptr %t89)
  %t90 = load %xiao.value, ptr %t91
  %t93 = getelementptr inbounds %xiao.value, ptr %t92, i64 0
  store %xiao.value %t90, ptr %t93
  %t94 = call i32 @xiao_runtime_print_values_with_capabilities(ptr %t92, i64 1, i64 127)
  %t95 = icmp eq i32 %t94, 0
  br i1 %t95, label %abi.ok35, label %abi.status.fail36
abi.status.fail36:
  call i32 @xiao_runtime_error_attach_span(i64 486, i64 507)
  br label %dynamic.nonlocal.finally.fail31
abi.ok35:
  store %xiao.value %t90, ptr %t96
  call void @xiao_runtime_value_release_strong(ptr %t96)
  store %xiao.value zeroinitializer, ptr %t98
  call void @xiao_runtime_value_none(ptr sret(%xiao.value) %t98)
  %t97 = load %xiao.value, ptr %t98
  store %xiao.value %t97, ptr %t99
  call void @xiao_runtime_value_release_strong(ptr %t99)
  %t100 = getelementptr inbounds [13 x i8], ptr @.xiao.str29, i64 0, i64 0
  %t101 = insertvalue %xiao.bytes zeroinitializer, ptr %t100, 0
  %t102 = insertvalue %xiao.bytes %t101, i64 12, 1
  store %xiao.bytes %t102, ptr %t103
  store ptr null, ptr %t104
  %t105 = call i32 @xiao_runtime_string_new(ptr %t103, ptr %t104)
  %t106 = icmp eq i32 %t105, 0
  br i1 %t106, label %abi.ok37, label %abi.status.fail38
abi.status.fail38:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %dynamic.nonlocal.finally.fail31
abi.ok37:
  %t107 = load ptr, ptr %t104
  store %xiao.value zeroinitializer, ptr %t109
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t109, ptr %t107)
  %t108 = load %xiao.value, ptr %t109
  store %xiao.value %t108, ptr %t110
  %t111 = getelementptr inbounds [10 x i8], ptr @.xiao.bytes30, i64 0, i64 0
  %t112 = insertvalue %xiao.bytes zeroinitializer, ptr %t111, 0
  %t113 = insertvalue %xiao.bytes %t112, i64 9, 1
  store %xiao.bytes %t113, ptr %t114
  %t116 = insertvalue %xiao.error.location zeroinitializer, i64 522, 0
  %t117 = insertvalue %xiao.error.location %t116, i64 554, 1
  %t118 = insertvalue %xiao.error.location %t117, i8 1, 2
  store %xiao.error.location %t118, ptr %t115
  store %xiao.value zeroinitializer, ptr %t120
  call void @xiao_runtime_error_new_values(ptr sret(%xiao.value) %t120, ptr %t114, ptr %t110, ptr null, ptr %t115)
  %t119 = load %xiao.value, ptr %t120
  store %xiao.value %t108, ptr %t121
  call void @xiao_runtime_value_release_strong(ptr %t121)
  %t122 = call i32 @xiao_runtime_error_class()
  %t123 = icmp eq i32 %t122, 0
  br i1 %t123, label %abi.error.ok39, label %abi.error.fail40
abi.error.fail40:
  call i32 @xiao_runtime_error_attach_span(i64 522, i64 554)
  br label %dynamic.nonlocal.finally.fail31
abi.error.ok39:
  store %xiao.value %t119, ptr %t124
  %t126 = insertvalue %xiao.error.location zeroinitializer, i64 516, 0
  %t127 = insertvalue %xiao.error.location %t126, i64 554, 1
  %t128 = insertvalue %xiao.error.location %t127, i8 1, 2
  store %xiao.error.location %t128, ptr %t125
  %t129 = call i32 @xiao_runtime_error_raise_value(ptr %t124, ptr %t125)
  call void @xiao_runtime_value_release_strong(ptr %t124)
  %t130 = icmp eq i32 %t129, 0
  br i1 %t130, label %abi.ok41, label %abi.status.fail42
abi.status.fail42:
  call i32 @xiao_runtime_error_attach_span(i64 516, i64 554)
  br label %dynamic.nonlocal.finally.fail31
abi.ok41:
  br label %dynamic.nonlocal.finally.fail31
dynamic.nonlocal.finally.fail31:
  call i32 @xiao_runtime_error_checkpoint_finish()
  call void @llvm.stackrestore(ptr %t81)
  %t131 = call i32 @xiao_runtime_error_class()
  %t132 = icmp eq i32 %t131, 2
  br i1 %t132, label %xiao.fn.error, label %dynamic.error-cleanup.recoverable43
dynamic.error-cleanup.recoverable43:
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  br label %xiao.fn.error
dynamic.try.normal7:
  call void @xiao_runtime_error_checkpoint_begin()
  %t133 = call ptr @llvm.stacksave()
  %t134 = getelementptr inbounds [13 x i8], ptr @.xiao.str31, i64 0, i64 0
  %t135 = insertvalue %xiao.bytes zeroinitializer, ptr %t134, 0
  %t136 = insertvalue %xiao.bytes %t135, i64 12, 1
  store %xiao.bytes %t136, ptr %t137
  store ptr null, ptr %t138
  %t139 = call i32 @xiao_runtime_string_new(ptr %t137, ptr %t138)
  %t140 = icmp eq i32 %t139, 0
  br i1 %t140, label %abi.ok46, label %abi.status.fail47
abi.status.fail47:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %dynamic.try.normal.finally.fail44
abi.ok46:
  %t141 = load ptr, ptr %t138
  store %xiao.value zeroinitializer, ptr %t143
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t143, ptr %t141)
  %t142 = load %xiao.value, ptr %t143
  %t145 = getelementptr inbounds %xiao.value, ptr %t144, i64 0
  store %xiao.value %t142, ptr %t145
  %t146 = call i32 @xiao_runtime_print_values_with_capabilities(ptr %t144, i64 1, i64 127)
  %t147 = icmp eq i32 %t146, 0
  br i1 %t147, label %abi.ok48, label %abi.status.fail49
abi.status.fail49:
  call i32 @xiao_runtime_error_attach_span(i64 486, i64 507)
  br label %dynamic.try.normal.finally.fail44
abi.ok48:
  store %xiao.value %t142, ptr %t148
  call void @xiao_runtime_value_release_strong(ptr %t148)
  store %xiao.value zeroinitializer, ptr %t150
  call void @xiao_runtime_value_none(ptr sret(%xiao.value) %t150)
  %t149 = load %xiao.value, ptr %t150
  store %xiao.value %t149, ptr %t151
  call void @xiao_runtime_value_release_strong(ptr %t151)
  %t152 = getelementptr inbounds [13 x i8], ptr @.xiao.str32, i64 0, i64 0
  %t153 = insertvalue %xiao.bytes zeroinitializer, ptr %t152, 0
  %t154 = insertvalue %xiao.bytes %t153, i64 12, 1
  store %xiao.bytes %t154, ptr %t155
  store ptr null, ptr %t156
  %t157 = call i32 @xiao_runtime_string_new(ptr %t155, ptr %t156)
  %t158 = icmp eq i32 %t157, 0
  br i1 %t158, label %abi.ok50, label %abi.status.fail51
abi.status.fail51:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %dynamic.try.normal.finally.fail44
abi.ok50:
  %t159 = load ptr, ptr %t156
  store %xiao.value zeroinitializer, ptr %t161
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t161, ptr %t159)
  %t160 = load %xiao.value, ptr %t161
  store %xiao.value %t160, ptr %t162
  %t163 = getelementptr inbounds [10 x i8], ptr @.xiao.bytes33, i64 0, i64 0
  %t164 = insertvalue %xiao.bytes zeroinitializer, ptr %t163, 0
  %t165 = insertvalue %xiao.bytes %t164, i64 9, 1
  store %xiao.bytes %t165, ptr %t166
  %t168 = insertvalue %xiao.error.location zeroinitializer, i64 522, 0
  %t169 = insertvalue %xiao.error.location %t168, i64 554, 1
  %t170 = insertvalue %xiao.error.location %t169, i8 1, 2
  store %xiao.error.location %t170, ptr %t167
  store %xiao.value zeroinitializer, ptr %t172
  call void @xiao_runtime_error_new_values(ptr sret(%xiao.value) %t172, ptr %t166, ptr %t162, ptr null, ptr %t167)
  %t171 = load %xiao.value, ptr %t172
  store %xiao.value %t160, ptr %t173
  call void @xiao_runtime_value_release_strong(ptr %t173)
  %t174 = call i32 @xiao_runtime_error_class()
  %t175 = icmp eq i32 %t174, 0
  br i1 %t175, label %abi.error.ok52, label %abi.error.fail53
abi.error.fail53:
  call i32 @xiao_runtime_error_attach_span(i64 522, i64 554)
  br label %dynamic.try.normal.finally.fail44
abi.error.ok52:
  store %xiao.value %t171, ptr %t176
  %t178 = insertvalue %xiao.error.location zeroinitializer, i64 516, 0
  %t179 = insertvalue %xiao.error.location %t178, i64 554, 1
  %t180 = insertvalue %xiao.error.location %t179, i8 1, 2
  store %xiao.error.location %t180, ptr %t177
  %t181 = call i32 @xiao_runtime_error_raise_value(ptr %t176, ptr %t177)
  call void @xiao_runtime_value_release_strong(ptr %t176)
  %t182 = icmp eq i32 %t181, 0
  br i1 %t182, label %abi.ok54, label %abi.status.fail55
abi.status.fail55:
  call i32 @xiao_runtime_error_attach_span(i64 516, i64 554)
  br label %dynamic.try.normal.finally.fail44
abi.ok54:
  br label %dynamic.try.normal.finally.fail44
dynamic.try.normal.finally.fail44:
  call i32 @xiao_runtime_error_checkpoint_finish()
  call void @llvm.stackrestore(ptr %t133)
  %t183 = call i32 @xiao_runtime_error_class()
  %t184 = icmp eq i32 %t183, 2
  br i1 %t184, label %xiao.fn.error, label %dynamic.error-cleanup.recoverable56
dynamic.error-cleanup.recoverable56:
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  br label %xiao.fn.error
dynamic.try.dispatch6:
  %t185 = call i32 @xiao_runtime_error_class()
  %t186 = icmp eq i32 %t185, 2
  br i1 %t186, label %xiao.fn.error, label %dynamic.try.recoverable57
dynamic.try.recoverable57:
  br label %dynamic.try.unmatched58
dynamic.try.unmatched58:
  call void @xiao_runtime_error_checkpoint_begin()
  %t187 = call ptr @llvm.stacksave()
  %t188 = getelementptr inbounds [13 x i8], ptr @.xiao.str34, i64 0, i64 0
  %t189 = insertvalue %xiao.bytes zeroinitializer, ptr %t188, 0
  %t190 = insertvalue %xiao.bytes %t189, i64 12, 1
  store %xiao.bytes %t190, ptr %t191
  store ptr null, ptr %t192
  %t193 = call i32 @xiao_runtime_string_new(ptr %t191, ptr %t192)
  %t194 = icmp eq i32 %t193, 0
  br i1 %t194, label %abi.ok61, label %abi.status.fail62
abi.status.fail62:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %dynamic.try.unmatched.finally.fail59
abi.ok61:
  %t195 = load ptr, ptr %t192
  store %xiao.value zeroinitializer, ptr %t197
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t197, ptr %t195)
  %t196 = load %xiao.value, ptr %t197
  %t199 = getelementptr inbounds %xiao.value, ptr %t198, i64 0
  store %xiao.value %t196, ptr %t199
  %t200 = call i32 @xiao_runtime_print_values_with_capabilities(ptr %t198, i64 1, i64 127)
  %t201 = icmp eq i32 %t200, 0
  br i1 %t201, label %abi.ok63, label %abi.status.fail64
abi.status.fail64:
  call i32 @xiao_runtime_error_attach_span(i64 486, i64 507)
  br label %dynamic.try.unmatched.finally.fail59
abi.ok63:
  store %xiao.value %t196, ptr %t202
  call void @xiao_runtime_value_release_strong(ptr %t202)
  store %xiao.value zeroinitializer, ptr %t204
  call void @xiao_runtime_value_none(ptr sret(%xiao.value) %t204)
  %t203 = load %xiao.value, ptr %t204
  store %xiao.value %t203, ptr %t205
  call void @xiao_runtime_value_release_strong(ptr %t205)
  %t206 = getelementptr inbounds [13 x i8], ptr @.xiao.str35, i64 0, i64 0
  %t207 = insertvalue %xiao.bytes zeroinitializer, ptr %t206, 0
  %t208 = insertvalue %xiao.bytes %t207, i64 12, 1
  store %xiao.bytes %t208, ptr %t209
  store ptr null, ptr %t210
  %t211 = call i32 @xiao_runtime_string_new(ptr %t209, ptr %t210)
  %t212 = icmp eq i32 %t211, 0
  br i1 %t212, label %abi.ok65, label %abi.status.fail66
abi.status.fail66:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %dynamic.try.unmatched.finally.fail59
abi.ok65:
  %t213 = load ptr, ptr %t210
  store %xiao.value zeroinitializer, ptr %t215
  call void @xiao_runtime_value_str_owned(ptr sret(%xiao.value) %t215, ptr %t213)
  %t214 = load %xiao.value, ptr %t215
  store %xiao.value %t214, ptr %t216
  %t217 = getelementptr inbounds [10 x i8], ptr @.xiao.bytes36, i64 0, i64 0
  %t218 = insertvalue %xiao.bytes zeroinitializer, ptr %t217, 0
  %t219 = insertvalue %xiao.bytes %t218, i64 9, 1
  store %xiao.bytes %t219, ptr %t220
  %t222 = insertvalue %xiao.error.location zeroinitializer, i64 522, 0
  %t223 = insertvalue %xiao.error.location %t222, i64 554, 1
  %t224 = insertvalue %xiao.error.location %t223, i8 1, 2
  store %xiao.error.location %t224, ptr %t221
  store %xiao.value zeroinitializer, ptr %t226
  call void @xiao_runtime_error_new_values(ptr sret(%xiao.value) %t226, ptr %t220, ptr %t216, ptr null, ptr %t221)
  %t225 = load %xiao.value, ptr %t226
  store %xiao.value %t214, ptr %t227
  call void @xiao_runtime_value_release_strong(ptr %t227)
  %t228 = call i32 @xiao_runtime_error_class()
  %t229 = icmp eq i32 %t228, 0
  br i1 %t229, label %abi.error.ok67, label %abi.error.fail68
abi.error.fail68:
  call i32 @xiao_runtime_error_attach_span(i64 522, i64 554)
  br label %dynamic.try.unmatched.finally.fail59
abi.error.ok67:
  store %xiao.value %t225, ptr %t230
  %t232 = insertvalue %xiao.error.location zeroinitializer, i64 516, 0
  %t233 = insertvalue %xiao.error.location %t232, i64 554, 1
  %t234 = insertvalue %xiao.error.location %t233, i8 1, 2
  store %xiao.error.location %t234, ptr %t231
  %t235 = call i32 @xiao_runtime_error_raise_value(ptr %t230, ptr %t231)
  call void @xiao_runtime_value_release_strong(ptr %t230)
  %t236 = icmp eq i32 %t235, 0
  br i1 %t236, label %abi.ok69, label %abi.status.fail70
abi.status.fail70:
  call i32 @xiao_runtime_error_attach_span(i64 516, i64 554)
  br label %dynamic.try.unmatched.finally.fail59
abi.ok69:
  br label %dynamic.try.unmatched.finally.fail59
dynamic.try.unmatched.finally.fail59:
  call i32 @xiao_runtime_error_checkpoint_finish()
  call void @llvm.stackrestore(ptr %t187)
  %t237 = call i32 @xiao_runtime_error_class()
  %t238 = icmp eq i32 %t237, 2
  br i1 %t238, label %xiao.fn.error, label %dynamic.error-cleanup.recoverable71
dynamic.error-cleanup.recoverable71:
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  br label %xiao.fn.error
dynamic.try.continue8:
  %t239 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes37, i64 0, i64 0
  %t240 = insertvalue %xiao.bytes zeroinitializer, ptr %t239, 0
  %t241 = insertvalue %xiao.bytes %t240, i64 10, 1
  store %xiao.bytes %t241, ptr %t242
  %t243 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t242)
  %t244 = icmp eq i32 %t243, 0
  br i1 %t244, label %abi.ok72, label %abi.status.fail73
abi.status.fail73:
  call i32 @xiao_runtime_error_attach_span(i64 559, i64 567)
  br label %xiao.fn.error
abi.ok72:
  store %xiao.value zeroinitializer, ptr %t246
  call void @xiao_runtime_value_int(ptr sret(%xiao.value) %t246, i64 0)
  %t245 = load %xiao.value, ptr %t246
  call void @xiao_runtime_error_clear()
  call void @xiao_runtime_value_release_strong(ptr %xiao.return.site1)
  store %xiao.value %t245, ptr %xiao.return.site1
  store ptr %xiao.return.site1, ptr %xiao.return.source
  store i1 true, ptr %xiao.return.temporary
  br label %xiao.fn.return
xiao.fn.return:
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  call void @xiao_runtime_value_release_strong(ptr %slot2)
  call void @xiao_runtime_value_release_strong(ptr %slot1)
  %t247 = call i32 @xiao_runtime_error_class()
  %t248 = icmp eq i32 %t247, 0
  br i1 %t248, label %abi.ok74, label %abi.status.fail75
abi.status.fail75:
  call i32 @xiao_runtime_error_attach_span(i64 307, i64 568)
  br label %xiao.fn.error
abi.ok74:
  %t249 = load ptr, ptr %xiao.return.source
  %t250 = icmp ne ptr %t249, null
  br i1 %t250, label %xiao.fn.return.value, label %xiao.fn.return.cleanup
xiao.fn.return.value:
  %t251 = load i1, ptr %xiao.return.temporary
  br i1 %t251, label %xiao.fn.return.copy, label %xiao.fn.return.move
xiao.fn.return.copy:
  %t252 = call i32 @xiao_runtime_value_copy(ptr %t249, ptr %xiao.function.result)
  %t253 = icmp eq i32 %t252, 0
  br i1 %t253, label %abi.ok76, label %abi.status.fail77
abi.status.fail77:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.fn.error
abi.ok76:
  br label %xiao.fn.return.cleanup
xiao.fn.return.move:
  %t254 = load %xiao.value, ptr %t249
  store %xiao.value %t254, ptr %xiao.function.result
  store %xiao.value zeroinitializer, ptr %t249
  br label %xiao.fn.return.cleanup
xiao.fn.return.cleanup:
  call void @xiao_runtime_value_release_strong(ptr %xiao.return.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.return.site1)
  %t255 = call i32 @xiao_runtime_error_class()
  %t256 = icmp eq i32 %t255, 0
  br i1 %t256, label %abi.ok78, label %abi.status.fail79
abi.status.fail79:
  call i32 @xiao_runtime_error_attach_span(i64 307, i64 568)
  br label %xiao.fn.error
abi.ok78:
  ret void
xiao.fn.error:
  %t257 = call i32 @xiao_runtime_error_class()
  %t258 = icmp eq i32 %t257, 2
  br i1 %t258, label %xiao.fn.error.return, label %xiao.fn.error.cleanup
xiao.fn.error.cleanup:
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  call void @xiao_runtime_value_release_strong(ptr %slot2)
  call void @xiao_runtime_value_release_strong(ptr %slot1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.return.site0)
  call void @xiao_runtime_value_release_strong(ptr %xiao.return.site1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.function.result)
  br label %xiao.fn.error.return
xiao.fn.error.return:
  %t259 = getelementptr inbounds [6 x i8], ptr @.xiao.bytes38, i64 0, i64 0
  %t260 = insertvalue %xiao.bytes zeroinitializer, ptr %t259, 0
  %t261 = insertvalue %xiao.bytes %t260, i64 5, 1
  store %xiao.bytes %t261, ptr %t262
  %t263 = getelementptr inbounds [7 x i8], ptr @.xiao.bytes39, i64 0, i64 0
  %t264 = insertvalue %xiao.bytes zeroinitializer, ptr %t263, 0
  %t265 = insertvalue %xiao.bytes %t264, i64 6, 1
  store %xiao.bytes %t265, ptr %t266
  call void @xiao_runtime_error_push_native_frame(ptr %t262, ptr %t266, i64 307, i64 568)
  store %xiao.value zeroinitializer, ptr %xiao.function.result
  ret void
}

define void @xiao.fn.15caa14cc209c2c0(ptr %xiao.function.result, ptr %xiao.arg0, ptr %xiao.arg1) {
entry:
  %xiao.return.source = alloca ptr
  %xiao.return.temporary = alloca i1
  %slot1 = alloca %xiao.value
  %slot0 = alloca %xiao.value
  %slot2 = alloca %xiao.value
  %t9 = alloca %xiao.bytes
  %t12 = alloca %xiao.value
  %t19 = alloca %xiao.bytes
  %t22 = alloca %xiao.value, i64 1
  %t24 = alloca %xiao.value
  %t28 = alloca %xiao.bytes
  %t31 = alloca %xiao.value
  %t32 = alloca %xiao.value
  %t37 = alloca %xiao.bytes
  %t40 = alloca %xiao.value
  %t44 = alloca %xiao.value
  %t48 = alloca %xiao.value, i64 2
  %t51 = alloca %xiao.value
  %t55 = alloca %xiao.bytes
  %t58 = alloca %xiao.value
  %t59 = alloca %xiao.value
  %t60 = alloca %xiao.value
  %t61 = alloca %xiao.value
  %t63 = alloca %xiao.value
  %t65 = alloca %xiao.value
  %t75 = alloca %xiao.bytes
  %t79 = alloca %xiao.bytes
  store ptr null, ptr %xiao.return.source
  store i1 false, ptr %xiao.return.temporary
  store %xiao.value zeroinitializer, ptr %slot1
  store %xiao.value zeroinitializer, ptr %slot0
  store %xiao.value zeroinitializer, ptr %slot2
  %t0 = call i32 @xiao_runtime_value_copy(ptr %xiao.arg0, ptr %slot1)
  %t1 = icmp eq i32 %t0, 0
  br i1 %t1, label %abi.ok0, label %abi.status.fail1
abi.status.fail1:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.fn.error
abi.ok0:
  %t2 = call i32 @xiao_runtime_value_copy(ptr %xiao.arg1, ptr %slot2)
  %t3 = icmp eq i32 %t2, 0
  br i1 %t3, label %abi.ok2, label %abi.status.fail3
abi.status.fail3:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.fn.error
abi.ok2:
  %t4 = load %xiao.value, ptr %slot1
  %t5 = load %xiao.value, ptr %slot2
  %t6 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes40, i64 0, i64 0
  %t7 = insertvalue %xiao.bytes zeroinitializer, ptr %t6, 0
  %t8 = insertvalue %xiao.bytes %t7, i64 10, 1
  store %xiao.bytes %t8, ptr %t9
  %t10 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t9)
  %t11 = icmp eq i32 %t10, 0
  br i1 %t11, label %abi.ok4, label %abi.status.fail5
abi.status.fail5:
  call i32 @xiao_runtime_error_attach_span(i64 259, i64 277)
  br label %xiao.fn.error
abi.ok4:
  store %xiao.value zeroinitializer, ptr %t12
  %t13 = call i32 @xiao_runtime_value_copy(ptr %slot1, ptr %t12)
  %t14 = icmp eq i32 %t13, 0
  br i1 %t14, label %abi.ok6, label %abi.status.fail7
abi.status.fail7:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.fn.error
abi.ok6:
  %t15 = load %xiao.value, ptr %t12
  %t16 = getelementptr inbounds [10 x i8], ptr @.xiao.bytes41, i64 0, i64 0
  %t17 = insertvalue %xiao.bytes zeroinitializer, ptr %t16, 0
  %t18 = insertvalue %xiao.bytes %t17, i64 9, 1
  store %xiao.bytes %t18, ptr %t19
  %t20 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t19)
  %t21 = icmp eq i32 %t20, 0
  br i1 %t21, label %abi.ok8, label %abi.status.fail9
abi.status.fail9:
  call i32 @xiao_runtime_error_attach_span(i64 267, i64 277)
  br label %xiao.fn.error
abi.ok8:
  %t23 = getelementptr inbounds %xiao.value, ptr %t22, i64 0
  store %xiao.value %t15, ptr %t23
  store %xiao.value zeroinitializer, ptr %t24
  %t25 = getelementptr inbounds [5 x i8], ptr @.xiao.bytes42, i64 0, i64 0
  %t26 = insertvalue %xiao.bytes zeroinitializer, ptr %t25, 0
  %t27 = insertvalue %xiao.bytes %t26, i64 4, 1
  store %xiao.bytes %t27, ptr %t28
  %t29 = call i32 @xiao_runtime_concurrency_call(ptr %t28, ptr %t22, i64 1, ptr %t24)
  %t30 = icmp eq i32 %t29, 0
  br i1 %t30, label %dynamic.concurrency.ok10, label %dynamic.concurrency.fail11
dynamic.concurrency.fail11:
  store %xiao.value %t15, ptr %t31
  call void @xiao_runtime_value_release_strong(ptr %t31)
  call i32 @xiao_runtime_error_attach_span(i64 267, i64 277)
  br label %xiao.fn.error
dynamic.concurrency.ok10:
  store %xiao.value %t15, ptr %t32
  call void @xiao_runtime_value_release_strong(ptr %t32)
  %t33 = load %xiao.value, ptr %t24
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  store %xiao.value %t33, ptr %slot0
  %t34 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes43, i64 0, i64 0
  %t35 = insertvalue %xiao.bytes zeroinitializer, ptr %t34, 0
  %t36 = insertvalue %xiao.bytes %t35, i64 10, 1
  store %xiao.bytes %t36, ptr %t37
  %t38 = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %t37)
  %t39 = icmp eq i32 %t38, 0
  br i1 %t39, label %abi.ok12, label %abi.status.fail13
abi.status.fail13:
  call i32 @xiao_runtime_error_attach_span(i64 282, i64 306)
  br label %xiao.fn.error
abi.ok12:
  store %xiao.value zeroinitializer, ptr %t40
  %t41 = call i32 @xiao_runtime_value_copy(ptr %slot0, ptr %t40)
  %t42 = icmp eq i32 %t41, 0
  br i1 %t42, label %abi.ok14, label %abi.status.fail15
abi.status.fail15:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.fn.error
abi.ok14:
  %t43 = load %xiao.value, ptr %t40
  store %xiao.value zeroinitializer, ptr %t44
  %t45 = call i32 @xiao_runtime_value_copy(ptr %slot2, ptr %t44)
  %t46 = icmp eq i32 %t45, 0
  br i1 %t46, label %abi.ok16, label %abi.status.fail17
abi.status.fail17:
  call i32 @xiao_runtime_error_attach_span(i64 0, i64 817)
  br label %xiao.fn.error
abi.ok16:
  %t47 = load %xiao.value, ptr %t44
  %t49 = getelementptr inbounds %xiao.value, ptr %t48, i64 0
  store %xiao.value %t43, ptr %t49
  %t50 = getelementptr inbounds %xiao.value, ptr %t48, i64 1
  store %xiao.value %t47, ptr %t50
  store %xiao.value zeroinitializer, ptr %t51
  %t52 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes44, i64 0, i64 0
  %t53 = insertvalue %xiao.bytes zeroinitializer, ptr %t52, 0
  %t54 = insertvalue %xiao.bytes %t53, i64 10, 1
  store %xiao.bytes %t54, ptr %t55
  %t56 = call i32 @xiao_runtime_concurrency_call(ptr %t55, ptr %t48, i64 2, ptr %t51)
  %t57 = icmp eq i32 %t56, 0
  br i1 %t57, label %dynamic.concurrency.ok18, label %dynamic.concurrency.fail19
dynamic.concurrency.fail19:
  store %xiao.value %t47, ptr %t58
  call void @xiao_runtime_value_release_strong(ptr %t58)
  store %xiao.value %t43, ptr %t59
  call void @xiao_runtime_value_release_strong(ptr %t59)
  call i32 @xiao_runtime_error_attach_span(i64 282, i64 306)
  br label %xiao.fn.error
dynamic.concurrency.ok18:
  store %xiao.value %t43, ptr %t60
  call void @xiao_runtime_value_release_strong(ptr %t60)
  store %xiao.value %t47, ptr %t61
  call void @xiao_runtime_value_release_strong(ptr %t61)
  %t62 = load %xiao.value, ptr %t51
  store %xiao.value %t62, ptr %t63
  call void @xiao_runtime_value_release_strong(ptr %t63)
  store ptr null, ptr %xiao.return.source
  store %xiao.value zeroinitializer, ptr %t65
  call void @xiao_runtime_value_none(ptr sret(%xiao.value) %t65)
  %t64 = load %xiao.value, ptr %t65
  store %xiao.value %t64, ptr %xiao.function.result
  br label %xiao.fn.return
xiao.fn.return:
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  call void @xiao_runtime_value_release_strong(ptr %slot1)
  %t66 = call i32 @xiao_runtime_error_class()
  %t67 = icmp eq i32 %t66, 0
  br i1 %t67, label %abi.ok20, label %abi.status.fail21
abi.status.fail21:
  call i32 @xiao_runtime_error_attach_span(i64 199, i64 307)
  br label %xiao.fn.error
abi.ok20:
  br label %xiao.fn.return.cleanup
xiao.fn.return.cleanup:
  %t68 = call i32 @xiao_runtime_error_class()
  %t69 = icmp eq i32 %t68, 0
  br i1 %t69, label %abi.ok22, label %abi.status.fail23
abi.status.fail23:
  call i32 @xiao_runtime_error_attach_span(i64 199, i64 307)
  br label %xiao.fn.error
abi.ok22:
  ret void
xiao.fn.error:
  %t70 = call i32 @xiao_runtime_error_class()
  %t71 = icmp eq i32 %t70, 2
  br i1 %t71, label %xiao.fn.error.return, label %xiao.fn.error.cleanup
xiao.fn.error.cleanup:
  call void @xiao_runtime_value_release_strong(ptr %slot0)
  call void @xiao_runtime_value_release_strong(ptr %slot1)
  call void @xiao_runtime_value_release_strong(ptr %xiao.function.result)
  br label %xiao.fn.error.return
xiao.fn.error.return:
  %t72 = getelementptr inbounds [6 x i8], ptr @.xiao.bytes45, i64 0, i64 0
  %t73 = insertvalue %xiao.bytes zeroinitializer, ptr %t72, 0
  %t74 = insertvalue %xiao.bytes %t73, i64 5, 1
  store %xiao.bytes %t74, ptr %t75
  %t76 = getelementptr inbounds [11 x i8], ptr @.xiao.bytes46, i64 0, i64 0
  %t77 = insertvalue %xiao.bytes zeroinitializer, ptr %t76, 0
  %t78 = insertvalue %xiao.bytes %t77, i64 10, 1
  store %xiao.bytes %t78, ptr %t79
  call void @xiao_runtime_error_push_native_frame(ptr %t75, ptr %t79, i64 199, i64 307)
  store %xiao.value zeroinitializer, ptr %xiao.function.result
  ret void
}


@xiao_native_metadata = constant [107 x i8] c"\58\49\41\4F\4D\45\54\41\01\00\00\00\6B\00\00\00\14\00\01\00\00\00\00\00\14\00\01\00\00\00\00\00\66\00\00\00\00\00\00\00\19\00\00\00\40\00\00\00\01\00\00\00\14\00\01\00\00\00\00\00\16\00\00\00\78\38\36\5F\36\34\2D\70\63\2D\77\69\6E\64\6F\77\73\2D\6D\73\76\63\05\00\00\00\30\2E\31\2E\30\08\00\00\00\70\6F\72\74\61\62\6C\65", section ".xiaomta", align 4
@llvm.used = appending global [1 x ptr] [ptr @xiao_native_metadata], section "llvm.metadata"

define internal i32 @wait_for_lock_cancel(ptr %operation) {
entry:
  br label %check
check:
  %result = call i32 @xiao_runtime_concurrency_cancellation_check(ptr %operation)
  %cancelled = icmp ne i32 %result, 0
  br i1 %cancelled, label %done, label %check
done:
  ret i32 %result
}
