#!/usr/bin/env bash
set -u
capture_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
capture_name="$1"
shift
capture_log="$capture_root/$capture_name.log"
capture_meta="$capture_root/$capture_name.meta"
{
  printf 'started_at=%s\n' "$(date --iso-8601=seconds)"
  printf 'commit=%s\n' "$(git rev-parse HEAD)"
  printf 'cwd=%s\n' "$PWD"
  printf 'RUSTUP_TOOLCHAIN=%s\n' "${RUSTUP_TOOLCHAIN-<unset>}"
  for capture_key in XIAO_CLANG XIAO_LLVM_AS XIAO_LLC XIAO_STRIP XIAO_TARGET_TRIPLE XIAO_RUNTIME_LIBRARY XIAO_DIAGNOSTICS_PATH XIAO_DIAGNOSTICS_HOLD_MS XIAO_USE_XVFB; do
    printf '%s=%s\n' "$capture_key" "${!capture_key-<unset>}"
  done
  printf 'command='
  printf '%q ' "$@"
  printf '\n'
} > "$capture_meta"
capture_started=$SECONDS
"$@" > "$capture_log" 2>&1
capture_status=$?
{
  printf 'finished_at=%s\n' "$(date --iso-8601=seconds)"
  printf 'elapsed_seconds=%s\n' "$((SECONDS-capture_started))"
  printf 'exit_code=%s\n' "$capture_status"
} >> "$capture_meta"
cat "$capture_meta"
tail -n 14 "$capture_log"
exit "$capture_status"
